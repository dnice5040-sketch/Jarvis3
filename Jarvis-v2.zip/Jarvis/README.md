# JARVIS — Phase 1 foundation

## Run it
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this `Jarvis` folder. Wait for "Gradle sync" to finish (first time takes a few minutes).
3. Connect your Android phone (Settings > About phone > tap Build number 7 times > Developer options > USB debugging), or create an emulator in Device Manager.
4. Press the green Run button.
5. In the app: tap the gear, paste your AI API key (console.anthropic.com), save. Tap MIC and allow microphone.

## Try saying
open YouTube / open WhatsApp / open wifi settings / call 555 0100 (asks first) /
text 555 0100 saying hello (asks first) / set alarm for 7:30 am / remind me to stretch at 5 pm /
timer for 10 minutes / search for best pizza near me / volume up / pause music / read my notifications /
remember that I like jazz / anything else goes to the AI.

## Roadmap
- Phase 2: contacts lookup, location (with permission), file picker, brightness, notification summaries by AI
- Phase 3: wake word "Hey JARVIS" (foreground service + on-device hotword engine), always-on hands-free
- Phase 4: Accessibility-based multi-step app control, proactive daily briefing

## Phase 3: wake word ("Hey JARVIS")
Gear > turn on "Listen for wake word" (allow microphone + notifications). A notification with a Stop button shows while JARVIS listens.
Also tap "Allow opening over other apps" and enable it, so JARVIS can jump to the screen when it hears you. Without it you get a "Tap to talk" notification instead.
Change the word in the "Wake word" box (default: jarvis), then Save.

Honest limits of this version: it uses Android's built-in speech recognizer (no extra account needed), so it uses more battery than a dedicated engine, may click or beep every few seconds on some phones, and works best with the phone unlocked. It does not restart after a reboot. An on-device engine (e.g. Picovoice Porcupine) is the upgrade path if you want battery-friendly always-on listening.

## Phase 2: contacts, location, files
- "call mom" / "text Sam saying running late" (asks for contacts permission the first time, then confirms; you still press call/send)
- "where am I" / "send my location to Sam" (location permission; uses your last known fix; confirms first)
- "summarize a file" / "read a file" (you pick one text file; only that file is read)
- "summarize my notifications" (asks first, because the text goes to the AI service)
- "set brightness to 40 percent" (opens the system page to allow it the first time)
Not yet: Accessibility-based control of other apps and a daily briefing (Phase 4).
