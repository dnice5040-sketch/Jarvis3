package com.jarvis.assistant

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val JarvisCyan = Color(0xFF00E5FF)
val JarvisText = Color(0xFFCFF8FF)
val JarvisPanel = Color(0xFF06181D)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = JarvisCyan,
            background = Color.Black,
            surface = Color(0xFF05161A),
            onSurface = JarvisText,
            onBackground = JarvisText,
            outline = JarvisCyan.copy(alpha = 0.4f)
        ),
        content = content
    )
}
