package com.jarvis.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { JarvisTheme { JarvisScreen() } }
        if (savedInstanceState == null) handleWake(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWake(intent)
    }

    private fun handleWake(i: Intent?) {
        if (i?.getBooleanExtra("wake", false) == true) { i.removeExtra("wake"); vm.onWake() }
    }

    // While the app is on screen it owns the microphone; the background listener steps aside.
    override fun onResume() { super.onResume(); WakeService.setAppVisible(true) }
    override fun onPause() { WakeService.setAppVisible(false); super.onPause() }
}
