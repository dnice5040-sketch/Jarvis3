package com.jarvis.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Only runs if the user turns on Notification access for JARVIS in Android settings.
 * Keeps the 30 most recent notifications in memory only (never written to disk or sent anywhere
 * unless the user asks JARVIS to read them).
 */
class JarvisNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (ex: Exception) { sbn.packageName }
        synchronized(recent) {
            recent.add(0, Item(app, title, text))
            while (recent.size > 30) recent.removeAt(recent.lastIndex)
        }
    }

    data class Item(val app: String, val title: String, val text: String)

    companion object {
        val recent = mutableListOf<Item>()
    }
}
