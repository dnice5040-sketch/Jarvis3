package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Talks to the Anthropic Messages API. Call from a background thread. */
class LlmClient {
    companion object {
        const val MODEL = "claude-sonnet-5-5"
        const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    }

    private fun system(owner: String, memories: List<String>): String {
        val who = if (owner.isBlank()) "user" else owner
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        val mem = if (memories.isEmpty()) "" else
            "\nThings the user asked you to remember:\n" + memories.joinToString("\n") { "- $it" }
        return """You are JARVIS, a calm, professional, slightly witty personal AI assistant living on $who's Android phone. Address the person as "$who". Your replies are spoken aloud, so keep them short (1-3 sentences unless asked for more), in plain text with no markdown. Be proactive but never intrusive. You cannot perform phone actions yourself; the app handles commands such as "open YouTube", "call 555 0100", "set alarm for 7 am", "search for ...". If asked for something like that, tell the user the phrase to say. Never claim to have done an action you did not do. Current local date and time: $now.$mem"""
    }

    fun ask(apiKey: String, owner: String, memories: List<String>, history: List<Pair<String, String>>): String {
        val msgs = JSONArray()
        history.dropWhile { it.first != "user" }.forEach { (role, text) ->
            msgs.put(JSONObject().put("role", role).put("content", text))
        }
        val body = JSONObject()
            .put("model", MODEL).put("max_tokens", 400)
            .put("system", system(owner, memories)).put("messages", msgs)
        val c = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", apiKey)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code !in 200..299) return "The AI service returned error $code. Please check your API key in settings."
            val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val blocks = json.getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until blocks.length()) {
                val b = blocks.getJSONObject(i)
                if (b.optString("type") == "text") sb.append(b.optString("text"))
            }
            return sb.toString().ifBlank { "I have nothing to add to that." }
        } catch (e: IOException) {
            return "I can't reach the network right now."
        } catch (e: Exception) {
            return "Something went wrong while thinking that through."
        } finally {
            c.disconnect()
        }
    }
}
