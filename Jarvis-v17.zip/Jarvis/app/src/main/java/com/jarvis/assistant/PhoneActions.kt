package com.jarvis.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class ActionResult {
    data class Done(val message: String) : ActionResult()
    /** Sensitive action: Jarvis explains it and waits for the user to confirm before running. */
    data class Confirm(val description: String, val run: () -> String) : ActionResult()
    /** Sensitive action that sends text to the AI service; needs confirmation first. */
    data class ConfirmAsk(val description: String, val prompt: String) : ActionResult()
    data class NeedPermission(val perms: List<String>, val message: String, val retry: String) : ActionResult()
    /** Slow work; runs on a background thread. */
    data class Later(val work: () -> String) : ActionResult()
    data class PickFile(val task: String) : ActionResult()
}

/** Turns spoken/typed commands into real Android actions using official intents and APIs. */
class PhoneActions(private val ctx: Context) {
    private val pm = ctx.packageManager
    private val store by lazy { SecureStore.of(ctx) }
    private val rx = RegexOption.IGNORE_CASE

    private data class Contact(val name: String, val number: String)
    private sealed class Resolved {
        data class Ok(val label: String, val number: String) : Resolved()
        data class Fail(val result: ActionResult) : Resolved()
    }

    private fun m(p: String, s: String) = Regex(p, rx).matchEntire(s)
    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun start(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (e: Exception) { false }

    private fun ok(success: Boolean, good: String, bad: String = "That didn't work on this device.") =
        ActionResult.Done(if (success) good else bad)

    private fun to24(h: Int, ap: String) = when (ap.lowercase()) {
        "p" -> if (h < 12) h + 12 else h
        "a" -> if (h == 12) 0 else h
        else -> h
    }

    private fun setAlarm(h: Int, min: Int, label: String): ActionResult {
        if (h > 23 || min > 59) return ActionResult.Done("That isn't a valid time.")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return ok(start(i), "Done. Set for ${"%02d:%02d".format(h, min)}.")
    }

    private fun key(code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun overlayHint(): String =
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(ctx))
            " If I'm in the background, turn on Display over other apps in the Control Center so Android lets me open apps."
        else ""

    private fun openApp(name: String): ActionResult {
        val q = AppFinder.clean(name)
        if (q.isEmpty()) return ActionResult.Done("Which app should I open?")
        val hits = AppFinder.find(ctx, q)
        if (hits.isEmpty()) {
            val pkg = AppFinder.knownPackage(q)
            if (pkg != null) {
                val label = q.replaceFirstChar { it.uppercase() }
                return ActionResult.Confirm("$label isn't installed on this phone. Shall I open its Play Store page?") {
                    val opened = start(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))) ||
                        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
                    if (opened) "Opening the Play Store." else "I couldn't open the Play Store."
                }
            }
            val sug = AppFinder.suggestions(ctx, q)
            return ActionResult.Done("I couldn't find an app called $name on this phone." +
                (if (sug.isNotEmpty()) " Did you mean " + sug.joinToString(" or ") + "?" else ""))
        }
        val app = hits[0]
        val intent = pm.getLaunchIntentForPackage(app.pkg)
            ?: return ActionResult.Done("I found ${app.label}, but Android has no way to open it.")
        if (JarvisAccessibilityService.instance == null) {
            return ok(start(intent), "Opening ${app.label}.", "Android wouldn't open ${app.label}." + overlayHint())
        }
        // With screen control on, check that the app really came to the front.
        return ActionResult.Later {
            if (!start(intent)) "Android wouldn't open ${app.label}." + overlayHint()
            else if (ScreenControl.waitForApp(app.pkg, 4000L)) "Opened ${app.label}."
            else "I tried to open ${app.label}, but it didn't come to the front." + overlayHint()
        }
    }

    // ---- Notifications -------------------------------------------------------------------------

    private fun notifications(summarize: Boolean): ActionResult {
        if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
            start(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return ActionResult.Done("Notification access is off. I've opened the setting; enable Jarvis there if you'd like me to read them.")
        }
        val items = synchronized(JarvisNotificationService.recent) { JarvisNotificationService.recent.take(10) }
        if (items.isEmpty()) return ActionResult.Done("No new notifications since I started listening.")
        if (summarize) {
            val dump = items.joinToString("\n") { "${it.app}: ${it.title} ${it.text}".trim() }
            return ActionResult.ConfirmAsk(
                "I'll send the text of your ${items.size} recent notifications to the AI service to summarize them.",
                "Summarize these phone notifications in two or three short sentences, most important first:\n$dump"
            )
        }
        return ActionResult.Done("You have ${items.size} recent. " + items.take(6).joinToString(" ") {
            "${it.app}: ${it.title.ifBlank { it.text }}."
        })
    }

    // ---- Contacts ------------------------------------------------------------------------------

    private fun findContacts(q: String): List<Contact> {
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$q%"), null
        ) ?: return emptyList()
        val out = mutableListOf<Contact>()
        c.use { while (it.moveToNext()) out += Contact(it.getString(0) ?: "", it.getString(1) ?: "") }
        return out.distinctBy { x -> x.number.filter { ch -> ch.isDigit() } }
    }

    private fun resolve(target: String, retry: String): Resolved {
        val t = target.trim()
        if (Regex("[\\d\\s+()\\-]+").matches(t)) return Resolved.Ok(t, t.filter { it.isDigit() || it == '+' })
        if (!has(Manifest.permission.READ_CONTACTS)) {
            return Resolved.Fail(ActionResult.NeedPermission(
                listOf(Manifest.permission.READ_CONTACTS),
                "To find $t I need access to your contacts. I only look people up when you ask.", retry
            ))
        }
        val found = findContacts(t)
        if (found.isEmpty()) return Resolved.Fail(ActionResult.Done("I couldn't find $t in your contacts."))
        val exact = found.filter { it.name.equals(t, true) }
        val pick = when {
            found.size == 1 -> found[0]
            exact.size == 1 -> exact[0]
            else -> null
        } ?: return Resolved.Fail(ActionResult.Done(
            "I found several matches: " + found.take(4).joinToString(", ") { it.name } + ". Which one?"
        ))
        return Resolved.Ok(pick.name, pick.number.filter { it.isDigit() || it == '+' })
    }

    // ---- Location ------------------------------------------------------------------------------

    private fun hasLocation() =
        has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)

    private fun locationPerms() =
        listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)

    @Suppress("MissingPermission")
    private fun lastLocation(): Location? {
        if (!hasLocation()) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null }
        }.maxByOrNull { it.time }
    }

    @Suppress("DEPRECATION")
    private fun describe(loc: Location): String {
        val coords = "%.4f, %.4f".format(loc.latitude, loc.longitude)
        return try {
            if (!Geocoder.isPresent()) return "Your coordinates are $coords."
            val a = Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
            if (a?.getAddressLine(0) != null) "You're near ${a.getAddressLine(0)}." else "Your coordinates are $coords."
        } catch (e: Exception) { "Your coordinates are $coords." }
    }

    /** Cleans the sentence, splits chains like "open X and read my screen", and runs the parts in order. */
    fun handle(raw: String): ActionResult? {
        val cleaned = Commands.normalize(raw, store.wakeWord)
        if (cleaned.isEmpty()) return null
        val steps = Commands.split(cleaned)
        if (steps.size <= 1) return handleOne(cleaned)
        return ActionResult.Later {
            val said = ArrayList<String>()
            for ((idx, step) in steps.withIndex()) {
                val r = handleOne(step)
                if (r is ActionResult.Done) said.add(r.message)
                else if (r is ActionResult.Later) said.add(r.work())
                else if (r == null) { said.add("I didn't understand \"$step\"."); break }
                else { said.add("I stopped before \"$step\" because it needs your approval. Please say it on its own."); break }
                if (idx < steps.size - 1) {
                    try { Thread.sleep(500) } catch (e: InterruptedException) { break }
                }
            }
            said.joinToString(" ")
        }
    }

    /** Returns null when the text isn't a phone command (so it goes to the AI). */
    private fun handleOne(raw: String): ActionResult? {
        val s = raw.trim().trimEnd('.', '!', '?').trim()

        m("(?:open (?:the )?camera|take (?:a )?(?:photo|picture|selfie))", s)?.let {
            return ok(start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)), "Camera ready.")
        }
        m("(?:open |show )?(?:the )?(?:(wi-?fi|bluetooth|display|sound|battery|location) )?settings", s)?.let { r ->
            val act = when (r.groupValues[1].lowercase().replace("-", "")) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            return ok(start(Intent(act)), "Opening settings.")
        }
        m("(summari[sz]e|read|analy[sz]e|explain)(?: a| the| my)? (?:text )?(?:file|document)|(?:pick|choose|select|attach) a file", s)?.let { r ->
            val sum = r.groupValues[1].lowercase().startsWith("summar")
            return ActionResult.PickFile(if (sum) "Briefly summarize this file." else "Briefly tell me what this file says.")
        }
        m("where am i|what(?:'s| is) my (?:current )?location", s)?.let {
            if (!hasLocation()) return ActionResult.NeedPermission(locationPerms(),
                "I'll need location permission for that. I only use it when you ask.", s)
            val loc = lastLocation() ?: return ActionResult.Done("I can't get a location fix yet. Opening Maps once usually refreshes it.")
            return ActionResult.Later { describe(loc) }
        }
        m("(?:share|send|text) my (?:current )?location (?:to|with) (.+)", s)?.let { r ->
            if (!hasLocation()) return ActionResult.NeedPermission(locationPerms(),
                "I'll need location permission for that. I only use it when you ask.", s)
            when (val t = resolve(r.groupValues[1], s)) {
                is Resolved.Fail -> return t.result
                is Resolved.Ok -> return ActionResult.Confirm(
                    "I'll prepare a text to ${t.label} with a map link to your current location. It won't send until you press send."
                ) {
                    val loc = lastLocation()
                    if (loc == null) "I can't get a location fix right now." else {
                        val body = "My location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
                        val i = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", t.number, null)).putExtra("sms_body", body)
                        if (start(i)) "Message drafted. Press send when ready." else "I couldn't open Messages."
                    }
                }
            }
        }
        m("(?:set )?brightness (?:to )?(\\d{1,3})(?: ?percent| ?%)?", s)?.let { r ->
            if (!Settings.System.canWrite(ctx)) {
                start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
                return ActionResult.Done("I need the permission to modify system settings. I've opened the page; enable it for Jarvis, then ask again.")
            }
            val pct = r.groupValues[1].toInt().coerceIn(1, 100)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
            return ActionResult.Done("Brightness set to $pct percent.")
        }
        m("(?:call|dial|phone) (.+)", s)?.let { r ->
            when (val t = resolve(r.groupValues[1], s)) {
                is Resolved.Fail -> return t.result
                is Resolved.Ok -> {
                    val direct = store.directCall
                    if (direct && !has(Manifest.permission.CALL_PHONE)) {
                        return ActionResult.NeedPermission(listOf(Manifest.permission.CALL_PHONE),
                            "To place calls for you I need the phone permission.", s)
                    }
                    return ActionResult.Confirm(
                        if (direct) "I'll call ${t.label} now." else "I'll open the dialer for ${t.label}. You'll press call yourself."
                    ) {
                        val i = Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", t.number, null))
                        if (start(i)) (if (direct) "Calling." else "Dialer ready.") else "I couldn't place the call."
                    }
                }
            }
        }
        m("(?:text|sms|message|send (?:a )?(?:text|message|sms) to) (.+?)\\s*(?:saying|that says|with|:)\\s*(.+)", s)?.let { r ->
            val body = r.groupValues[2].trim()
            when (val t = resolve(r.groupValues[1], s)) {
                is Resolved.Fail -> return t.result
                is Resolved.Ok -> return ActionResult.Confirm(
                    "I'll prepare a message to ${t.label}: \"$body\". It won't send until you press send in Messages."
                ) {
                    val i = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", t.number, null)).putExtra("sms_body", body)
                    if (start(i)) "Message drafted. Press send when ready." else "I couldn't open Messages."
                }
            }
        }
        m("(?:text|sms|message) (.+)", s)?.let { r ->
            when (val t = resolve(r.groupValues[1], s)) {
                is Resolved.Fail -> return t.result
                is Resolved.Ok -> return ActionResult.Confirm("I'll open Messages for ${t.label}.") {
                    if (start(Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", t.number, null)))) "Messages ready." else "I couldn't open Messages."
                }
            }
        }
        m("(?:set (?:an? )?alarm (?:for|at)|wake me (?:up )?at) (\\d{1,2})(?:[:. ](\\d{2}))?\\s*([ap])?\\.?m?\\.?", s)?.let { r ->
            val h = to24(r.groupValues[1].toInt(), r.groupValues[3])
            return setAlarm(h, r.groupValues[2].ifEmpty { "0" }.toInt(), "Jarvis alarm")
        }
        m("remind me (?:to )?(.+?) (?:at|by) (\\d{1,2})(?:[:. ](\\d{2}))?\\s*([ap])?\\.?m?\\.?(?:\\s+(every ?day|daily))?", s)?.let { r ->
            val hr = r.groupValues[2].toInt()
            val min = r.groupValues[3].ifEmpty { "0" }.toInt()
            val ap = r.groupValues[4]
            if (hr > 23 || min > 59) return ActionResult.Done("That isn't a valid time.")
            val at = if (ap.isNotEmpty() || hr > 12 || hr == 0) Reminders.nextAt(to24(hr, ap), min)
                else minOf(Reminders.nextAt(hr % 12, min), Reminders.nextAt(hr % 12 + 12, min))
            val daily = r.groupValues[5].isNotEmpty()
            val what = r.groupValues[1].trim()
            Reminders.add(ctx, what, at, daily)
            return ActionResult.Done("Done. I'll call you at " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(at)) +
                (if (daily) " every day" else "") + " to remind you: " + what + ".")
        }
        m("remind me (?:to )?(.+?) in (\\d+) (minute|hour)s?", s)?.let { r ->
            val n = r.groupValues[2].toLong()
            val ms = n * (if (r.groupValues[3].lowercase() == "hour") 3_600_000L else 60_000L)
            Reminders.add(ctx, r.groupValues[1].trim(), System.currentTimeMillis() + ms, false)
            return ActionResult.Done("Okay. I'll call you in $n ${r.groupValues[3].lowercase()}${if (n == 1L) "" else "s"} to remind you: ${r.groupValues[1].trim()}.")
        }
        m("remind me in (\\d+) (minute|hour)s? to (.+)", s)?.let { r ->
            val n = r.groupValues[1].toLong()
            val ms = n * (if (r.groupValues[2].lowercase() == "hour") 3_600_000L else 60_000L)
            Reminders.add(ctx, r.groupValues[3].trim(), System.currentTimeMillis() + ms, false)
            return ActionResult.Done("Okay. I'll call you in $n ${r.groupValues[2].lowercase()}${if (n == 1L) "" else "s"} to remind you: ${r.groupValues[3].trim()}.")
        }
        m("(?:what are my|list my|show my|do i have any) reminders", s)?.let {
            val list = Reminders.all(ctx)
            if (list.isEmpty()) return ActionResult.Done("You have no reminders.")
            val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
            return ActionResult.Done("You have ${list.size}. " + list.joinToString(" ") { it.text + " at " + fmt.format(Date(it.at)) + "." })
        }
        m("(?:cancel|clear|delete) (?:all )?(?:my )?reminders", s)?.let {
            Reminders.cancelAll(ctx)
            return ActionResult.Done("All reminders cleared.")
        }
        m("(?:set (?:a )?)?timer (?:for )?(\\d+) (second|minute|hour)s?", s)?.let { r ->
            val n = r.groupValues[1].toInt()
            val secs = n * when (r.groupValues[2].lowercase()) { "hour" -> 3600; "minute" -> 60; else -> 1 }
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return ok(start(i), "Timer started.")
        }
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        m("(?:set )?volume (?:to )?(\\d{1,3})(?: ?percent| ?%)?", s)?.let { r ->
            val pct = r.groupValues[1].toInt().coerceIn(0, 100)
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, max * pct / 100, AudioManager.FLAG_SHOW_UI)
            return ActionResult.Done("Volume set to $pct percent.")
        }
        m("(?:turn )?(?:the )?volume (up|down)|turn (?:it )?(up|down)", s)?.let { r ->
            val up = (r.groupValues[1].ifEmpty { r.groupValues[2] }) == "up"
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return ActionResult.Done(if (up) "Volume up." else "Volume down.")
        }
        m("(pause|resume|next|previous|skip|play|stop)(?: the)?(?: (?:music|song|track|media|video))?", s)?.let { r ->
            val w = r.groupValues[1].lowercase()
            val hasNoun = Regex("music|song|track|media|video", rx).containsMatchIn(s)
            if (hasNoun || w !in listOf("play", "stop")) {
                key(when (w) {
                    "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    "resume", "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                    "next", "skip" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    else -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                })
                return ActionResult.Done("Done.")
            }
        }
        m("summari[sz]e(?: my)?(?: new)? notifications", s)?.let { return notifications(true) }
        m("(?:read|check|what are|show)(?: me)?(?: my)?(?: new)? notifications", s)?.let { return notifications(false) }
        m("google (.+)", s)?.let { r ->
            val q = r.groupValues[1].trim()
            val ok1 = start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
            val ok2 = ok1 || start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            return ok(ok2, "Searching for $q.")
        }
        MoreActions.handle(ctx, s)?.let { return it }
        m("(?:open|launch|start) (.+)", s)?.let { return openApp(it.groupValues[1]) }
        return null
    }
}
