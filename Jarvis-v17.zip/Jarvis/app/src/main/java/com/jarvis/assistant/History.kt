package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** What Jarvis did on its own (auto-replies, call rules, alerts). Stored encrypted on the phone. */
object History {
    fun all(ctx: Context): List<String> {
        val raw = SecureStore.of(ctx).historyJson
        if (raw.isEmpty()) return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    fun log(ctx: Context, text: String) {
        val list = all(ctx).toMutableList()
        list.add(SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date()) + "  " + text)
        while (list.size > 60) list.removeAt(0)
        SecureStore.of(ctx).historyJson = JSONArray(list).toString()
    }

    fun clear(ctx: Context) { SecureStore.of(ctx).historyJson = "" }
}
