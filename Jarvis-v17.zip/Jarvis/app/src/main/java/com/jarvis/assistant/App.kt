package com.jarvis.assistant

import android.app.Application

/** Starts before any screen, service or alarm, so the lock is always in force. */
class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Auth.setup(this)
    }
}
