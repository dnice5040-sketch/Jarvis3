package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Jarvis in the background. While another app is on screen it:
 *  1. listens for the wake word,
 *  2. answers out loud ("Yes, Sam?"), listens for a command,
 *  3. runs phone actions / asks the AI, speaks the result,
 *  4. goes back to listening for the wake word.
 * Shown to the user as a permanent notification with a Stop button. Only runs if switched on.
 */
class WakeService : Service() {
    private enum class St { WAKE, COMMAND, BUSY }
    private enum class After { WAKE, LISTEN }

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private var voice: Voice? = null
    private lateinit var store: SecureStore
    private lateinit var actions: PhoneActions
    private val llm = LlmClient()
    private val brain by lazy { OfflineBrain(applicationContext) }
    private val hud by lazy { AssistantHud(applicationContext) { shush() } }

    private var paused = false
    private var wakeWord = "jarvis"
    private var wakeWords = listOf("jarvis")
    private var st = St.WAKE
    private var after = After.WAKE
    private var gotText = false
    private var authMode = false
    private var turns = 0
    private var warnedOverlay = false
    private var quitting = false
    private var destroyed = false
    private var pending: Pending? = null
    private var replyTarget: JarvisNotificationService.Item? = null
    private var awaitingReplyText = false
    private val announceQueue = mutableListOf<JarvisNotificationService.Item>()
    private data class Alert(val text: String, val call: Boolean)
    private val alertQueue = mutableListOf<Alert>()
    private var userPaused = false
    private var callMode = false
    private var draftItem: JarvisNotificationService.Item? = null
    private val history = Convo.history
    private val backstop = Runnable { if (st == St.COMMAND && !gotText) endConversation() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        store = SecureStore(this)
        actions = PhoneActions(applicationContext)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LISTEN, "Wake word listening", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Jarvis needs you", NotificationManager.IMPORTANCE_HIGH))
        voice = Voice(
            applicationContext,
            onText = { onCommand(it) },
            onLevel = { hud.level(it) },
            onListening = { on ->
                if (!on) main.postDelayed({ if (st == St.COMMAND && !gotText) endConversation() }, 300)
            },
            onSpeechDone = { onSpeechFinished() },
            onFail = { endConversation() }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                SecureStore.of(this).wakeEnabled = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                userPaused = !userPaused
                if (userPaused) {
                    stopRecognizer()
                    voice?.stopListening()
                    hud.hide(0)
                    st = St.WAKE
                } else if (!paused) {
                    st = St.WAKE
                    startListening()
                }
                notifyListening()
                return START_STICKY
            }
            ACTION_SHUSH -> {
                shush()
                return START_STICKY
            }
        }
        wakeWord = store.wakeWord.lowercase(Locale.getDefault())
        wakeWords = if (wakeWord == "jarvis") listOf("jarvis", "jarvas", "jervis") else listOf(wakeWord)
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, 1, buildNotification(), type)
        st = St.WAKE
        paused = appVisible
        if (!paused) startListening()
        return START_STICKY
    }

    // ---- Wake word -----------------------------------------------------------------------------

    private fun startListening() {
        if (paused || userPaused || st != St.WAKE || recognizer != null) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(b: Bundle?) { heardWake(b) }
            override fun onResults(b: Bundle?) { if (!heardWake(b)) restart(300) }
            override fun onError(e: Int) {
                restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
            }
        })
        recognizer = r
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        })
    }

    private fun heardWake(b: Bundle?): Boolean {
        if (paused || userPaused || st != St.WAKE) return false
        val heard = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.joinToString(" ")?.lowercase(Locale.getDefault()) ?: return false
        if (wakeWords.none { heard.contains(it) }) return false
        main.post { onWake() }
        return true
    }

    private fun stopRecognizer() { recognizer?.destroy(); recognizer = null }

    private fun restart(delayMs: Long) {
        stopRecognizer()
        main.postDelayed({ startListening() }, delayMs)
    }

    // ---- Conversation --------------------------------------------------------------------------

    private fun onWake() {
        if (paused || st != St.WAKE) return
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        st = St.COMMAND
        after = After.LISTEN
        turns = 0
        pending = null
        gotText = false
        authMode = false
        if (!Auth.isUnlocked()) { beginAuth(); return }
        val name = store.ownerName.trim()
        val ack = if (name.isEmpty()) "Yes?" else "Yes, $name?"
        hud.show(2, ack)
        voice?.speak(ack)
    }

    private fun onSpeechFinished() {
        if (destroyed || quitting || paused) return
        when (st) {
            St.COMMAND -> startCommandListening()
            St.BUSY -> if (after == After.LISTEN) { st = St.COMMAND; startCommandListening() } else endConversation()
            St.WAKE -> {}
        }
    }

    private fun startCommandListening() {
        if (paused) { st = St.WAKE; return }
        gotText = false
        stopRecognizer()
        hud.show(0, if (authMode) "Security verification" else "Listening…")
        voice?.listen()
        main.removeCallbacks(backstop)
        main.postDelayed(backstop, 12000)
    }

    private fun endConversation() {
        main.removeCallbacks(backstop)
        voice?.stopListening()
        hud.hide(700)
        authMode = false
        st = St.WAKE
        pending = null
        replyTarget = null
        awaitingReplyText = false
        callMode = false
        draftItem = null
        if (!paused && !quitting && !destroyed) main.postDelayed({ if (!tryAnnounce()) startListening() }, 500)
    }

    // ---- Passcode check by voice (the spoken password is never shown, stored or sent anywhere) ----

    private fun beginAuth() {
        Convo.history.clear()
        when {
            !Auth.isSet() -> authSpeak("No passcode is set yet. Please open my security settings and create one.", false)
            Auth.lockoutSecs() > 0L -> authSpeak("Voice interaction is locked. Try again in " + minutesText(Auth.lockoutSecs()) + ".", false)
            else -> { authMode = true; authSpeak("Security verification required. What is the password?", true) }
        }
    }

    private fun authSpeak(text: String, listen: Boolean) {
        after = if (listen) After.LISTEN else After.WAKE
        st = St.BUSY
        hud.show(if (listen) 0 else 2, if (listen) "Security verification" else text)
        voice?.speak(text)
    }

    private fun verifySpoken(text: String) {
        val r = Auth.verify(text)
        when (r.status) {
            AuthStatus.OK -> {
                authMode = false
                turns = 0
                say("Identity verified. Welcome back. How can I assist you?", After.LISTEN)
            }
            AuthStatus.WRONG -> authSpeak("Access denied. Incorrect password. What is the password?", true)
            AuthStatus.LOCKED_OUT -> {
                authMode = false
                authSpeak(
                    if (r.justLocked) "Access denied. Incorrect password. Too many incorrect attempts. Voice interaction is locked for 5 minutes."
                    else "Voice interaction is locked. Try again in " + minutesText(r.lockSecs) + ".",
                    false
                )
            }
            AuthStatus.NOT_SET -> {
                authMode = false
                authSpeak("No passcode is set yet. Please open my security settings and create one.", false)
            }
        }
    }

    private fun onCommand(text: String) {
        gotText = true
        main.removeCallbacks(backstop)
        st = St.BUSY
        if (authMode) { verifySpoken(text); return }
        hud.show(1, text)
        handle(text.trim())
    }

    private fun say(text: String, next: After) {
        if (destroyed) return
        after = next
        st = St.BUSY
        Bridge.post(Msg(false, text))
        history += "assistant" to text
        hud.show(2, text)
        voice?.speak(text)
    }

    private fun sayError(text: String) {
        if (destroyed) return
        after = After.WAKE
        st = St.BUSY
        Bridge.post(Msg(false, text))
        hud.show(2, text)
        voice?.speak(text)
    }

    private fun handle(text: String) {
        if (text.isEmpty()) { endConversation(); return }
        // Defence in depth: nothing below runs unless the owner has been verified.
        if (!Auth.isUnlocked()) { endConversation(); return }
        Auth.touch()
        Bridge.post(Msg(true, text))
        val t = text.lowercase(Locale.getDefault()).trimEnd('.', '!', '?').trim()
        if (callFlow(t)) return
        if (replyFlow(text, t)) return

        val p = pending
        if (p != null) {
            pending = null
            val di = draftItem
            if (di != null) {
                val edited = Regex("(?:change it to|make it|edit it to|no,? say|no,? tell (?:him|her|them)|instead say|say instead)\\s+(.+)", RegexOption.IGNORE_CASE)
                    .matchEntire(text.trimEnd('.', '!', '?'))
                if (edited != null) { confirmReply(di, edited.groupValues[1].trim()); return }
                draftItem = null
            }
            if (t in YES) {
                if (p.ask != null) { history += "user" to p.ask; askModel() } else say(p.run(), After.WAKE)
                return
            }
            if (t in NO) { say("Understood. Cancelled.", After.WAKE); return }
        }
        if (t in SLEEP) {
            quitting = true
            store.wakeEnabled = false
            say("Going quiet. Switch me back on in my settings whenever you like.", After.WAKE)
            main.postDelayed({ stopSelf() }, 4500)
            return
        }

        history += "user" to text
        Regex("remember (?:that )?(.+)", RegexOption.IGNORE_CASE).matchEntire(text.trimEnd('.'))?.let {
            store.remember(it.groupValues[1]); say("Noted. I'll remember that.", After.WAKE); return
        }
        if (t == "forget everything" || t == "forget all") { store.forgetAll(); say("Memory cleared.", After.WAKE); return }

        val cmdText = when (t) {
            "read them", "read them out", "read them to me" -> "read my notifications"
            "summarize them", "summarise them" -> "summarize my notifications"
            else -> text
        }
        when (val r = actions.handle(cmdText)) {
            is ActionResult.Done -> say(withOverlayNote(r.message), After.WAKE)
            is ActionResult.Confirm -> {
                if (store.sensitiveAuth) {
                    say("This action needs your fingerprint or phone PIN, so I'm opening my screen.", After.WAKE)
                    bringForward("retry", text)
                } else {
                    pending = Pending(r.description, r.run)
                    say(r.description + " Shall I proceed? Say yes or no.", After.LISTEN)
                }
            }
            is ActionResult.ConfirmAsk -> {
                if (store.sensitiveAuth) {
                    say("This action needs your fingerprint or phone PIN, so I'm opening my screen.", After.WAKE)
                    bringForward("retry", text)
                } else {
                    pending = Pending(r.description, ask = r.prompt)
                    say(r.description + " Shall I proceed? Say yes or no.", After.LISTEN)
                }
            }
            is ActionResult.NeedPermission -> {
                say("I need your permission for that, so I'm opening my screen.", After.WAKE)
                bringForward("retry", r.retry)
            }
            is ActionResult.PickFile -> {
                say("Opening my screen so you can choose the file.", After.WAKE)
                bringForward("retry", text)
            }
            is ActionResult.Later -> exec.execute {
                val m = r.work()
                main.post { say(m, After.WAKE) }
            }
            null -> askModel()
        }
    }

    private fun askModel() {
        val lastAsked = history.lastOrNull { it.first == "user" }?.second.orEmpty()
        val noInternet = store.offlineMode || !Net.online(applicationContext)
        Capabilities.refresh(applicationContext)
        val local = brain.answer(Commands.normalize(lastAsked, store.wakeWord), store.ownerName, noInternet)
        if (local != null) { say(local, if (++turns < 6) After.LISTEN else After.WAKE); return }
        if (noInternet) {
            sayError("I'm offline right now. I can still run phone commands and simple questions like the time, date or battery.")
            return
        }
        val cfg = store.aiConfig()
        val owner = store.ownerName
        val mem = store.memories
        val snap = history.takeLast(20)
        exec.execute {
            val r = llm.ask(cfg, owner, mem, snap)
            main.post {
                if (r.ok) say(r.text, if (++turns < 6) After.LISTEN else After.WAKE) else sayError(r.text)
            }
        }
    }

    // ---- Reading notifications aloud and replying ------------------------------------------------

    fun postAnnouncement(item: JarvisNotificationService.Item) {
        main.post {
            if (destroyed || quitting) return@post
            if (!Auth.isUnlocked()) return@post
            if (announceQueue.size < 5) announceQueue.add(item)
            tryAnnounce()
        }
    }

    private fun tryAnnounce(): Boolean {
        if (!Auth.isUnlocked()) { announceQueue.clear(); alertQueue.clear(); return false }
        if (destroyed || quitting || paused || userPaused || st != St.WAKE) return false
        if (alertQueue.isNotEmpty()) {
            val a = alertQueue.removeAt(0)
            main.removeCallbacksAndMessages(null)
            stopRecognizer()
            replyTarget = null
            awaitingReplyText = false
            pending = null
            turns = 0
            callMode = a.call
            st = St.BUSY
            after = if (a.call) After.LISTEN else After.WAKE
            Bridge.post(Msg(false, a.text))
            hud.show(2, a.text)
            voice?.speak(a.text)
            return true
        }
        if (announceQueue.isEmpty()) return false
        if (announceQueue.size >= 3) {
            val perApp = announceQueue.groupingBy { it.app }.eachCount()
            val line = "You have " + announceQueue.size + " new notifications: " +
                perApp.entries.joinToString(", ") { it.value.toString() + " from " + it.key } + ". Say read them, or summarize them."
            announceQueue.clear()
            main.removeCallbacksAndMessages(null)
            stopRecognizer()
            replyTarget = null
            pending = null
            turns = 0
            st = St.BUSY
            after = After.LISTEN
            Bridge.post(Msg(false, line))
            hud.show(2, line)
            voice?.speak(line)
            return true
        }
        val item = announceQueue.removeAt(0)
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        replyTarget = item
        awaitingReplyText = false
        pending = null
        turns = 0
        st = St.BUSY
        val canReply = item.action != null
        after = if (canReply) After.LISTEN else After.WAKE
        val who = item.title.ifBlank { "someone" }
        val body = item.text.take(300)
        Bridge.post(Msg(false, "[" + item.app + "] " + who + ": " + body))
        hud.show(2, item.app + ": " + who + " - " + body)
        voice?.speak(item.app + ", from " + who + ": " + body + "." + if (canReply) " Say reply, followed by your message, or ignore." else "")
        return true
    }

    private fun replyFlow(text: String, t: String): Boolean {
        if (pending != null) return false
        val clean = text.trimEnd('.', '!', '?')
        Regex("(?:reply|respond) to (?:the )?(?:last|latest|recent|that) (?:message|notification)(?: (?:with|saying) (.+))?", RegexOption.IGNORE_CASE)
            .matchEntire(clean)?.let { m ->
                val item = synchronized(JarvisNotificationService.recent) { JarvisNotificationService.recent.firstOrNull { it.action != null } }
                if (item == null) { say("There's no message I can reply to.", After.WAKE); return true }
                val draft = m.groupValues[1].trim()
                if (draft.isEmpty()) {
                    replyTarget = item
                    awaitingReplyText = true
                    say("What should I say to " + item.title.ifBlank { "them" } + "?", After.LISTEN)
                } else confirmReply(item, draft)
                return true
            }
        val target = replyTarget ?: return false
        if (awaitingReplyText) { awaitingReplyText = false; confirmReply(target, text); return true }
        if (t in IGNORE) { replyTarget = null; say("Okay.", After.WAKE); return true }
        if (Regex("(?:suggest|draft|what should i say|write (?:one|something)|reply for me|you reply)(?: a reply)?", RegexOption.IGNORE_CASE)
                .matchEntire(clean) != null) {
            smartDraft(target)
            return true
        }
        if (t in setOf("yes", "reply", "respond", "answer", "yes reply")) {
            awaitingReplyText = true
            say("What should I say?", After.LISTEN)
            return true
        }
        Regex("(?:reply|respond|answer|tell (?:him|her|them)|say|write)(?: that| to (?:him|her|them)| with)?\\s*(.*)", RegexOption.IGNORE_CASE)
            .matchEntire(clean)?.let { m ->
                val draft = m.groupValues[1].trim()
                if (draft.isEmpty()) { awaitingReplyText = true; say("What should I say?", After.LISTEN) }
                else confirmReply(target, draft)
                return true
            }
        replyTarget = null
        return false
    }

    private fun confirmReply(item: JarvisNotificationService.Item, draft: String) {
        replyTarget = null
        if (store.sensitiveAuth) {
            say("Replying to messages needs your fingerprint or phone PIN, which I can't ask for in the background. Please reply from the app.", After.WAKE)
            return
        }
        draftItem = item
        val who = item.title.ifBlank { "them" }
        val line = "I'll reply to " + who + " on " + item.app + ": \"" + draft + "\"."
        pending = Pending(line, run = {
            if (JarvisNotificationService.sendReply(applicationContext, item, draft)) "Sent." else "I couldn't send that reply."
        })
        say("$line Shall I send it?", After.LISTEN)
    }

    // ---- Alerts, incoming calls, smart replies, notification controls ------------------------------

    fun postAlert(text: String, call: Boolean) {
        main.post {
            if (destroyed || quitting || !Auth.isUnlocked()) return@post
            if (alertQueue.size < 5) alertQueue.add(Alert(text, call))
            tryAnnounce()
        }
    }

    /** While a call is ringing, "answer" or "decline" are understood without the word "call". */
    private fun callFlow(t: String): Boolean {
        if (!callMode) return false
        val cmd = when {
            t in setOf("answer", "accept", "pick up", "answer the call", "pick up the call") -> "answer the call"
            t in setOf("decline", "reject", "hang up", "ignore", "decline the call", "reject the call") -> "decline the call"
            else -> return false
        }
        callMode = false
        when (val r = actions.handle(cmd)) {
            is ActionResult.Done -> say(r.message, After.WAKE)
            is ActionResult.NeedPermission -> {
                say("I need the phone permission for that. Opening my screen.", After.WAKE)
                bringForward("retry", cmd)
            }
            else -> say("I couldn't do that.", After.WAKE)
        }
        return true
    }

    /** Asks the AI for a short reply to the message, then goes through the normal "shall I send it?" check. */
    private fun smartDraft(item: JarvisNotificationService.Item) {
        replyTarget = item
        if (!store.smartReplies) {
            say("Smart replies are switched off in my control center. You can say reply, followed by your message.", After.LISTEN)
            return
        }
        if (store.offlineMode || !Net.online(applicationContext)) {
            say("I need the internet to write a reply. You can say reply, followed by your message.", After.LISTEN)
            return
        }
        val chat = synchronized(JarvisNotificationService.recent) {
            JarvisNotificationService.recent.filter { it.pkg == item.pkg && it.title == item.title }.take(4).reversed()
                .joinToString("\n") { it.sender.ifBlank { it.title } + ": " + it.text }
        }
        val prompt = "Write a short, natural reply (one or two casual sentences, first person, no quotation marks) " +
            "that I could send to this message on " + item.app + ". The conversation so far:\n" + chat +
            "\nAnswer with only the text of the reply."
        val cfg = store.aiConfig().copy(liveSearch = false)
        val owner = store.ownerName
        st = St.BUSY
        hud.show(1, "Writing a reply…")
        exec.execute {
            val r = llm.ask(cfg, owner, emptyList(), listOf("user" to prompt))
            main.post {
                if (r.ok) confirmReply(item, r.text.trim().trim('"')) else sayError(r.text)
            }
        }
    }

    /** Stops talking and listening right now (tap on the pill, or the Quiet button in the notification). */
    fun shush() {
        main.post {
            voice?.stopSpeaking()
            voice?.stopListening()
            announceQueue.clear()
            alertQueue.clear()
            endConversation()
        }
    }

    private fun buildNotification(): Notification {
        fun act(code: Int, action: String): PendingIntent = PendingIntent.getService(
            this, code, Intent(this, WakeService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (userPaused) "Jarvis is paused" else "Jarvis is listening for \"$wakeWord\"")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, if (userPaused) "Resume" else "Pause", act(2, ACTION_PAUSE))
            .addAction(0, "Quiet", act(4, ACTION_SHUSH))
            .addAction(0, "Stop", act(1, ACTION_STOP))
            .build()
    }

    private fun notifyListening() {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification())
    }

    private fun withOverlayNote(msg: String): String {
        if (warnedOverlay || Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) return msg
        warnedOverlay = true
        return "$msg If nothing opened, please allow Display over other apps for me in my settings."
    }

    /** Opens the Jarvis screen (needed for permission pop-ups and the file picker). */
    private fun bringForward(key: String, value: String) {
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(key, value)
        if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) {
            startActivity(open)
        } else {
            val pi = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(this, CH_WAKE)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Jarvis needs you")
                .setContentText("Tap to continue")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
        }
    }

    /** The app screen has priority over the microphone while it is open. */
    fun onVisibility(visible: Boolean) {
        main.removeCallbacksAndMessages(null)
        if (visible) {
            paused = true
            stopRecognizer()
            voice?.stopListening()
            voice?.stopSpeaking()
            hud.hide(0)
            st = St.WAKE
            pending = null
        } else {
            paused = false
            st = St.WAKE
            main.postDelayed({ if (!tryAnnounce()) startListening() }, 1200)
        }
    }

    override fun onDestroy() {
        destroyed = true
        hud.hide(0)
        instance = null
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        voice?.shutdown()
        exec.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.jarvis.assistant.STOP_WAKE"
        const val ACTION_PAUSE = "com.jarvis.assistant.PAUSE_WAKE"
        const val ACTION_SHUSH = "com.jarvis.assistant.SHUSH_WAKE"
        private const val CH_LISTEN = "wake_listen"
        private const val CH_WAKE = "wake_heard"
        private val YES = setOf("yes", "yes please", "yep", "yeah", "sure", "ok", "okay", "confirm", "do it", "go ahead", "proceed")
        private val NO = setOf("no", "nope", "cancel", "stop", "never mind", "nevermind", "don't")
        private val IGNORE = setOf("ignore", "skip", "no", "nope", "never mind", "nevermind", "dismiss", "not now")
        private val SLEEP = setOf("go to sleep", "stop listening", "goodbye", "good bye")
        @Volatile var appVisible = false
        private var instance: WakeService? = null

        fun announce(item: JarvisNotificationService.Item) { instance?.postAnnouncement(item) }
        fun alert(text: String) { instance?.postAlert(text, false) }
        fun alertCall(text: String) { instance?.postAlert(text, true) }
        fun markVisible(v: Boolean) { appVisible = v; instance?.onVisibility(v) }
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }
    }
}
