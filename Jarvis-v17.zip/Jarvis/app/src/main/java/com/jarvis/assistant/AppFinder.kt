package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import java.util.Locale

/** Finds installed apps with Android's package manager and matches spoken names ("what's app" finds WhatsApp). */
object AppFinder {
    data class App(val label: String, val pkg: String)

    /** Popular apps and their Play Store ids, used to say "not installed" and offer the Play Store page. */
    private val known = mapOf(
        "whatsapp" to "com.whatsapp", "whatsappbusiness" to "com.whatsapp.w4b",
        "youtube" to "com.google.android.youtube", "chrome" to "com.android.chrome",
        "gmail" to "com.google.android.gm", "maps" to "com.google.android.apps.maps",
        "googlemaps" to "com.google.android.apps.maps", "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana", "messenger" to "com.facebook.orca",
        "telegram" to "org.telegram.messenger", "snapchat" to "com.snapchat.android",
        "tiktok" to "com.zhiliaoapp.musically", "twitter" to "com.twitter.android", "x" to "com.twitter.android",
        "spotify" to "com.spotify.music", "netflix" to "com.netflix.mediaclient",
        "photos" to "com.google.android.apps.photos", "googlephotos" to "com.google.android.apps.photos",
        "drive" to "com.google.android.apps.docs", "meet" to "com.google.android.apps.tachyon",
        "zoom" to "us.zoom.videomeet", "uber" to "com.ubercab", "discord" to "com.discord",
        "linkedin" to "com.linkedin.android", "pinterest" to "com.pinterest", "reddit" to "com.reddit.frontpage",
        "firefox" to "org.mozilla.firefox", "paypal" to "com.paypal.android.p2pmobile"
    )

    fun norm(s: String): String = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    fun knownPackage(query: String): String? = known[norm(query)]

    /** "the whatsapp app" becomes "whatsapp". */
    fun clean(query: String): String {
        var q = query.trim().lowercase(Locale.ROOT)
        q = q.replace(Regex("^(?:the|my|an?)\\s+"), "")
        q = q.replace(Regex("\\s+(?:app|application|please)$"), "")
        return q.trim()
    }

    fun installed(ctx: Context): List<App> {
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return list.map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName) }.distinctBy { it.pkg }
    }

    /** Best matches first. */
    fun find(ctx: Context, query: String): List<App> {
        val q = norm(query)
        if (q.isEmpty()) return emptyList()
        return installed(ctx).map { it to score(norm(it.label), q) }
            .filter { it.second >= 55 }
            .sortedByDescending { it.second }
            .map { it.first }
    }

    /** Names that look a bit like what was said, for "did you mean...". */
    fun suggestions(ctx: Context, query: String): List<String> {
        val q = norm(query)
        if (q.length < 3) return emptyList()
        return installed(ctx).map { it.label to similarity(norm(it.label), q) }
            .filter { it.second >= 0.5 }
            .sortedByDescending { it.second }
            .take(3)
            .map { it.first }
    }

    private fun score(label: String, q: String): Int = when {
        label == q -> 100
        q.length >= 3 && label.startsWith(q) -> 90
        q.length >= 4 && label.length >= 4 && q.startsWith(label) -> 80
        q.length >= 3 && label.contains(q) -> 70
        label.length >= 4 && q.contains(label) -> 65
        else -> {
            val sim = similarity(label, q)
            if (maxOf(label.length, q.length) >= 4 && sim >= 0.75) 40 + (sim * 20).toInt() else 0
        }
    }

    private fun similarity(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        if (m == 0) return 1.0
        return 1.0 - distance(a, b).toDouble() / m
    }

    private fun distance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
