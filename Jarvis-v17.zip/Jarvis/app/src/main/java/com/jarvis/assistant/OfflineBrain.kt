package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/** Answers simple questions using only the phone (no internet). */
class OfflineBrain(private val ctx: Context) {
    private val rx = RegexOption.IGNORE_CASE
    private val jokes = listOf(
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "I would tell you a UDP joke, but you might not get it.",
        "There are ten kinds of people: those who understand binary and those who don't.",
        "My battery and I have something in common. We both run out of energy by evening."
    )

    private fun m(p: String, s: String) = Regex(p, rx).matchEntire(s)

    /**
     * [chatty] is true when no AI is available (offline), so small talk is answered here too.
     * Returns null when this question needs the AI.
     */
    fun answer(text: String, owner: String, chatty: Boolean): String? {
        val t = text.trim().trimEnd('.', '!', '?').trim()
        if (t.isEmpty()) return null
        val who = if (owner.isBlank()) "" else ", $owner"

        m("(?:what(?:'s| is) the time|what time is it|tell me the time|current time|time now)(?: now)?", t)?.let {
            return "It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "."
        }
        m("(?:what(?:'s| is) (?:the )?(?:date|day)(?: today)?|what day is it|today's date|what is today)", t)?.let {
            return "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + "."
        }
        m("(?:what(?:'s| is) )?(?:my |the )?battery(?: level| percentage| status)?|how much battery(?: do i have| is left)?", t)?.let {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            if (level < 0) return "I can't read the battery right now."
            val pct = level * 100 / scale
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            return "Battery is at $pct percent" + (if (charging) " and charging." else ".")
        }
        m("(?:how much |what(?:'s| is) (?:my |the )?)?(?:storage|disk space|free space)(?: do i have| is left| left)?", t)?.let {
            val fs = StatFs(Environment.getDataDirectory().path)
            val free = fs.availableBytes / 1_000_000_000.0
            val total = fs.totalBytes / 1_000_000_000.0
            return "You have " + "%.1f".format(free) + " gigabytes free of " + "%.0f".format(total) + "."
        }
        m("(?:flip|toss) a coin", t)?.let { return if (Random.nextBoolean()) "Heads." else "Tails." }
        m("roll (?:a |the )?(?:dice|die)", t)?.let { return "You rolled a " + (Random.nextInt(6) + 1) + "." }

        Regex("(?:what(?:'s| is)|calculate|compute)?\\s*(-?\\d+(?:\\.\\d+)?)\\s*(plus|\\+|minus|-|times|x|\\*|multiplied by|divided by|/|over)\\s*(-?\\d+(?:\\.\\d+)?)", rx)
            .matchEntire(t)?.let { r ->
                val a = r.groupValues[1].toDouble()
                val b = r.groupValues[3].toDouble()
                val res = when (r.groupValues[2].lowercase(Locale.getDefault())) {
                    "plus", "+" -> a + b
                    "minus", "-" -> a - b
                    "times", "x", "*", "multiplied by" -> a * b
                    else -> if (b == 0.0) return "I can't divide by zero." else a / b
                }
                val shown = if (res == Math.floor(res) && Math.abs(res) < 1e12) res.toLong().toString() else "%.4f".format(res).trimEnd('0').trimEnd('.')
                return "That's $shown."
            }

        m("(?:what (?:commands )?can i say|what are your commands|list (?:the |my )?commands|show (?:the |my )?commands|commands)", t)?.let {
            return "You can say: open WhatsApp, read my screen, scroll down, go back, call someone, set a reminder, " +
                "read my notifications, or search for anything. The full list is in the Command Center."
        }
        if (!chatty) return null
        m("(?:hello|hi|hey|good (?:morning|afternoon|evening))(?: jarvis)?", t)?.let { return "Hello$who. How may I help?" }
        m("how are you(?: doing)?(?: today)?", t)?.let { return "All systems nominal$who." }
        m("(?:thanks|thank you)(?: jarvis)?(?: very much)?", t)?.let { return "You're welcome$who." }
        m("(?:who are you|what(?:'s| is) your name)", t)?.let { return "I'm Jarvis, your personal assistant." }
        m("tell me a joke|say something funny|make me laugh", t)?.let { return jokes.random() }
        m("what can you do(?: offline)?|help|what are your commands", t)?.let {
            return "I can open apps, read what's on your screen, scroll, go back, set alarms, timers and reminders, " +
                "control volume and media, read your notifications, and tell you the time, date, battery and storage. " +
                "With internet I can also chat and search the web."
        }
        return null
    }
}
