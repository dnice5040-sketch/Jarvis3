package com.jarvis.assistant

/** The running conversation, shared by the app screen and the background service so Jarvis keeps its context. */
object Convo {
    val history = mutableListOf<Pair<String, String>>()
}
