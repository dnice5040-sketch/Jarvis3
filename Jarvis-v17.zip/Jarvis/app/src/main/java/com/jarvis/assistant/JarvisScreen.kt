package com.jarvis.assistant

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val Mono = FontFamily.Monospace

@Composable
fun JarvisScreen(vm: JarvisViewModel = viewModel()) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var tabIdx by rememberSaveable { mutableStateOf(0) }
    var showSecurity by remember { mutableStateOf(false) }
    var showControl by remember { mutableStateOf(false) }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleMic() else vm.notify("Microphone permission was denied. I can still read typed commands.")
    }
    fun onMic() {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) vm.toggleMic() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun send() { vm.submit(input); input = "" }

    val wakePerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic) vm.setWake(true) else vm.notify("I need microphone permission to listen for the wake word.")
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        vm.permResult(res.values.any { it })
    }
    LaunchedEffect(vm.permRequest) { vm.permRequest?.let { permLauncher.launch(it.perms.toTypedArray()) } }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        vm.fileChosen(uri, ctx.contentResolver)
    }
    LaunchedEffect(vm.filePick) {
        if (vm.filePick != null) fileLauncher.launch(arrayOf("text/*", "application/json", "application/xml"))
    }
    fun onWakeToggle(on: Boolean) {
        if (!on) { vm.setWake(false); return }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        wakePerms.launch(perms.toTypedArray())
    }

    LaunchedEffect(Unit) { while (true) { vm.tick(); delay(1000) } }
    LaunchedEffect(vm.needDeviceAuth) {
        if (vm.needDeviceAuth) {
            val act = ctx as? FragmentActivity
            if (act != null) DeviceAuth.prompt(act, "Confirm this action") { ok -> vm.deviceAuthResult(ok) }
            else vm.deviceAuthResult(false)
        }
    }
    if (vm.locked) {
        LockScreen(vm)
    } else {
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .background(Brush.radialGradient(colors = listOf(Color(0xFF061428), Color(0xFF01040A)), radius = 1500f))
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("J A R V I S", Modifier.align(Alignment.Center), color = JarvisCyan, fontFamily = Mono,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 3.sp)
                Box(Modifier.align(Alignment.CenterEnd)) { StatusIndicator(vm.status) }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tabIdx) {
                    0 -> HomeTab(vm)
                    1 -> ChatTab(vm)
                    else -> CommandCenterTab(vm) { cmd -> vm.submit(cmd); tabIdx = 0 }
                }
            }
            vm.pending?.let {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.confirmPending() }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text("CONFIRM") }
                    OutlinedButton(onClick = { vm.cancelPending() }, modifier = Modifier.weight(1f)) { Text("CANCEL") }
                }
            }
            if (tabIdx == 1) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Type a message…") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() })
                    )
                    TextButton(onClick = { send() }) { Text("SEND", color = JarvisCyan, fontFamily = Mono) }
                }
            }
            BottomBar(tabIdx, vm.status == Status.LISTENING, { tabIdx = it }, { onMic() }, { showSettings = true })
        }
    }
    }
    if (showSettings && !vm.locked) {
        SettingsDialog(vm, onToggleWake = { onWakeToggle(it) }, onSecurity = { showSecurity = true },
            onControl = { showControl = true }) { showSettings = false }
    }
    if (showControl && !vm.locked) {
        ControlCenterDialog(vm, onToggleWake = { onWakeToggle(it) }, onOpenAi = { showSettings = true }) { showControl = false }
    }
    if (showSecurity && !vm.locked) SecurityDialog(vm) { showSecurity = false }
}

@Composable
fun StatusIndicator(status: Status) {
    val label = when (status) {
        Status.STANDBY -> "STANDBY"; Status.LISTENING -> "LISTENING"
        Status.THINKING -> "PROCESSING"; Status.SPEAKING -> "SPEAKING"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (status == Status.STANDBY) JarvisCyan.copy(alpha = 0.4f) else JarvisCyan))
        Spacer(Modifier.width(6.dp))
        Text(label, color = JarvisCyan, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun ClockBlock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now).uppercase()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(time, color = JarvisText, fontFamily = Mono, fontSize = 30.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp)
        Text(date, color = JarvisCyan.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun ArcReactor(status: Status, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "reactor")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin"
    )
    val pulse by t.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween(if (status == Status.STANDBY) 2200 else 900, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ), label = "pulse"
    )
    val boost = when (status) {
        Status.LISTENING -> 0.15f + level * 0.35f
        Status.SPEAKING -> 0.25f
        Status.THINKING -> 0.1f
        Status.STANDBY -> 0f
    }
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(JarvisCyan.copy(alpha = 0.25f), r * 0.98f, c, style = Stroke(1.5.dp.toPx()))
        drawCircle(JarvisCyan.copy(alpha = 0.12f), r * 0.70f, c, style = Stroke(1.dp.toPx()))
        for (k in 0 until 3) rotate(spin + k * 120f, c) {
            drawArc(JarvisCyan, 0f, 70f, false, Offset(c.x - r * 0.85f, c.y - r * 0.85f),
                Size(r * 1.7f, r * 1.7f), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
        }
        for (k in 0 until 4) rotate(-spin * 1.6f + k * 90f, c) {
            drawArc(JarvisCyan.copy(alpha = 0.7f), 0f, 40f, false, Offset(c.x - r * 0.58f, c.y - r * 0.58f),
                Size(r * 1.16f, r * 1.16f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        val coreR = r * 0.38f * (pulse + boost) * 1.6f
        drawCircle(Brush.radialGradient(listOf(Color.White, JarvisCyan, Color.Transparent), c, coreR), coreR, c)
    }
}

@Composable
fun Waveform(status: Status, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase"
    )
    val amp = when (status) {
        Status.LISTENING -> 0.15f + level * 0.85f
        Status.SPEAKING -> 0.6f
        Status.THINKING -> 0.3f
        Status.STANDBY -> 0.06f
    }
    Canvas(modifier) {
        val n = 36
        val gap = size.width / n
        for (i in 0 until n) {
            val h = (size.height * (0.12f + amp * abs(sin(phase + i * 0.45f)))).coerceAtMost(size.height)
            val x = gap * i + gap / 2
            drawLine(JarvisCyan.copy(alpha = 0.35f + 0.65f * amp.coerceAtMost(1f)),
                Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = gap * 0.5f, cap = StrokeCap.Round)
        }
    }
}

data class Stats(val battery: Float, val memory: Float, val storage: Float)

fun readStats(ctx: Context): Stats {
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) / 100f
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val fs = StatFs(Environment.getDataDirectory().path)
    return Stats(
        bat.coerceIn(0f, 1f),
        (1f - mi.availMem.toFloat() / mi.totalMem.toFloat()).coerceIn(0f, 1f),
        (1f - fs.availableBytes.toFloat() / fs.totalBytes.toFloat()).coerceIn(0f, 1f)
    )
}

@Composable
fun SystemDashboard() {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(readStats(ctx)) }
    LaunchedEffect(Unit) { while (true) { delay(5000); s = readStats(ctx) } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Gauge("PWR", s.battery, Modifier.weight(1f))
        Gauge("MEM", s.memory, Modifier.weight(1f))
        Gauge("DISK", s.storage, Modifier.weight(1f))
    }
}

@Composable
fun Gauge(label: String, value: Float, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, JarvisCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Text("$label ${(value * 100).toInt()}%", color = JarvisCyan, fontFamily = Mono, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = { value }, modifier = Modifier.fillMaxWidth(),
            color = JarvisCyan, trackColor = JarvisCyan.copy(alpha = 0.15f))
    }
}

@Composable
fun Bubble(m: Msg) {
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier.widthIn(max = 300.dp).clip(shape)
                .background(if (m.fromUser) Color(0xFF0B2547) else JarvisPanel)
                .border(1.dp, JarvisCyan.copy(alpha = if (m.fromUser) 0.6f else 0.25f), shape)
                .padding(10.dp)
        ) { Text(m.text, color = JarvisText, fontSize = 14.sp) }
    }
}

@Composable
fun MicButton(listening: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(56.dp).clip(CircleShape)
            .background(if (listening) JarvisCyan else JarvisPanel)
            .border(1.5.dp, JarvisCyan, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(if (listening) "■" else "MIC", color = if (listening) Color.Black else JarvisCyan,
            fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun SettingsDialog(vm: JarvisViewModel, onToggleWake: (Boolean) -> Unit, onSecurity: () -> Unit, onControl: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var prov by remember { mutableStateOf(vm.provider) }
    var key by remember(prov) { mutableStateOf("") }
    var model by remember(prov) { mutableStateOf(vm.modelFor(prov)) }
    var name by remember { mutableStateOf(vm.ownerName) }
    var word by remember { mutableStateOf(vm.wakeWord) }
    var backend by remember { mutableStateOf(vm.backendUrl) }
    var token by remember { mutableStateOf("") }
    fun save() = vm.saveSettings(prov, key, model, name, word, backend, token)

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF071327),
        title = { Text("SYSTEM CONFIG", color = JarvisCyan, fontFamily = Mono) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onControl) { Text("Control center…") }
                OutlinedButton(onClick = onSecurity) { Text("Security & passcode…") }
                Text("AI provider", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AiProvider.values().forEach { p ->
                        if (p == prov) {
                            Button(onClick = { prov = p }, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text(p.short) }
                        } else {
                            OutlinedButton(onClick = { prov = p }, modifier = Modifier.weight(1f)) { Text(p.short) }
                        }
                    }
                }
                OutlinedTextField(key, { key = it }, singleLine = true,
                    label = { Text(if (vm.keySaved(prov)) "${prov.short} API key (saved; paste to replace)" else "${prov.short} API key") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(model, { model = it }, singleLine = true,
                    label = { Text("Model (default: ${vm.defaultModel(prov)})") })
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("What should I call you?") })
                OutlinedTextField(word, { word = it }, singleLine = true, label = { Text("Wake word") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Listen for wake word", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.wakeEnabled, { onToggleWake(it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Continuous conversation", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.continuous, { vm.continuous = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Read notifications aloud", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.readAloud, { vm.updateReadAloud(it) })
                }
                Text("Voice", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("male" to "Male", "female" to "Female").forEach { (g, label) ->
                        if (vm.voiceGender == g) {
                            Button(onClick = { vm.chooseGender(g) }, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text(label) }
                        } else {
                            OutlinedButton(onClick = { vm.chooseGender(g) }, modifier = Modifier.weight(1f)) { Text(label) }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Offline mode (no internet)", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.offlineMode, { vm.updateOffline(it) })
                }
                OutlinedButton(onClick = { vm.cycleVoice() }) { Text("Try another voice (now: " + vm.voiceLabel + ")") }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }) { Text("Allow opening over other apps…") }
                OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                    Text("Notification access…")
                }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }) { Text("Keep me running in background…") }
                Text("Optional secure backend", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                OutlinedTextField(backend, { backend = it }, singleLine = true,
                    label = { Text("Backend URL (https://…, leave empty for direct)") })
                OutlinedTextField(token, { token = it }, singleLine = true,
                    label = { Text("Backend token (paste to set)") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedButton(onClick = { save(); onClose(); vm.testConnection() }) { Text("Save and test connection") }
                Text("Keys are stored encrypted on this phone only. With a backend, the AI key stays on the server instead.",
                    color = JarvisText.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton({ save(); onClose() }) { Text("SAVE") } },
        dismissButton = { TextButton(onClose) { Text("CLOSE") } }
    )
}


// =====================  Hologram look  =====================

private fun fibonacciSphere(n: Int): FloatArray {
    val out = FloatArray(n * 3)
    val golden = Math.PI * (3.0 - Math.sqrt(5.0))
    for (i in 0 until n) {
        val y = 1.0 - (i / (n - 1.0)) * 2.0
        val r = Math.sqrt(1.0 - y * y)
        val th = golden * i
        out[3 * i] = (Math.cos(th) * r).toFloat()
        out[3 * i + 1] = y.toFloat()
        out[3 * i + 2] = (Math.sin(th) * r).toFloat()
    }
    return out
}

@Composable
fun HomeTab(vm: JarvisViewModel) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ClockBlock()
        Spacer(Modifier.height(4.dp))
        HoloHead(vm.status, vm.level, Modifier.weight(1f).fillMaxWidth())
        val last = vm.messages.lastOrNull { !it.fromUser }?.text.orEmpty()
        Text(
            last, color = JarvisText.copy(alpha = 0.85f), fontSize = 15.sp, textAlign = TextAlign.Center,
            maxLines = 3, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp).heightIn(min = 64.dp)
        )
        Waveform(vm.status, vm.level, Modifier.fillMaxWidth().height(28.dp).padding(horizontal = 28.dp))
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ChatTab(vm: JarvisViewModel) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 14.dp), state = listState,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { items(vm.messages) { Bubble(it) } }
}

@Composable
fun HoloSphere(status: Status, level: Float, modifier: Modifier = Modifier) {
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { time.floatValue = it / 1_000_000_000f } } }
    val sphere = remember { fibonacciSphere(420) }
    val noise = remember { FloatArray(900) { kotlin.random.Random(it).nextFloat() } }
    val target = when (status) {
        Status.LISTENING -> 0.25f + level * 0.9f
        Status.SPEAKING -> 0.55f
        Status.THINKING -> 0.35f
        Status.STANDBY -> 0.08f
    }
    val amp by animateFloatAsState(target, label = "amp")
    Canvas(modifier) {
        val t = time.floatValue
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = min(size.width, size.height) / 2f * 0.95f
        val a = if (status == Status.SPEAKING) amp * (0.6f + 0.4f * sin(t * 9f)) else amp

        drawCircle(JarvisCyan.copy(alpha = 0.22f), r * 0.98f, Offset(cx, cy), style = Stroke(1.dp.toPx()))
        drawCircle(JarvisCyan.copy(alpha = 0.12f), r * 0.60f, Offset(cx, cy), style = Stroke(1.dp.toPx()))

        // wobbling particle rings
        val rings = 3
        val per = 300
        val ring = ArrayList<Offset>(rings * per)
        for (k in 0 until rings) {
            val base = r * (0.84f - k * 0.045f)
            for (i in 0 until per) {
                val th = (i / per.toFloat()) * 6.2831855f
                val nz = noise[(k * per + i) % noise.size]
                val wob = a * 0.07f * r * (sin(3f * th + t * 1.3f + k) + 0.6f * sin(5f * th - t * 0.9f))
                val jit = (nz - 0.5f) * r * 0.035f * (1f + a * 2f)
                val rr = base + wob + jit
                ring.add(Offset(cx + rr * cos(th), cy + rr * sin(th)))
            }
        }
        drawPoints(ring, PointMode.Points, JarvisCyan.copy(alpha = 0.85f), 2.4.dp.toPx(), StrokeCap.Round)

        // rotating particle globe
        val rotY = t * (if (status == Status.THINKING) 1.3f else 0.35f)
        val tilt = 0.45f
        val sr = r * 0.42f * (1f + a * 0.10f)
        val cY = cos(rotY); val sY = sin(rotY); val cX = cos(tilt); val sX = sin(tilt)
        val front = ArrayList<Offset>()
        val back = ArrayList<Offset>()
        for (i in 0 until sphere.size / 3) {
            val x = sphere[3 * i]; val y = sphere[3 * i + 1]; val z = sphere[3 * i + 2]
            val x1 = x * cY + z * sY
            val z1 = -x * sY + z * cY
            val y2 = y * cX - z1 * sX
            val z2 = y * sX + z1 * cX
            val p = Offset(cx + x1 * sr, cy + y2 * sr)
            if (z2 > 0f) front.add(p) else back.add(p)
        }
        drawCircle(
            Brush.radialGradient(listOf(JarvisCyan.copy(alpha = 0.30f), Color.Transparent), Offset(cx, cy), sr * 1.35f),
            sr * 1.35f, Offset(cx, cy)
        )
        drawPoints(back, PointMode.Points, JarvisCyan.copy(alpha = 0.30f), 1.6.dp.toPx(), StrokeCap.Round)
        drawPoints(front, PointMode.Points, JarvisCyan.copy(alpha = 0.95f), 2.8.dp.toPx(), StrokeCap.Round)
    }
}

private fun DrawScope.polyline(pts: List<Pair<Float, Float>>, close: Boolean, ox: Float, oy: Float, s: Float) {
    val p = Path()
    pts.forEachIndexed { i, pt ->
        val px = ox + pt.first * s
        val py = oy + pt.second * s
        if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
    }
    if (close) p.close()
    drawPath(p, JarvisCyan.copy(alpha = 0.18f), style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(p, JarvisCyan, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.drawSuit(t: Float) {
    val s = min(size.width / 100f, size.height / 140f) * 0.95f
    val ox = (size.width - 100f * s) / 2f
    val oy = (size.height - 140f * s) / 2f
    fun mir(p: List<Pair<Float, Float>>) = p.map { (100f - it.first) to it.second }

    val head = listOf(50f to 4f, 62f to 6f, 72f to 16f, 78f to 32f, 80f to 50f, 76f to 64f, 70f to 78f, 62f to 92f, 54f to 100f, 50f to 102f)
    polyline(head + mir(head).reversed(), true, ox, oy, s)
    val plate = listOf(50f to 20f, 64f to 26f, 70f to 40f, 68f to 58f, 62f to 72f, 54f to 84f, 50f to 86f)
    polyline(plate + mir(plate).reversed(), true, ox, oy, s)
    val eye = listOf(56f to 44f, 68f to 42f, 70f to 48f, 58f to 52f)
    polyline(eye, true, ox, oy, s)
    polyline(mir(eye), true, ox, oy, s)
    polyline(listOf(42f to 92f, 58f to 92f), false, ox, oy, s)
    polyline(listOf(44f to 98f, 56f to 98f), false, ox, oy, s)
    val shoulder = listOf(38f to 100f, 24f to 106f, 8f to 118f, 0f to 140f)
    polyline(shoulder, false, ox, oy, s)
    polyline(mir(shoulder), false, ox, oy, s)
    val chest = listOf(38f to 100f, 36f to 118f, 30f to 140f)
    polyline(chest, false, ox, oy, s)
    polyline(mir(chest), false, ox, oy, s)

    val c = Offset(ox + 50f * s, oy + 124f * s)
    drawCircle(JarvisCyan.copy(alpha = 0.25f), 13f * s, c, style = Stroke(5.dp.toPx()))
    drawCircle(JarvisCyan, 9f * s, c, style = Stroke(1.6.dp.toPx()))
    drawCircle(JarvisCyan.copy(alpha = 0.8f), 5f * s, c, style = Stroke(1.2.dp.toPx()))
    drawCircle(Brush.radialGradient(listOf(Color.White, JarvisCyan, Color.Transparent), c, 8f * s), 8f * s, c)

    val y = oy + ((t * 0.25f) % 1f) * 140f * s
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, JarvisCyan.copy(alpha = 0.25f)), startY = y - 30f * s, endY = y),
        topLeft = Offset(ox - 10f * s, y - 30f * s), size = Size(120f * s, 30f * s)
    )
    drawLine(JarvisCyan, Offset(ox - 10f * s, y), Offset(ox + 110f * s, y), 1.5.dp.toPx())
}

@Composable
fun SuitTab(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var st by remember { mutableStateOf(readStats(ctx)) }
    LaunchedEffect(Unit) { while (true) { delay(3000); st = readStats(ctx) } }
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { time.floatValue = it / 1_000_000_000f } } }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Canvas(Modifier.weight(1f).fillMaxWidth()) { drawSuit(time.floatValue) }
        Spacer(Modifier.height(8.dp))
        Text("POWER LEVEL  " + "%.1f".format(st.battery * 100f) + "%", color = JarvisCyan, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = { st.battery }, modifier = Modifier.fillMaxWidth(),
            color = JarvisCyan, trackColor = JarvisCyan.copy(alpha = 0.15f))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Gauge("MEM", st.memory, Modifier.weight(1f))
            Gauge("DISK", st.storage, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "AI CORE  " + vm.provider.short.uppercase() + "     WAKE WORD  " + (if (vm.wakeEnabled) "ON" else "OFF"),
            color = JarvisText.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp
        )
        Spacer(Modifier.height(10.dp))
    }
}

private fun DrawScope.drawNavIcon(kind: Int, color: Color) {
    val s = size.minDimension
    val w = s * 0.08f
    val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val c = Offset(s / 2f, s / 2f)
    when (kind) {
        0 -> {
            drawCircle(color, s * 0.42f, c, style = st)
            drawLine(color, c, Offset(c.x, c.y - s * 0.25f), w, StrokeCap.Round)
            drawLine(color, c, Offset(c.x + s * 0.18f, c.y + s * 0.08f), w, StrokeCap.Round)
        }
        1 -> {
            drawRoundRect(color, topLeft = Offset(s * 0.08f, s * 0.12f), size = Size(s * 0.84f, s * 0.6f),
                cornerRadius = CornerRadius(s * 0.14f), style = st)
            val tail = Path()
            tail.moveTo(s * 0.3f, s * 0.72f); tail.lineTo(s * 0.24f, s * 0.92f); tail.lineTo(s * 0.5f, s * 0.72f)
            drawPath(tail, color, style = st)
        }
        2 -> {
            val g = s * 0.36f
            drawRoundRect(color, topLeft = Offset(s * 0.1f, s * 0.1f), size = Size(g, g), cornerRadius = CornerRadius(s * 0.06f), style = st)
            drawRoundRect(color, topLeft = Offset(s * 0.54f, s * 0.1f), size = Size(g, g), cornerRadius = CornerRadius(s * 0.06f), style = st)
            drawRoundRect(color, topLeft = Offset(s * 0.1f, s * 0.54f), size = Size(g, g), cornerRadius = CornerRadius(s * 0.06f), style = st)
            drawRoundRect(color, topLeft = Offset(s * 0.54f, s * 0.54f), size = Size(g, g), cornerRadius = CornerRadius(s * 0.06f), style = st)
        }
        else -> {
            drawCircle(color, s * 0.2f, c, style = st)
            for (k in 0 until 8) {
                val ang = k * 0.7853982f
                drawLine(color, Offset(c.x + s * 0.3f * cos(ang), c.y + s * 0.3f * sin(ang)),
                    Offset(c.x + s * 0.44f * cos(ang), c.y + s * 0.44f * sin(ang)), w * 1.4f, StrokeCap.Round)
            }
        }
    }
}

@Composable
fun NavIcon(selected: Boolean, kind: Int, onClick: () -> Unit) {
    val color = if (selected) JarvisCyan else JarvisCyan.copy(alpha = 0.55f)
    Box(
        Modifier.size(50.dp).clip(CircleShape)
            .then(if (selected) Modifier.border(1.dp, JarvisCyan.copy(alpha = 0.6f), CircleShape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Canvas(Modifier.size(26.dp)) { drawNavIcon(kind, color) } }
}

@Composable
fun MicBig(listening: Boolean, onClick: () -> Unit) {
    val tr = rememberInfiniteTransition(label = "mic")
    val pulse by tr.animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pulse"
    )
    Box(Modifier.size(68.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            if (listening) drawCircle(JarvisCyan.copy(alpha = 0.25f * pulse), r * 0.98f, c)
            drawCircle(JarvisCyan, r * 0.9f, c, style = Stroke(2.dp.toPx()))
            drawCircle(JarvisCyan.copy(alpha = 0.35f), r * 0.74f, c, style = Stroke(1.dp.toPx()))
            val w = r * 0.26f
            drawRoundRect(JarvisCyan, topLeft = Offset(c.x - w / 2f, c.y - r * 0.38f), size = Size(w, r * 0.5f),
                cornerRadius = CornerRadius(w / 2f), style = Stroke(2.dp.toPx()))
            drawArc(JarvisCyan, 0f, 180f, false, Offset(c.x - r * 0.26f, c.y - r * 0.2f), Size(r * 0.52f, r * 0.42f),
                style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            drawLine(JarvisCyan, Offset(c.x, c.y + r * 0.22f), Offset(c.x, c.y + r * 0.38f), 2.dp.toPx())
        }
    }
}

@Composable
fun BottomBar(tab: Int, listening: Boolean, onTab: (Int) -> Unit, onMic: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF040D1C))) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(JarvisCyan.copy(alpha = 0.4f)))
        Row(
            Modifier.fillMaxWidth().height(76.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            NavIcon(tab == 0, 0) { onTab(0) }
            NavIcon(tab == 1, 1) { onTab(1) }
            MicBig(listening, onMic)
            NavIcon(false, 3) { onSettings() }
            NavIcon(tab == 2, 2) { onTab(2) }
        }
    }
}


// =====================  The talking head  =====================

@Composable
fun HoloHead(status: Status, level: Float, modifier: Modifier = Modifier) {
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { time.floatValue = it / 1_000_000_000f } } }
    val target = when (status) {
        Status.LISTENING -> 0.25f + level * 0.9f
        Status.SPEAKING -> 0.6f
        Status.THINKING -> 0.4f
        Status.STANDBY -> 0.08f
    }
    val amp by animateFloatAsState(target, label = "headAmp")
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(Modifier.aspectRatio(1f)) {
            Image(
                painter = painterResource(R.drawable.jarvis_head),
                contentDescription = null,
                modifier = Modifier.fillMaxSize()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            Brush.verticalGradient(0f to Color.Transparent, 0.1f to Color.Black, 0.9f to Color.Black, 1f to Color.Transparent),
                            blendMode = BlendMode.DstIn
                        )
                        drawRect(
                            Brush.horizontalGradient(0f to Color.Transparent, 0.1f to Color.Black, 0.9f to Color.Black, 1f to Color.Transparent),
                            blendMode = BlendMode.DstIn
                        )
                    },
                contentScale = ContentScale.Fit
            )
            Canvas(Modifier.fillMaxSize()) { drawHeadOverlay(time.floatValue, status, amp) }
        }
    }
}

/** Moving parts drawn on top of the head picture: orbiting arcs, scan line, platform pulses and the mouth. */
private fun DrawScope.drawHeadOverlay(t: Float, status: Status, amp: Float) {
    val s = size.width
    val c = Offset(s * 0.5f, s * 0.449f)
    val a = if (status == Status.SPEAKING) amp * (0.6f + 0.4f * sin(t * 9f)) else amp
    val glow = JarvisCyan

    val r1 = s * 0.335f
    rotate(t * 18f, c) {
        drawArc(glow.copy(alpha = 0.18f + 0.3f * a), -25f, 62f, false, Offset(c.x - r1, c.y - r1), Size(2f * r1, 2f * r1),
            style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
        drawArc(glow.copy(alpha = 0.9f), -25f, 62f, false, Offset(c.x - r1, c.y - r1), Size(2f * r1, 2f * r1),
            style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
    }
    val r2 = s * 0.30f
    rotate(-t * 26f, c) {
        drawArc(glow.copy(alpha = 0.35f + 0.4f * a), 150f, 34f, false, Offset(c.x - r2, c.y - r2), Size(2f * r2, 2f * r2),
            style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
    }

    val scanY = s * (0.20f + 0.40f * ((t * 0.35f) % 1f))
    drawLine(glow.copy(alpha = 0.20f + 0.25f * a), Offset(c.x - s * 0.16f, scanY), Offset(c.x + s * 0.16f, scanY), 1.5.dp.toPx())

    for (k in 0 until 3) {
        val ph = (t * 0.45f + k / 3f) % 1f
        val rx = s * (0.08f + 0.30f * ph)
        val ry = rx * 0.16f
        drawOval(glow.copy(alpha = (1f - ph) * 0.55f), Offset(s * 0.5f - rx, s * 0.923f - ry), Size(2f * rx, 2f * ry),
            style = Stroke(1.5.dp.toPx()))
    }

    for (k in 0 until 28) {
        val fx = (k * 0.6180339f) % 1f
        val px = s * (0.12f + 0.76f * fx)
        val py = s * (1f - ((t * 0.04f + k * 0.0357f) % 1f))
        drawCircle(glow.copy(alpha = 0.35f), 1.6.dp.toPx(), Offset(px, py))
    }

    // the mouth: only moves while JARVIS is speaking
    val mouth = if (status == Status.SPEAKING) {
        (0.15f + 0.85f * abs(sin(t * 10.5f) * sin(t * 6.3f + 1f))).coerceIn(0f, 1f) * (0.75f + 0.25f * sin(t * 2.1f))
    } else 0f
    if (mouth > 0.07f) {
        val mx = s * 0.5f
        val my = s * 0.586f
        val hw = s * 0.052f * (0.8f + 0.2f * mouth)
        val hh = s * 0.03f * mouth
        drawOval(Color(0xFF010A1C).copy(alpha = 0.88f), Offset(mx - hw, my - hh), Size(2f * hw, 2f * hh))
        drawOval(glow.copy(alpha = 0.85f), Offset(mx - hw, my - hh), Size(2f * hw, 2f * hh), style = Stroke(1.4.dp.toPx()))
        for (k in 0 until 8) {
            val px = mx + hw * (-0.7f + 0.2f * k)
            val py = my + hh * 0.5f * sin(k * 1.7f + t * 5f)
            drawCircle(glow.copy(alpha = 0.5f), 1.2.dp.toPx(), Offset(px, py))
        }
    }
}


// =====================  Command Center (the inside of the app)  =====================

private data class Dash(
    val online: Boolean,
    val st: Stats,
    val feed: List<Pair<String, String>>,
    val reminders: List<Reminders.R>,
    val memories: List<String>
)

private fun readDash(ctx: Context, store: SecureStore): Dash {
    val feed = synchronized(JarvisNotificationService.recent) {
        JarvisNotificationService.recent.take(4).map { n ->
            (n.app + ": " + n.title.ifBlank { n.text }) to (if (n.action != null) "REPLY" else "INFO")
        }
    }
    val rem = Reminders.all(ctx).sortedBy { it.at }.take(4)
    return Dash(Net.online(ctx), readStats(ctx), feed, rem, store.memories)
}

private fun inText(ms: Long): String {
    val m = (ms / 60000L).coerceAtLeast(0L)
    return when {
        m < 60L -> "in " + m + " min"
        m < 1440L -> "in " + (m / 60L) + "h " + (m % 60L) + "m"
        else -> "in " + (m / 1440L) + " d"
    }
}

@Composable
fun Panel(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(Color(0xFF071A33).copy(alpha = 0.85f))
            .border(1.dp, JarvisCyan.copy(alpha = 0.35f), shape).padding(12.dp)
    ) {
        Text(title, color = JarvisText.copy(alpha = 0.8f), fontFamily = Mono, fontSize = 10.sp,
            letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun StatusRow(title: String, sub: String, dot: Color, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0A2244).copy(alpha = 0.6f)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = JarvisText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = dot, fontSize = 11.sp)
        }
    }
}

@Composable
fun StatusChip(text: String, color: Color, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier.clip(shape).border(1.dp, color.copy(alpha = 0.6f), shape).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, color = JarvisText, fontFamily = Mono, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun FeedRow(text: String, tag: String, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0A2244).copy(alpha = 0.6f)).padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, Modifier.weight(1f), color = JarvisText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.width(8.dp))
        Text(tag, color = JarvisCyan, fontFamily = Mono, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun QuickButton(text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0A2244).copy(alpha = 0.6f)).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(JarvisCyan))
        Spacer(Modifier.width(10.dp))
        Text(text, color = JarvisText, fontSize = 13.sp)
    }
}

@Composable
fun RingGauge(label: String, value: Float, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(78.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = 7.dp.toPx()
                val inset = w / 2f
                val box = Size(size.width - w, size.height - w)
                drawArc(JarvisCyan.copy(alpha = 0.15f), 135f, 270f, false, Offset(inset, inset), box,
                    style = Stroke(w, cap = StrokeCap.Round))
                drawArc(JarvisCyan, 135f, 270f * value.coerceIn(0f, 1f), false, Offset(inset, inset), box,
                    style = Stroke(w, cap = StrokeCap.Round))
            }
            Text("" + (value * 100f).toInt() + "%", color = JarvisText, fontSize = 13.sp, fontFamily = Mono)
        }
        Text(label, color = JarvisText.copy(alpha = 0.7f), fontSize = 11.sp, fontFamily = Mono)
    }
}

@Composable
fun Constellation(modifier: Modifier = Modifier) {
    val pts = remember { listOf(0.08f to 0.7f, 0.22f to 0.35f, 0.38f to 0.6f, 0.52f to 0.25f, 0.66f to 0.55f, 0.82f to 0.3f, 0.92f to 0.7f) }
    Canvas(modifier) {
        for (i in 0 until pts.size - 1) {
            drawLine(JarvisCyan.copy(alpha = 0.35f),
                Offset(size.width * pts[i].first, size.height * pts[i].second),
                Offset(size.width * pts[i + 1].first, size.height * pts[i + 1].second), 1.dp.toPx())
        }
        for (p in pts) drawCircle(JarvisCyan, 3.dp.toPx(), Offset(size.width * p.first, size.height * p.second))
    }
}

@Composable
fun CommandCenterTab(vm: JarvisViewModel, onCommand: (String) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    var d by remember { mutableStateOf(readDash(ctx, store)) }
    LaunchedEffect(Unit) { while (true) { delay(3000); d = readDash(ctx, store) } }
    val good = Color(0xFF2EE6A6)
    val warn = Color(0xFFFFB020)
    val dim = Color(0xFF6C7A92)
    val hasKey = (if (store.provider == AiProvider.GEMINI) store.geminiKey else store.apiKey).isNotBlank()
    val aiOn = !vm.offlineMode && d.online && (hasKey || store.backendUrl.isNotBlank())
    val listenerOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val overlayOk = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ClockBlock()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusChip(if (aiOn) "SYSTEM OPTIMAL" else "LIMITED MODE", if (aiOn) good else warn)
            StatusChip(if (vm.offlineMode) "OFFLINE MODE" else if (d.online) "ONLINE" else "NO NETWORK",
                if (!vm.offlineMode && d.online) good else warn)
        }

        StatusChip("VERIFIED - auto-lock " + store.timeoutMin + " min", good)
        Panel("AI CORE OVERVIEW") {
            StatusRow("AI Core",
                if (vm.offlineMode) "Offline brain" else vm.provider.short + (if (hasKey) " - active" else " - no key"),
                if (aiOn) good else warn)
            StatusRow("Memory", "" + d.memories.size + " stored", good)
            StatusRow("Voice", (if (vm.wakeEnabled) "Wake word on" else "Wake word off") + " - " + vm.voiceGender,
                if (vm.wakeEnabled) good else dim)
            StatusRow("Network", if (vm.offlineMode) "Offline mode" else if (d.online) "Connected" else "No connection",
                if (!vm.offlineMode && d.online) good else warn)
        }

        Panel("LIVE INTELLIGENCE FEED") {
            if (d.feed.isEmpty()) {
                Text("No new activity", color = JarvisText.copy(alpha = 0.6f), fontSize = 12.sp)
            } else {
                d.feed.forEach { FeedRow(it.first, it.second) }
            }
        }

        Panel("MISSION TIMELINE") {
            if (d.reminders.isEmpty()) {
                Text("No reminders. Say: remind me to call Ada at 5 pm.", color = JarvisText.copy(alpha = 0.6f), fontSize = 12.sp)
            } else {
                val fmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
                d.reminders.forEach { r ->
                    FeedRow(fmt.format(Date(r.at)) + "  " + r.text, inText(r.at - System.currentTimeMillis()))
                }
            }
        }

        Panel("QUICK COMMANDS") {
            QuickButton("Read my notifications") { onCommand("read my notifications") }
            QuickButton("Summarize my notifications") { onCommand("summarize my notifications") }
            QuickButton("What are my reminders") { onCommand("what are my reminders") }
            QuickButton("Where am I") { onCommand("where am i") }
            QuickButton("What time is it") { onCommand("what time is it") }
        }

        Panel("SYSTEM MONITOR") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RingGauge("PWR", d.st.battery)
                RingGauge("RAM", d.st.memory)
                RingGauge("DISK", d.st.storage)
            }
        }

        Panel("MEMORY INSIGHTS") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Constellation(Modifier.weight(1f).height(70.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Memories", color = JarvisText.copy(alpha = 0.7f), fontSize = 11.sp)
                    Text("" + d.memories.size, color = JarvisCyan, fontSize = 22.sp, fontFamily = Mono)
                }
            }
            if (d.memories.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(d.memories.last(), color = JarvisText.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }

        Panel("AI PROVIDERS") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusRow("Gemini", if (store.geminiKey.isNotBlank()) "Connected" else "Not linked",
                    if (store.geminiKey.isNotBlank()) good else dim, Modifier.weight(1f))
                StatusRow("Claude", if (store.apiKey.isNotBlank()) "Connected" else "Not linked",
                    if (store.apiKey.isNotBlank()) good else dim, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusRow("Backend", if (store.backendUrl.isNotBlank()) "Connected" else "None",
                    if (store.backendUrl.isNotBlank()) good else dim, Modifier.weight(1f))
                StatusRow("Offline brain", "Ready", good, Modifier.weight(1f))
            }
        }

        Panel("VOICE COMMANDS (say Jarvis first)") {
            CommandHelp.groups.forEach { (title, lines) ->
                Text(title, color = JarvisCyan, fontFamily = Mono, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(lines.joinToString("\n"), color = JarvisText.copy(alpha = 0.85f), fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
            }
        }
        Panel("ACTIVE MODULES") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusRow("Wake word", if (vm.wakeEnabled) "Active" else "Standby", if (vm.wakeEnabled) good else dim, Modifier.weight(1f))
                StatusRow("Reader", if (vm.readAloud && listenerOn) "Active" else if (vm.readAloud) "Needs access" else "Standby",
                    if (vm.readAloud && listenerOn) good else if (vm.readAloud) warn else dim, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusRow("Reminders", "" + d.reminders.size + " scheduled", if (d.reminders.isNotEmpty()) good else dim, Modifier.weight(1f))
                StatusRow("Phone control", if (overlayOk) "Ready" else "Allow overlay", if (overlayOk) good else warn, Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}


// =====================  Security  =====================

@Composable
fun LockScreen(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var code by remember { mutableStateOf("") }
    var code2 by remember { mutableStateOf("") }
    val first = !vm.passcodeSet
    val activity = ctx as? FragmentActivity
    Column(
        Modifier.fillMaxSize().background(Color(0xFF01040A)).statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(48.dp))
        Text("J A R V I S", color = JarvisCyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 26.sp, letterSpacing = 4.sp)
        Text(if (first) "CREATE YOUR PASSCODE" else "SECURITY VERIFICATION REQUIRED", color = JarvisText,
            fontFamily = Mono, fontSize = 12.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center)
        if (first) {
            Text("Choose a word you can say out loud. It is stored encrypted on this phone only and is never sent anywhere.",
                color = JarvisText.copy(alpha = 0.7f), fontSize = 12.sp, textAlign = TextAlign.Center)
            OutlinedTextField(code, { code = it }, singleLine = true, label = { Text("New passcode") },
                visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(code2, { code2 = it }, singleLine = true, label = { Text("Repeat passcode") },
                visualTransformation = PasswordVisualTransformation())
            Button(onClick = { vm.createPasscode(code, code2); code = ""; code2 = "" },
                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text("SAVE PASSCODE") }
        } else {
            OutlinedTextField(code, { code = it }, singleLine = true, label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { vm.tryPasscode(code); code = "" }))
            Button(onClick = { vm.tryPasscode(code); code = "" },
                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text("UNLOCK") }
            OutlinedButton(onClick = { vm.startVoiceAuth() }) { Text("SPEAK THE PASSWORD") }
            if (vm.bioAllowed && activity != null) {
                OutlinedButton(onClick = { DeviceAuth.prompt(activity, "Unlock Jarvis") { ok -> vm.biometricResult(ok) } }) {
                    Text("USE FINGERPRINT OR PHONE PIN")
                }
            }
        }
        val note = if (vm.lockSecs > 0L) "Too many wrong attempts. Try again in " + minutesText(vm.lockSecs) + "." else vm.authMessage
        if (note.isNotEmpty()) {
            Text(note, color = Color(0xFFFFB020), fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        if (vm.status == Status.LISTENING) {
            Text("Listening…", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
        }
    }
}

@Composable
fun SecurityDialog(vm: JarvisViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore(ctx) }
    var cur by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var timeout by remember { mutableStateOf(store.timeoutMin) }
    var bio by remember { mutableStateOf(store.bioUnlock) }
    var sens by remember { mutableStateOf(store.sensitiveAuth) }
    val bioAvail = remember { DeviceAuth.available(ctx) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF071327),
        title = { Text("SECURITY", color = JarvisCyan, fontFamily = Mono) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Session: VERIFIED. Auto-locks after $timeout min without use, and whenever Jarvis restarts.",
                    color = JarvisText.copy(alpha = 0.8f), fontSize = 12.sp)
                Text("Auto-lock after", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1, 5, 15, 30).forEach { mins ->
                        if (timeout == mins) {
                            Button(onClick = { }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text("" + mins) }
                        } else {
                            OutlinedButton(onClick = { store.timeoutMin = mins; timeout = mins; Auth.touch() },
                                modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("" + mins) }
                        }
                    }
                }
                Text("Change passcode", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                OutlinedTextField(cur, { cur = it }, singleLine = true, label = { Text("Current passcode") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(n1, { n1 = it }, singleLine = true, label = { Text("New passcode") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(n2, { n2 = it }, singleLine = true, label = { Text("Repeat new passcode") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedButton(onClick = {
                    msg = vm.changePasscode(cur, n1, n2)
                    if (msg == "Passcode changed.") { cur = ""; n1 = ""; n2 = "" }
                }) { Text("Change passcode") }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Allow fingerprint / phone PIN to unlock", Modifier.weight(1f), color = JarvisText, fontSize = 13.sp)
                    Switch(bio, { store.bioUnlock = it; bio = it; vm.refreshSecurityUi() }, enabled = bioAvail)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ask for fingerprint / phone PIN before sensitive actions (calls, texts, replies)",
                        Modifier.weight(1f), color = JarvisText, fontSize = 13.sp)
                    Switch(sens, { store.sensitiveAuth = it; sens = it }, enabled = bioAvail)
                }
                if (!bioAvail) {
                    Text("Set a screen lock or fingerprint in Android settings to use these two options.",
                        color = JarvisText.copy(alpha = 0.6f), fontSize = 12.sp)
                }
                OutlinedButton(onClick = { Auth.lock(); vm.tick(); onClose() }) { Text("Lock now") }
                if (msg.isNotEmpty()) Text(msg, color = Color(0xFFFFB020), fontSize = 13.sp)
            }
        },
        confirmButton = { TextButton(onClose) { Text("CLOSE") } }
    )
}
