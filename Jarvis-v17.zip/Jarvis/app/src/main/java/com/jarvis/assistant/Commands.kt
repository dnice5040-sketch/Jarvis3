package com.jarvis.assistant

/** Turns what the microphone heard into clean commands: removes "Jarvis," and "please", and splits chains. */
object Commands {
    private val rx = RegexOption.IGNORE_CASE

    private const val VERBS = "open|launch|start|go|tell|read|scroll|tap|click|press|turn|set|call|text|message|search|show|take|" +
        "describe|what|summari[sz]e|come|return|check|test|answer|decline|remind|google|play|pause|volume|silent|lock|look"

    private val splitter = Regex(
        "\\s*(?:,\\s*)?(?:and then|and also|and|then|after that|afterwards)\\s+(?=(?:$VERBS)\\b)", rx
    )

    /** These start a single command whose text may itself contain "and", so they are never split. */
    private val noSplit = Regex("^(?:remind|text|message|sms|search|google|look up|call|dial|send)\\b", rx)

    fun normalize(raw: String, wakeWord: String): String {
        var s = raw.trim().replace('\u2019', '\'').replace('\u2018', '\'')
        val name = Regex.escape(wakeWord.trim().ifEmpty { "jarvis" })
        val strip = listOf(
            "^(?:(?:hey|ok|okay|hi|hello)[,\\s]+)?(?:jarvis|$name)\\b[,.!:\\s]*",
            "^(?:please|kindly)[,\\s]+",
            "^(?:could|can|would|will) you (?:please )?",
            "^i (?:want|need|would like) you to ",
            "^(?:go ahead and|just) "
        )
        var changed = true
        while (changed) {
            changed = false
            for (p in strip) {
                val n = s.replace(Regex(p, rx), "").trim()
                if (n != s) { s = n; changed = true }
            }
        }
        s = s.replace(Regex("[,\\s]+(?:please|for me)$", rx), "")
        return s.trim().trimEnd('.', '!', '?', ',').trim()
    }

    fun split(s: String): List<String> {
        if (noSplit.containsMatchIn(s)) return listOf(s)
        val parts = s.split(splitter).map { it.trim().trimEnd(',').trim() }.filter { it.isNotEmpty() }
        return if (parts.size <= 1) listOf(s) else parts
    }
}
