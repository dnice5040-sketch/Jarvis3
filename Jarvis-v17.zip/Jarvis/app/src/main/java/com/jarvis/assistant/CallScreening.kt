package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat

/**
 * Android's official call-screening hook. It can only allow, silence or reject an incoming call and tell
 * Jarvis about it. It cannot talk to the caller, and Jarvis never records calls or speaks as the owner.
 * It only works after the owner makes Jarvis the "Caller ID & spam" app in Android settings.
 */
class JarvisCallScreening : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val builder = CallResponse.Builder()
        try {
            val incoming = Build.VERSION.SDK_INT < 29 || callDetails.callDirection == Call.Details.DIRECTION_INCOMING
            if (incoming) {
                val ctx = applicationContext
                val store = SecureStore.of(ctx)
                val number = callDetails.handle?.schemeSpecificPart.orEmpty()
                val canLookup = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
                val who = if (canLookup) CallRules.lookup(ctx, number) else null
                val known = who != null
                if (store.busyMode && canLookup && !known) {
                    when (store.busyCallRule) {
                        "reject" -> {
                            builder.setDisallowCall(true).setRejectCall(true)
                            History.log(ctx, "Busy mode: rejected a call from " + number.ifEmpty { "a hidden number" })
                        }
                        "silence" -> if (Build.VERSION.SDK_INT >= 29) {
                            builder.setSilenceCall(true)
                            History.log(ctx, "Busy mode: silenced a call from " + number.ifEmpty { "a hidden number" })
                        }
                    }
                } else {
                    val label = who?.first ?: number.ifEmpty { "an unknown caller" }
                    WakeService.alertCall("Incoming call from $label. Say answer or decline.")
                    if (known && who?.second == true && store.autoAnswer &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
                    ) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            try { (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall() } catch (e: Exception) { }
                        }, 1500L)
                        History.log(ctx, "Auto-answered a call from $label")
                    }
                }
            }
        } catch (e: Exception) { }
        respondToCall(callDetails, builder.build())
    }
}

object CallRules {
    /** Contact name and whether it is a starred contact, or null if the number is not in the contacts. */
    fun lookup(ctx: Context, number: String): Pair<String, Boolean>? {
        if (number.isEmpty()) return null
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        val cols = arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup.STARRED)
        ctx.contentResolver.query(uri, cols, null, null, null)?.use {
            if (it.moveToFirst()) return Pair(it.getString(0) ?: "a contact", it.getInt(1) == 1)
        }
        return null
    }
}
