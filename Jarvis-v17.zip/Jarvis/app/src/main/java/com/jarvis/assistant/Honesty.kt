package com.jarvis.assistant

import android.content.Context

/** What the AI is told about the phone right now, so it never has to guess what Jarvis can do. */
object Capabilities {
    @Volatile var summary: String = ""

    fun refresh(ctx: Context) {
        val screen = if (JarvisAccessibilityService.instance != null) "ON" else "OFF"
        summary = " Right now screen control (Accessibility) is $screen."
    }
}

/** Safety net: stops the AI from claiming limits that are not true (like "optical sensors"). */
object Honesty {
    private val falseClaims = Regex(
        "optical sensor|cannot reach (?:my|your) display|no access to (?:your|the) (?:screen|display)|" +
            "(?:cannot|can't|unable to|not able to) (?:directly )?(?:launch|open) (?:any )?(?:applications|apps)",
        RegexOption.IGNORE_CASE
    )

    fun fix(text: String): String =
        if (falseClaims.containsMatchIn(text)) {
            "I can open apps and read the screen on this phone. Try saying \"open WhatsApp\" or \"read my screen\". " +
                "If that doesn't work, check that Jarvis screen control is switched on in the Control Center."
        } else text
}
