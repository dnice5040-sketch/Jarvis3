package com.jarvis.assistant

import android.content.Context

object Control {
    /** Switches every background activity off at once. Reminders you created yourself stay scheduled. */
    fun stopAll(ctx: Context) {
        val s = SecureStore.of(ctx)
        s.readAloud = false
        s.busyMode = false
        s.autoReply = false
        s.autoAnswer = false
        s.briefingOn = false
        s.proactiveOn = false
        s.wakeEnabled = false
        WakeService.stop(ctx)
        Proactive.cancel(ctx)
        History.log(ctx, "Emergency stop: all background activity switched off")
    }
}
