package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AiProvider(val label: String, val short: String) {
    GEMINI("Google Gemini", "Gemini"),
    CLAUDE("Anthropic Claude", "Claude")
}

data class AiResult(val ok: Boolean, val text: String)

data class AiConfig(
    val provider: AiProvider,
    val key: String,
    val model: String,
    val backendUrl: String,
    val backendToken: String,
    val liveSearch: Boolean = true
)

/** Talks to Gemini or Claude, directly (key on this phone) or through your own https backend. Call off the main thread. */
class LlmClient {
    companion object {
        const val GEMINI_MODEL = "gemini-3.5-flash-lite"
        const val CLAUDE_MODEL = "claude-sonnet-5-5"
        private const val GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
        private const val CLAUDE_URL = "https://api.anthropic.com/v1/messages"
        fun defaultModel(p: AiProvider) = if (p == AiProvider.GEMINI) GEMINI_MODEL else CLAUDE_MODEL
    }

    private class Http(val code: Int, val body: String)

    private fun system(owner: String, memories: List<String>, search: Boolean): String {
        val who = if (owner.isBlank()) "user" else owner
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        val mem = if (memories.isEmpty()) "" else
            "\nThings the user asked you to remember:\n" + memories.joinToString("\n") { "- $it" }
        val web = if (search) " When a question needs current or factual information (news, weather, scores, prices, opening hours, schedules), use live web search and answer with the key facts in a sentence or two." else ""
        return """You are Jarvis, a calm, professional, slightly witty personal AI assistant living on $who's Android phone. Address the person as "$who". Your replies are spoken aloud, so keep them short (1-3 sentences unless asked for more), in plain text with no markdown. Be proactive but never intrusive. You run inside an Android app on the user's own phone, and the app can really open installed apps, read the visible text on the screen, scroll, press back and home, tap buttons, set alarms and reminders, read notifications, and place calls or send messages after the user confirms. Screen features need Accessibility switched on in the app's Control Center.${Capabilities.summary} You have no cameras or "optical sensors" and must never claim science-fiction limits. The app runs phone commands before you are asked, so if you are being asked about one, it was not understood: say so plainly and give a short phrase to try, such as "open WhatsApp" or "read my screen". Never claim to have done an action you did not do.$web Current local date and time: $now.$mem"""
    }

    /** Roles must start with "user" and alternate; merge neighbours with the same role. */
    private fun normalize(h: List<Pair<String, String>>): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        for ((role, text) in h) {
            if (text.isBlank()) continue
            if (out.isEmpty() && role != "user") continue
            if (out.isNotEmpty() && out.last().first == role) {
                out[out.lastIndex] = role to (out.last().second + "\n" + text)
            } else out += role to text
        }
        return out
    }

    fun ask(cfg: AiConfig, owner: String, memories: List<String>, history: List<Pair<String, String>>): AiResult {
        val turns = normalize(history)
        if (turns.isEmpty()) return AiResult(false, "I have nothing to send yet.")
        val sys = system(owner, memories, cfg.liveSearch)
        val viaBackend = cfg.backendUrl.isNotBlank()
        if (!viaBackend && cfg.key.isBlank()) {
            return AiResult(false, "No ${cfg.provider.short} API key is set. Tap the gear icon and paste your key.")
        }
        val out = try {
            when {
                viaBackend -> backend(cfg, sys, turns)
                cfg.provider == AiProvider.GEMINI -> gemini(cfg, sys, turns)
                else -> claude(cfg, sys, turns)
            }
        } catch (e: UnknownHostException) {
            AiResult(false, "I can't reach the internet right now. Please check your connection.")
        } catch (e: SocketTimeoutException) {
            AiResult(false, "The AI service took too long to answer. Please try again.")
        } catch (e: IOException) {
            AiResult(false, "A network problem interrupted the request. Please try again.")
        } catch (e: Exception) {
            AiResult(false, "Something went wrong while reading the AI response.")
        }
        return if (out.ok) AiResult(true, Honesty.fix(out.text)) else out
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Http {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 75000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Http(code, text)
        } finally {
            c.disconnect()
        }
    }

    // ---- Google Gemini (key sent in the x-goog-api-key header, never in the URL) -----------------

    private fun gemini(cfg: AiConfig, sys: String, turns: List<Pair<String, String>>): AiResult {
        val contents = JSONArray()
        turns.forEach { (role, text) ->
            contents.put(
                JSONObject().put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        fun build(fast: Boolean, search: Boolean): JSONObject {
            val b = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents)
            // Low "thinking" keeps spoken replies quick; retried without it if the model rejects the option.
            if (fast) b.put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", "low")))
            if (search) b.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            return b
        }
        val chosen = cfg.model.trim().takeIf { Regex("[A-Za-z0-9._-]+").matches(it) } ?: GEMINI_MODEL
        // Each model has its own quota, so if one is used up (429), gone (404) or busy (503) try the next.
        val models = listOf(chosen, "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.8-flash").distinct()
        val headers = mapOf("x-goog-api-key" to cfg.key)
        var failed: Http? = null
        for (model in models) {
            val url = GEMINI_BASE + model + ":generateContent"
            var r = post(url, headers, build(true, cfg.liveSearch))
            if (r.code == 400 && r.body.contains("thinking", true)) r = post(url, headers, build(false, cfg.liveSearch))
            // Search has limits of its own: if it is the problem, ask again without it.
            if (cfg.liveSearch && (
                    r.code == 429 ||
                    (r.code in 400..404 && (r.body.contains("search", true) || r.body.contains("tool", true) || r.body.contains("ground", true)))
                )
            ) r = post(url, headers, build(true, false))
            if (r.code in 200..299) return parseGemini(r.body)
            failed = r
            if (r.code != 429 && r.code != 404 && r.code != 503) break
        }
        val lastError = failed ?: return AiResult(false, "Gemini did not answer.")
        val more = if (models.size > 1 && (lastError.code == 429 || lastError.code == 404 || lastError.code == 503)) " I also tried other Gemini models." else ""
        return AiResult(false, explain(lastError, "Gemini") + more)
    }

    private fun parseGemini(body: String): AiResult {
        val j = JSONObject(body)
        val cands = j.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return AiResult(false, if (reason.isNotEmpty()) "Gemini declined that request ($reason)." else "Gemini returned no answer.")
        }
        val cand = cands.getJSONObject(0)
        val parts = cand.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
            }
        }
        val text = sb.toString().trim()
        if (text.isEmpty()) {
            val fr = cand.optString("finishReason")
            return AiResult(false, "Gemini returned an empty answer" + if (fr.isNotEmpty()) " ($fr)." else ".")
        }
        return AiResult(true, text)
    }

    // ---- Anthropic Claude --------------------------------------------------------------------------

    private fun claude(cfg: AiConfig, sys: String, turns: List<Pair<String, String>>): AiResult {
        val msgs = JSONArray()
        turns.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("content", text)) }
        fun build(search: Boolean): JSONObject {
            val b = JSONObject().put("model", cfg.model.ifBlank { CLAUDE_MODEL }).put("max_tokens", if (search) 900 else 400)
                .put("system", sys).put("messages", msgs)
            if (search) b.put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)))
            return b
        }
        val hdr = mapOf("x-api-key" to cfg.key, "anthropic-version" to "2023-06-01")
        var r = post(CLAUDE_URL, hdr, build(cfg.liveSearch))
        if (cfg.liveSearch && r.code in 400..404 && (r.body.contains("search", true) || r.body.contains("tool", true))) {
            r = post(CLAUDE_URL, hdr, build(false))
        }
        if (r.code !in 200..299) return AiResult(false, explain(r, "Claude"))
        val blocks = JSONObject(r.body).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        val text = sb.toString().trim()
        return if (text.isEmpty()) AiResult(false, "Claude returned an empty answer.") else AiResult(true, text)
    }

    // ---- Your own backend (the API key lives on the server, not on the phone) -----------------------

    private fun backend(cfg: AiConfig, sys: String, turns: List<Pair<String, String>>): AiResult {
        if (!cfg.backendUrl.startsWith("https://")) {
            return AiResult(false, "The backend address must start with https:// for security.")
        }
        val msgs = JSONArray()
        turns.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("text", text)) }
        val body = JSONObject().put("provider", cfg.provider.name.lowercase())
            .put("model", cfg.model).put("system", sys).put("messages", msgs).put("liveSearch", cfg.liveSearch)
        val headers = if (cfg.backendToken.isBlank()) emptyMap() else mapOf("x-app-token" to cfg.backendToken)
        val r = post(cfg.backendUrl, headers, body)
        if (r.code !in 200..299) return AiResult(false, explain(r, cfg.provider.short))
        val text = JSONObject(r.body).optString("text").trim()
        return if (text.isEmpty()) AiResult(false, "The backend returned an empty answer.") else AiResult(true, text)
    }

    // ---- Friendly errors ------------------------------------------------------------------------------

    private fun explain(r: Http, name: String): String {
        val err = try { JSONObject(r.body).optJSONObject("error") } catch (e: Exception) { null }
        val status = err?.optString("status").orEmpty()
        val msg = err?.optString("message").orEmpty()
        val badKey = msg.contains("API key", true) &&
            (msg.contains("not valid", true) || msg.contains("invalid", true) || msg.contains("expired", true))
        return when {
            r.code == 401 || badKey || status == "UNAUTHENTICATED" ->
                "$name rejected the API key. It looks invalid or expired. Open settings and paste it again."
            r.code == 403 || status == "PERMISSION_DENIED" ->
                "$name denied access. The key may be restricted or not allowed to use this service."
            r.code == 429 || status == "RESOURCE_EXHAUSTED" -> {
                val lim = Regex("limit:\\s*(\\d+)").find(msg)?.groupValues?.get(1)
                val mod = Regex("model:\\s*([\\w.\\-]+)").find(msg)?.groupValues?.get(1)
                val detail = if (lim != null && mod != null)
                    " (limit " + lim + " on " + mod + (if (lim == "0") ": your plan has no quota for it" else "") + ")" else ""
                "$name says the quota or rate limit has been reached$detail. Wait a minute, or check your plan and billing."
            }
            r.code == 404 ->
                "$name could not find that model. It may have been retired; clear or change the model name in settings."
            r.code == 400 ->
                "$name rejected the request." + if (msg.isNotEmpty()) " " + msg.take(140) else ""
            r.code >= 500 ->
                "$name is temporarily unavailable (error ${r.code}). Please try again shortly."
            else -> "$name returned error ${r.code}."
        }
    }
}
