package com.jarvis.assistant

import android.Manifest
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

private val CcMono = FontFamily.Monospace

private data class PermState(
    val mic: Boolean, val post: Boolean, val contacts: Boolean, val answer: Boolean, val call: Boolean,
    val overlay: Boolean, val listener: Boolean, val access: Boolean, val role: Boolean,
    val dnd: Boolean, val battery: Boolean
)

private fun readPerms(ctx: Context): PermState {
    fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val role = Build.VERSION.SDK_INT >= 29 &&
        (ctx.getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true)
    return PermState(
        granted(Manifest.permission.RECORD_AUDIO),
        Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS),
        granted(Manifest.permission.READ_CONTACTS),
        granted(Manifest.permission.ANSWER_PHONE_CALLS),
        granted(Manifest.permission.CALL_PHONE),
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx),
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName),
        JarvisAccessibilityService.instance != null,
        role,
        nm.isNotificationPolicyAccessGranted,
        pm.isIgnoringBatteryOptimizations(ctx.packageName)
    )
}

private data class AppEntry(val label: String, val pkg: String)

private fun loadLaunchableApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    return list.map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .distinctBy { it.pkg }
        .filter { it.pkg != ctx.packageName }
        .sortedBy { it.label.lowercase() }
}

@Composable
private fun ToggleRow(label: String, initial: Boolean, onChange: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = JarvisText, fontSize = 13.sp)
        Switch(v, { v = it; onChange(it) })
    }
}

@Composable
private fun PermRow(label: String, ok: Boolean, action: String, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (ok) Color(0xFF2EE6A6) else Color(0xFFFFB020)))
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f), color = JarvisText, fontSize = 13.sp)
        if (ok) {
            Text("ON", color = Color(0xFF2EE6A6), fontFamily = CcMono, fontSize = 11.sp)
        } else {
            OutlinedButton(onClick = onAction, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)) {
                Text(action, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, color = JarvisText.copy(alpha = 0.6f), fontSize = 12.sp)
}

@Composable
private fun AppPickerDialog(title: String, current: Set<String>, onSave: (Set<String>) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val apps = remember { loadLaunchableApps(ctx) }
    var sel by remember { mutableStateOf(current) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF040D1C)).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
            Text(title, color = JarvisCyan, fontFamily = CcMono, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(apps) { a ->
                    Row(
                        Modifier.fillMaxWidth().clickable { sel = if (sel.contains(a.pkg)) sel - a.pkg else sel + a.pkg }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(a.label, Modifier.weight(1f), color = JarvisText, fontSize = 14.sp)
                        Switch(sel.contains(a.pkg), { sel = if (it) sel + a.pkg else sel - a.pkg })
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onClose, modifier = Modifier.weight(1f)) { Text("CANCEL") }
                Button(
                    onClick = { onSave(sel); onClose() }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)
                ) { Text("SAVE") }
            }
        }
    }
}

@Composable
private fun HistoryDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val all = remember { History.all(ctx).reversed() }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF071327),
        title = { Text("AUTOMATION HISTORY", color = JarvisCyan, fontFamily = CcMono) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (all.isEmpty()) {
                    Text("Nothing yet.", color = JarvisText)
                } else {
                    all.forEach { Text(it, color = JarvisText, fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                }
            }
        },
        confirmButton = { TextButton(onClose) { Text("CLOSE") } }
    )
}

@Composable
fun ControlCenterDialog(vm: JarvisViewModel, onToggleWake: (Boolean) -> Unit, onOpenAi: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SecureStore.of(ctx) }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }
    val ps = remember(tick) { readPerms(ctx) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    var picker by remember { mutableStateOf(0) }
    var showHistory by remember { mutableStateOf(false) }
    var replyText by remember { mutableStateOf(store.autoReplyText) }
    var rule by remember { mutableStateOf(store.busyCallRule) }
    var briefHour by remember { mutableStateOf(store.briefingHour) }

    fun ask(p: String) { permLauncher.launch(arrayOf(p)) }
    fun open(i: Intent) { try { ctx.startActivity(i) } catch (e: Exception) { } }
    fun requestRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = ctx.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }
        }
    }
    fun appToggle(pkgs: List<String>, on: Boolean) {
        val cur = store.allowedApps().toMutableSet()
        if (on) cur.addAll(pkgs) else cur.removeAll(pkgs.toSet())
        store.saveAllowedApps(cur)
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF040D1C)).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("CONTROL CENTER", Modifier.weight(1f), color = JarvisCyan, fontFamily = CcMono,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 2.sp)
                TextButton(onClose) { Text("CLOSE") }
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Panel("BACKGROUND") {
                    ToggleRow("Listen in the background (wake word)", vm.wakeEnabled) { onToggleWake(it) }
                    ToggleRow("Read approved notifications aloud", vm.readAloud) { vm.updateReadAloud(it) }
                    PermRow("Battery: let Jarvis keep running", ps.battery, "OPEN") {
                        open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = { Control.stopAll(ctx); vm.reloadFlags(); onClose() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935), contentColor = Color.White)
                    ) { Text("STOP ALL BACKGROUND ACTIVITY") }
                    Note("Switches off listening, reading aloud, busy mode, auto-replies, auto-answer and the proactive jobs at once. Reminders you set stay scheduled.")
                }

                Panel("PERMISSIONS") {
                    PermRow("Microphone", ps.mic, "ALLOW") { ask(Manifest.permission.RECORD_AUDIO) }
                    PermRow("Notifications", ps.post, "ALLOW") {
                        if (Build.VERSION.SDK_INT >= 33) ask(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    PermRow("Read notifications (notification access)", ps.listener, "OPEN") {
                        open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }
                    PermRow("Contacts", ps.contacts, "ALLOW") { ask(Manifest.permission.READ_CONTACTS) }
                    PermRow("Answer and end calls", ps.answer, "ALLOW") { ask(Manifest.permission.ANSWER_PHONE_CALLS) }
                    PermRow("Place calls directly", ps.call, "ALLOW") { ask(Manifest.permission.CALL_PHONE) }
                    PermRow("Call screening (busy mode for calls)", ps.role, "SET") { requestRole() }
                    PermRow("Display over other apps (the top pill)", ps.overlay, "OPEN") {
                        open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                    }
                    PermRow("Screen control (Accessibility)", ps.access, "OPEN") {
                        open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    PermRow("Do Not Disturb access", ps.dnd, "OPEN") {
                        open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
                    }) { Text("Turn permissions off in Android…") }
                    Note("Android only lets you switch a permission off in its own settings, so the button above opens them.")
                }

                Panel("APPS JARVIS MAY READ") {
                    val allowed = store.allowedApps()
                    ToggleRow("WhatsApp", allowed.contains("com.whatsapp")) { appToggle(listOf("com.whatsapp", "com.whatsapp.w4b"), it) }
                    ToggleRow("TikTok", allowed.contains("com.zhiliaoapp.musically") || allowed.contains("com.ss.android.ugc.trill")) {
                        appToggle(listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"), it)
                    }
                    ToggleRow("Messages", allowed.contains("com.google.android.apps.messaging")) {
                        appToggle(listOf("com.google.android.apps.messaging"), it)
                    }
                    OutlinedButton(onClick = { picker = 1 }) { Text("Choose other apps…") }
                    Note("Jarvis ignores notifications from every app you don't approve here.")
                }

                Panel("WHATSAPP AND TIKTOK ASSISTANT") {
                    ToggleRow("Never read verification codes aloud", store.skipCodes) { store.skipCodes = it }
                    ToggleRow("Smart replies: the AI drafts a reply", store.smartReplies) { store.smartReplies = it }
                    Note("After Jarvis reads a message, say \"suggest a reply\". You approve or change every reply before it is sent. Replies go through the app's own reply button, so they only work while the notification is still showing. TikTok has no public messaging API, so replies there only work if TikTok offers a reply button.")
                }

                Panel("BUSY MODE AND AUTOMATIC REPLIES") {
                    ToggleRow("Busy mode", store.busyMode) {
                        store.busyMode = it
                        History.log(ctx, if (it) "Busy mode switched on" else "Busy mode switched off")
                    }
                    Text("Calls from numbers that are not in your contacts:", color = JarvisText, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("allow" to "Allow", "silence" to "Silence", "reject" to "Reject").forEach { (k, label) ->
                            if (rule == k) {
                                Button(
                                    onClick = { }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)
                                ) { Text(label) }
                            } else {
                                OutlinedButton(
                                    onClick = { store.busyCallRule = k; rule = k },
                                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)
                                ) { Text(label) }
                            }
                        }
                    }
                    ToggleRow("Auto-reply to messages while busy", store.autoReply) { store.autoReply = it }
                    OutlinedTextField(replyText, { replyText = it; store.autoReplyText = it },
                        label = { Text("Automatic reply text") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { picker = 2 }) { Text("Choose auto-reply apps…") }
                    ToggleRow("Auto-answer calls from starred contacts", store.autoAnswer) { store.autoAnswer = it }
                    ToggleRow("Place calls directly after I confirm", store.directCall) { store.directCall = it }
                    Note("Auto-replies are never sent in group chats and at most once an hour per person. Keep a line in the text saying it is automated. Jarvis never records calls and never talks to callers for you.")
                }

                Panel("PROACTIVE JARVIS") {
                    ToggleRow("Daily briefing", store.briefingOn) { store.briefingOn = it; Proactive.refresh(ctx) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Briefing time: " + "%02d:%02d".format(briefHour, store.briefingMin), Modifier.weight(1f),
                            color = JarvisText, fontSize = 13.sp)
                        OutlinedButton(onClick = { briefHour = (briefHour + 23) % 24; store.briefingHour = briefHour },
                            contentPadding = PaddingValues(horizontal = 12.dp)) { Text("-") }
                        Spacer(Modifier.width(6.dp))
                        OutlinedButton(onClick = { briefHour = (briefHour + 1) % 24; store.briefingHour = briefHour },
                            contentPadding = PaddingValues(horizontal = 12.dp)) { Text("+") }
                    }
                    ToggleRow("Alerts: low battery, unanswered messages, Play Store updates", store.proactiveOn) {
                        store.proactiveOn = it
                        Proactive.refresh(ctx)
                    }
                    Note("These checks run about every 15 minutes, which is the fastest Android allows. Android does not let any app see which other apps have updates waiting, so update alerts come from Google Play's own notification.")
                }

                Panel("AI AND INTERNET") {
                    val keyOk = (if (store.provider == AiProvider.GEMINI) store.geminiKey else store.apiKey).isNotBlank()
                    ToggleRow("Live internet search for answers", store.liveSearch) { store.liveSearch = it }
                    Text("Provider: " + vm.provider.short + if (keyOk) " (key saved)" else " (no key yet)", color = JarvisText, fontSize = 13.sp)
                    OutlinedButton(onClick = onOpenAi) { Text("AI key and provider…") }
                }

                Panel("AUTOMATION HISTORY") {
                    val recent = History.all(ctx).takeLast(5).reversed()
                    if (recent.isEmpty()) {
                        Note("Nothing yet.")
                    } else {
                        recent.forEach { Text(it, color = JarvisText, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showHistory = true }) { Text("View all") }
                        OutlinedButton(onClick = { History.clear(ctx); tick++ }) { Text("Clear") }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
    if (picker == 1) AppPickerDialog("Apps Jarvis may read", store.allowedApps(), { store.saveAllowedApps(it) }) { picker = 0 }
    if (picker == 2) AppPickerDialog("Apps Jarvis may auto-reply in", store.autoReplyApps(), { store.saveAutoReplyApps(it) }) { picker = 0 }
    if (showHistory) HistoryDialog { showHistory = false }
}
