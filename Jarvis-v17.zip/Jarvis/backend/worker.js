// JARVIS secure backend (Cloudflare Worker). Your AI keys live here as secrets, never in the app.
// Secrets/variables to add: GEMINI_API_KEY, (optional) ANTHROPIC_API_KEY, APP_TOKEN, GEMINI_MODEL
const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json" } });
const fail = (status, code, message) => json({ error: { status: code, message } }, status);

export default {
  async fetch(request, env) {
    if (request.method !== "POST") return fail(405, "METHOD_NOT_ALLOWED", "POST only");
    if (env.APP_TOKEN && request.headers.get("x-app-token") !== env.APP_TOKEN) {
      return fail(401, "UNAUTHENTICATED", "Bad app token");
    }
    let body;
    try { body = await request.json(); } catch { return fail(400, "INVALID_ARGUMENT", "Bad JSON"); }

    const provider = body.provider === "claude" ? "claude" : "gemini";
    const system = String(body.system || "").slice(0, 8000);
    const msgs = (Array.isArray(body.messages) ? body.messages : []).slice(-30).map((m) => ({
      role: m.role === "user" ? "user" : "assistant",
      text: String(m.text || "").slice(0, 20000),
    }));
    if (!msgs.length || msgs[0].role !== "user") return fail(400, "INVALID_ARGUMENT", "No messages");

    if (provider === "gemini") {
      if (!env.GEMINI_API_KEY) return fail(500, "NOT_CONFIGURED", "GEMINI_API_KEY is not set");
      const wanted = String(body.model || "");
      const model = /^[A-Za-z0-9._-]+$/.test(wanted) ? wanted : env.GEMINI_MODEL || "gemini-3.8-flash";
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
      const send = (search) =>
        fetch(url, {
          method: "POST",
          headers: { "content-type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
          body: JSON.stringify({
            system_instruction: { parts: [{ text: system }] },
            contents: msgs.map((m) => ({
              role: m.role === "user" ? "user" : "model",
              parts: [{ text: m.text }],
            })),
            ...(search ? { tools: [{ google_search: {} }] } : {}),
          }),
        });
      const wantSearch = body.liveSearch === true;
      let r = await send(wantSearch);
      if (wantSearch && r.status >= 400 && r.status <= 404) r = await send(false);
      const data = await r.json().catch(() => ({}));
      if (!r.ok) return json(data, r.status);
      const parts = data.candidates?.[0]?.content?.parts || [];
      const text = parts.filter((p) => !p.thought).map((p) => p.text || "").join("").trim();
      return json({ text });
    }

    if (!env.ANTHROPIC_API_KEY) return fail(500, "NOT_CONFIGURED", "ANTHROPIC_API_KEY is not set");
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: /^[A-Za-z0-9._-]+$/.test(body.model || "") ? body.model : "claude-sonnet-5-5",
        max_tokens: 400,
        system,
        messages: msgs.map((m) => ({ role: m.role, content: m.text })),
      }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return json(data, r.status);
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("").trim();
    return json({ text });
  },
};
