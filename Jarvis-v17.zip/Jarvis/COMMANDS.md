# Jarvis voice commands

Say "Jarvis" first (or use the mic). You can add please / can you; you can chain steps with "and" / "then".

## Open apps and websites
- open WhatsApp  (also: launch / start; any installed app)
- open youtube.com  /  go to bbc.com  /  visit example.com
- open camera  /  take a photo
- open settings  /  open wifi settings  (bluetooth, display, sound, battery, location)
- google best pizza  (opens the browser)
- search for the football score  (answered out loud with live web search)

## Chain steps in one sentence
- open WhatsApp and tell me what is on the screen
- open YouTube then scroll down
- go home and open Chrome

## Read and control the screen (needs Accessibility)
- read my screen  /  what's on my screen  /  tell me what is on the screen
- what do you see  /  describe the screen
- summarize the screen  (asks before sending text to the AI)
- scroll down  /  scroll up
- go back  /  go home  /  open recent apps
- tap Ada  /  click Search  (never payment or delete buttons)
- pull down the notification panel  /  open quick settings
- take a screenshot  /  lock the screen
- test screen control

## Calls and location
- call Ada  /  call 0801 234 5678  (asks first)
- answer the call  /  pick up the call  /  decline the call  /  hang up
- while a call is ringing, just say: answer  or  decline
- where am I  /  send my location to Ada

## Messages
- text Ada saying I'm on my way  (asks first)
- text 0801 234 5678 saying hello
- read my notifications  /  summarize my notifications
- read them  /  summarize them  (after I announce several)
- reply to the last message saying I'll call you back
- after I read a message: reply I'm on my way  /  tell her I'm busy  /  suggest a reply  /  ignore
- to approve or edit a reply: yes  /  no  /  change it to ...

## Alarms, timers and reminders
- set alarm for 7:30 am  /  wake me at 6
- timer for 10 minutes
- remind me to take my pills at 6 pm every day
- remind me to call Ada in 20 minutes
- what are my reminders  /  clear reminders

## Phone settings
- volume up  /  volume down  /  volume to 50 percent
- set brightness to 40 percent
- pause  /  resume  /  next  /  previous  /  pause the music
- turn on the flashlight  /  turn off the flashlight
- do not disturb on  /  do not disturb off
- silent mode  /  vibrate mode  /  normal mode
- turn on wifi  /  turn on bluetooth  (opens the panel; Android does not let apps switch them)

## Files and memory
- summarize a file  /  read a file
- remember that I like jazz
- what do you remember  /  forget everything

## Quick answers (work offline)
- what time is it  /  what's the date
- battery level  /  how much storage do I have
- flip a coin  /  roll a dice  /  what is 12 plus 30
- who are you  /  what can you do  /  what commands can I say

## Control Jarvis itself
- Jarvis  (wake word; then the password if locked)
- tap the pill at the top, or press Quiet in the notification, to make me stop talking
- go to sleep  /  stop listening  /  goodbye  (turns background listening off)
- yes / confirm / go ahead  and  no / cancel / never mind  (for questions I ask)

