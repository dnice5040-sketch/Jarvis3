# JARVIS — Phase 1 foundation

## Run it
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select this `Jarvis` folder. Wait for "Gradle sync" to finish (first time takes a few minutes).
3. Connect your Android phone (Settings > About phone > tap Build number 7 times > Developer options > USB debugging), or create an emulator in Device Manager.
4. Press the green Run button.
5. In the app: tap the gear, paste your AI API key (console.anthropic.com), save. Tap MIC and allow microphone.

## Try saying
open YouTube / open WhatsApp / open wifi settings / call 555 0100 (asks first) /
text 555 0100 saying hello (asks first) / set alarm for 7:30 am / remind me to stretch at 5 pm /
timer for 10 minutes / search for best pizza near me / volume up / pause music / read my notifications /
remember that I like jazz / anything else goes to the AI.

## Roadmap
- Phase 2: contacts lookup, location (with permission), file picker, brightness, notification summaries by AI
- Phase 3: wake word "Hey JARVIS" (foreground service + on-device hotword engine), always-on hands-free
- Phase 4: Accessibility-based multi-step app control, proactive daily briefing

## Phase 3: wake word ("Hey JARVIS")
Gear > turn on "Listen for wake word" (allow microphone + notifications). A notification with a Stop button shows while JARVIS listens.
Also tap "Allow opening over other apps" and enable it, so JARVIS can jump to the screen when it hears you. Without it you get a "Tap to talk" notification instead.
Change the word in the "Wake word" box (default: jarvis), then Save.

Honest limits of this version: it uses Android's built-in speech recognizer (no extra account needed), so it uses more battery than a dedicated engine, may click or beep every few seconds on some phones, and works best with the phone unlocked. It does not restart after a reboot. An on-device engine (e.g. Picovoice Porcupine) is the upgrade path if you want battery-friendly always-on listening.

## Phase 2: contacts, location, files
- "call mom" / "text Sam saying running late" (asks for contacts permission the first time, then confirms; you still press call/send)
- "where am I" / "send my location to Sam" (location permission; uses your last known fix; confirms first)
- "summarize a file" / "read a file" (you pick one text file; only that file is read)
- "summarize my notifications" (asks first, because the text goes to the AI service)
- "set brightness to 40 percent" (opens the system page to allow it the first time)
Not yet: Accessibility-based control of other apps and a daily briefing (Phase 4).

## AI provider (Gemini or Claude)
Gear > pick Gemini or Claude, paste that provider's key, Save. Default model: gemini-3.8-flash (change it in the Model box if Google retires it).
"Save and test connection" sends one small real request and prints PASS/FAIL in the chat.
Optional secure backend: deploy backend/worker.js as a Cloudflare Worker, put the AI key in its secrets, then enter the Worker's https URL (and APP_TOKEN) in settings. The key then never lives on the phone.

## Talking in the background
Turn on "Listen for wake word" and "Allow opening over other apps". Say "open YouTube" in JARVIS, then say "Jarvis" while YouTube is on screen:
JARVIS answers "Yes, Sam?", listens, runs your command (open apps, alarms, volume, search, call/text with spoken yes/no) or chats with the AI, and talks back, without covering the other app.
"Jarvis ... go to sleep" turns the background listener off. Also tap "Keep me running in background" and allow it.

## Michelle (v10)
Renamed to Michelle (wake word "michelle"). New: read notifications aloud and reply by voice (confirmation first), reminders that ring like a call ("remind me to take my pills at 6 pm every day", "remind me to call Ada in 20 minutes"), and a voice picker in settings.

## Jarvis (v12)
Back to the name Jarvis (wake word "jarvis"). Home screen is the glowing holographic head with HUD rings; the mouth moves while Jarvis speaks. Settings > Voice: Male / Female (changes pitch of the installed voice) and "Try another voice".

## v13: pill, offline mode, Command Center
- Say "Jarvis" in any app: a Siri-style pill appears at the top (listening / thinking / speaking) instead of opening the full app. Needs "Display over other apps".
- Offline mode (Settings): no internet requests. Phone commands, reminders, notifications, time/date/battery/storage/maths/jokes keep working. For offline speech recognition download the language pack in Google app > Settings > Voice > Offline speech recognition.
- Inside the app, the grid tab is now the Command Center dashboard (live data only). The face (home tab) and the icon are unchanged.

## v14: security passcode
Jarvis is locked on every start and after the auto-lock timeout. First run: create your passcode (stored only as a salted hash in Keystore-encrypted storage; nothing is hard-coded and nothing is sent to an AI).
Say "Jarvis": if locked he asks "Security verification required. What is the password?". Three wrong attempts lock voice for 5 minutes.
Settings > Security & passcode: change passcode, auto-lock time, optional fingerprint/phone-PIN unlock and confirmation for sensitive actions, lock now.
If you forget the passcode, the only reset is clearing the app's data (this also erases settings and keys).
