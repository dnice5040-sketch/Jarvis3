package com.jarvis.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Everything sensitive (API key, name, remembered facts) is encrypted on-device. */
class SecureStore(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "jarvis_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v.trim()).apply()

    var ownerName: String
        get() = prefs.getString("owner", "Sam") ?: "Sam"
        set(v) = prefs.edit().putString("owner", v.trim()).apply()

    var provider: AiProvider
        get() = try { AiProvider.valueOf(prefs.getString("provider", "GEMINI") ?: "GEMINI") } catch (e: Exception) { AiProvider.GEMINI }
        set(v) = prefs.edit().putString("provider", v.name).apply()

    var geminiKey: String
        get() = prefs.getString("gemini_key", "") ?: ""
        set(v) = prefs.edit().putString("gemini_key", v.trim()).apply()

    fun model(p: AiProvider): String = prefs.getString("model_" + p.name, "") ?: ""
    fun setModel(p: AiProvider, v: String) = prefs.edit().putString("model_" + p.name, v.trim()).apply()

    var backendUrl: String
        get() = prefs.getString("backend_url", "") ?: ""
        set(v) = prefs.edit().putString("backend_url", v.trim()).apply()

    var backendToken: String
        get() = prefs.getString("backend_token", "") ?: ""
        set(v) = prefs.edit().putString("backend_token", v.trim()).apply()

    var wakeWord: String
        get() = (prefs.getString("wake_word", "jarvis") ?: "jarvis").ifBlank { "jarvis" }
        set(v) = prefs.edit().putString("wake_word", v.trim().ifBlank { "jarvis" }).apply()

    var wakeEnabled: Boolean
        get() = prefs.getBoolean("wake_on", false)
        set(v) = prefs.edit().putBoolean("wake_on", v).apply()

    val memories: List<String>
        get() = (prefs.getString("mem", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun remember(fact: String) {
        val all = memories + fact.replace("\n", " ").trim()
        prefs.edit().putString("mem", all.takeLast(50).joinToString("\n")).apply()
    }

    init {
        // One-time switch of the default wake word to the new name.
        if (!prefs.getBoolean("renamed_jarvis_back", false)) {
            prefs.edit().putString("wake_word", "jarvis").putBoolean("renamed_jarvis_back", true).apply()
        }
    }

    var readAloud: Boolean
        get() = prefs.getBoolean("read_aloud", false)
        set(v) = prefs.edit().putBoolean("read_aloud", v).apply()

    var remindersJson: String
        get() = prefs.getString("reminders", "") ?: ""
        set(v) = prefs.edit().putString("reminders", v).apply()

    var passHash: String
        get() = prefs.getString("pass_hash", "") ?: ""
        set(v) = prefs.edit().putString("pass_hash", v).apply()

    var passSalt: String
        get() = prefs.getString("pass_salt", "") ?: ""
        set(v) = prefs.edit().putString("pass_salt", v).apply()

    var failCount: Int
        get() = prefs.getInt("fail_count", 0)
        set(v) = prefs.edit().putInt("fail_count", v).apply()

    var lockUntil: Long
        get() = prefs.getLong("lock_until", 0L)
        set(v) = prefs.edit().putLong("lock_until", v).apply()

    var timeoutMin: Int
        get() = prefs.getInt("timeout_min", 5)
        set(v) = prefs.edit().putInt("timeout_min", v).apply()

    var bioUnlock: Boolean
        get() = prefs.getBoolean("bio_unlock", false)
        set(v) = prefs.edit().putBoolean("bio_unlock", v).apply()

    var sensitiveAuth: Boolean
        get() = prefs.getBoolean("sensitive_auth", false)
        set(v) = prefs.edit().putBoolean("sensitive_auth", v).apply()

    var offlineMode: Boolean
        get() = prefs.getBoolean("offline_mode", false)
        set(v) = prefs.edit().putBoolean("offline_mode", v).apply()

    var voiceGender: String
        get() = prefs.getString("voice_gender", "male") ?: "male"
        set(v) = prefs.edit().putString("voice_gender", v).apply()

    var voiceName: String
        get() = prefs.getString("voice_name", "") ?: ""
        set(v) = prefs.edit().putString("voice_name", v).apply()

    fun aiConfig(): AiConfig {
        val p = provider
        return AiConfig(p, if (p == AiProvider.GEMINI) geminiKey else apiKey, model(p), backendUrl, backendToken)
    }

    fun forgetAll() = prefs.edit().remove("mem").apply()
}
