package com.jarvis.assistant

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Status { STANDBY, LISTENING, THINKING, SPEAKING }
data class Msg(val fromUser: Boolean, val text: String)
class Pending(val description: String, val run: () -> String = { "" }, val ask: String? = null)
class PermRequest(val perms: List<String>, val retry: String)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SecureStore(app)
    private val actions = PhoneActions(app)
    private val llm = LlmClient()
    private val brain = OfflineBrain(app)
    private val history = mutableListOf<Pair<String, String>>()
    private lateinit var voice: Voice

    val messages = mutableStateListOf<Msg>()
    var status by mutableStateOf(Status.STANDBY); private set
    var pending by mutableStateOf<Pending?>(null); private set
    var permRequest by mutableStateOf<PermRequest?>(null); private set
    var filePick by mutableStateOf<String?>(null); private set
    var level by mutableStateOf(0f); private set
    var continuous by mutableStateOf(false)
    var hasKey by mutableStateOf(false); private set
    var provider by mutableStateOf(store.provider); private set
    var readAloud by mutableStateOf(store.readAloud); private set
    var voiceGender by mutableStateOf(store.voiceGender); private set
    var offlineMode by mutableStateOf(store.offlineMode); private set
    var locked by mutableStateOf(!Auth.isUnlocked()); private set
    var passcodeSet by mutableStateOf(Auth.isSet()); private set
    var authMessage by mutableStateOf(""); private set
    var lockSecs by mutableStateOf(0L); private set
    var bioAllowed by mutableStateOf(false); private set
    var needDeviceAuth by mutableStateOf(false); private set
    private var awaitingAuth: Pending? = null
    private var authListen = false
    var voiceLabel by mutableStateOf(store.voiceName.ifEmpty { "default" }); private set
    var backendUrl by mutableStateOf(store.backendUrl); private set
    var ownerName by mutableStateOf(store.ownerName); private set
    var wakeWord by mutableStateOf(store.wakeWord); private set
    var wakeEnabled by mutableStateOf(store.wakeEnabled); private set

    init {
        voice = Voice(
            app,
            onText = { submit(it) },
            onLevel = { level = it },
            onListening = { on ->
                if (!on) { level = 0f; if (status == Status.LISTENING) status = Status.STANDBY }
            },
            onSpeechDone = {
                status = Status.STANDBY
                if (authListen) { authListen = false; status = Status.LISTENING; voice.listen() }
                else if (continuous && WakeService.appVisible && Auth.isUnlocked()) { status = Status.LISTENING; voice.listen() }
            },
            onFail = { notify(it); status = Status.STANDBY }
        )
        val who = if (ownerName.isBlank()) "" else ", $ownerName"
        messages += Msg(false, "Jarvis online$who. How may I assist?")
        Bridge.drain().forEach { messages += it }
        Bridge.sink = { messages += it }
        refreshSecurityUi()
    }

    private fun config(): AiConfig {
        val p = store.provider
        val key = if (p == AiProvider.GEMINI) store.geminiKey else store.apiKey
        return AiConfig(p, key, store.model(p), store.backendUrl, store.backendToken)
    }

    fun keySaved(p: AiProvider) = (if (p == AiProvider.GEMINI) store.geminiKey else store.apiKey).isNotBlank()
    fun modelFor(p: AiProvider) = store.model(p)
    fun defaultModel(p: AiProvider) = LlmClient.defaultModel(p)

    fun saveSettings(
        p: AiProvider, key: String, model: String, name: String, word: String,
        backend: String, token: String
    ) {
        store.provider = p
        if (key.isNotBlank()) { if (p == AiProvider.GEMINI) store.geminiKey = key else store.apiKey = key }
        store.setModel(p, model)
        store.backendUrl = backend
        if (token.isNotBlank()) store.backendToken = token
        store.ownerName = name
        provider = p
        backendUrl = store.backendUrl
        hasKey = config().key.isNotBlank() || store.backendUrl.isNotBlank()
        ownerName = store.ownerName
        val changed = word.trim().ifBlank { "jarvis" } != store.wakeWord
        store.wakeWord = word
        wakeWord = store.wakeWord
        if (changed && wakeEnabled) setWake(true)
    }

    /** Call only after microphone permission is granted. */
    fun setWake(on: Boolean) {
        val app = getApplication<Application>()
        store.wakeEnabled = on
        wakeEnabled = on
        if (on) { WakeService.stop(app); WakeService.start(app) } else WakeService.stop(app)
    }

    /** Called when the wake word was heard and the app was brought forward. */
    fun onWake() {
        if (status == Status.LISTENING) return
        if (!Auth.isUnlocked()) { startVoiceAuth(); return }
        voice.stopSpeaking()
        status = Status.LISTENING
        voice.listen()
    }

    fun notify(text: String) { messages += Msg(false, text) }

    fun toggleMic() {
        if (status == Status.LISTENING) { voice.stopListening(); status = Status.STANDBY; return }
        if (!Auth.isUnlocked()) { startVoiceAuth(); return }
        voice.stopSpeaking()
        status = Status.LISTENING
        voice.listen()
    }

    fun confirmPending() = submit("yes")
    fun cancelPending() = submit("cancel")

    fun submit(textRaw: String, echo: Boolean = true) {
        val text = textRaw.trim()
        if (text.isEmpty()) return
        if (!Auth.isUnlocked()) {
            // While locked, anything typed or spoken is only ever treated as a password attempt:
            // it is never shown in the chat, never stored, never sent to an AI.
            if (echo) handleAuth(Auth.verify(text), true)
            return
        }
        Auth.touch()
        if (echo) messages += Msg(true, text)
        val t = text.lowercase().trimEnd('.', '!')
        val p = pending
        if (p != null) {
            pending = null
            if (t in listOf("yes", "confirm", "do it", "go ahead", "yes please", "yep", "sure")) {
                if (store.sensitiveAuth) { awaitingAuth = p; needDeviceAuth = true } else runPending(p)
                return
            }
            if (t in listOf("no", "cancel", "stop", "never mind", "nevermind")) { reply("Understood. Cancelled."); return }
        }
        history += "user" to text
        Regex("remember (?:that )?(.+)", RegexOption.IGNORE_CASE).matchEntire(text.trimEnd('.'))?.let {
            store.remember(it.groupValues[1]); reply("Noted. I'll remember that."); return
        }
        if (t == "forget everything" || t == "forget all") { store.forgetAll(); reply("Memory cleared."); return }
        if (t == "what do you remember") {
            val m = store.memories
            reply(if (m.isEmpty()) "Nothing yet." else "I remember: " + m.joinToString(". ")); return
        }
        when (val r = actions.handle(text)) {
            is ActionResult.Done -> reply(r.message)
            is ActionResult.Confirm -> {
                pending = Pending(r.description, r.run)
                reply(r.description + " Shall I proceed?")
            }
            is ActionResult.ConfirmAsk -> {
                pending = Pending(r.description, ask = r.prompt)
                reply(r.description + " Shall I proceed?")
            }
            is ActionResult.NeedPermission -> {
                reply(r.message)
                permRequest = PermRequest(r.perms, r.retry)
            }
            is ActionResult.Later -> {
                status = Status.THINKING
                viewModelScope.launch { reply(withContext(Dispatchers.IO) { r.work() }) }
            }
            is ActionResult.PickFile -> {
                reply("Choose a file. I'll only read the one you pick.")
                filePick = r.task
            }
            null -> askModel()
        }
    }

    fun permResult(anyGranted: Boolean) {
        val r = permRequest ?: return
        permRequest = null
        if (anyGranted) submit(r.retry, echo = false)
        else reply("Understood. I won't access that without your permission.")
    }

    fun fileChosen(uri: Uri?, cr: ContentResolver) {
        val task = filePick ?: return
        filePick = null
        if (uri == null) { reply("No file selected."); return }
        status = Status.THINKING
        viewModelScope.launch {
            val (name, text) = withContext(Dispatchers.IO) {
                val n = cr.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "file"
                val t = try {
                    cr.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(12000) } ?: ""
                } catch (e: Exception) { "" }
                n to t
            }
            if (text.isBlank() || text.contains('\u0000')) {
                reply("I can only read plain text files for now, and that one looks empty or binary.")
                return@launch
            }
            messages += Msg(true, "File: $name")
            history += "user" to "$task\n\nFile name: $name\n-----\n$text"
            askModel()
        }
    }

    private fun askModel() {
        val appCtx = getApplication<Application>()
        val lastAsked = history.lastOrNull { it.first == "user" }?.second.orEmpty()
        val noInternet = store.offlineMode || !Net.online(appCtx)
        val local = brain.answer(lastAsked, store.ownerName, noInternet)
        if (local != null) { reply(local); return }
        if (noInternet) {
            reply("I'm offline right now. I can still run phone commands, set reminders and answer simple questions like the time, date, battery or storage.", remember = false)
            return
        }
        val cfg = config()
        status = Status.THINKING
        val snapshot = history.takeLast(20)
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { llm.ask(cfg, store.ownerName, store.memories, snapshot) }
            reply(r.text, remember = r.ok)
        }
    }

    /** Sends one tiny real request with the saved settings and reports the outcome in the chat. */
    fun testConnection() {
        val cfg = config()
        status = Status.THINKING
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                llm.ask(cfg, store.ownerName, emptyList(), listOf("user" to "Reply with exactly: Connection OK"))
            }
            status = Status.STANDBY
            val via = if (cfg.backendUrl.isNotBlank()) "backend" else "direct"
            messages += Msg(false, if (r.ok) "Test passed (${cfg.provider.short}, $via): ${r.text}" else "Test failed: ${r.text}")
        }
    }

    private fun reply(text: String, remember: Boolean = true) {
        messages += Msg(false, text)
        if (remember) history += "assistant" to text
        status = Status.SPEAKING
        voice.speak(text)
    }

    fun updateReadAloud(on: Boolean) { store.readAloud = on; readAloud = on }

    fun updateOffline(on: Boolean) { store.offlineMode = on; offlineMode = on }

    /** Switches between the male and female voice style and speaks a sample. */
    fun chooseGender(g: String) {
        store.voiceGender = g
        voiceGender = g
        voice.applyGender(g != "female")
        voice.speak("This is how I sound now.")
        if (wakeEnabled) setWake(true)
    }

    /** Tries the next installed voice and speaks a sample. */
    fun cycleVoice() {
        val names = voice.voiceNames()
        if (names.isEmpty()) {
            notify("No other voices are installed yet. Add some in Android Settings > Text-to-speech.")
            return
        }
        val next = names[(names.indexOf(store.voiceName) + 1) % names.size]
        if (voice.setVoice(next)) {
            store.voiceName = next
            voiceLabel = next
            voice.speak("Hello, I'm Jarvis. Is this voice okay?")
            if (wakeEnabled) setWake(true)
        }
    }

    // ---- Security ------------------------------------------------------------------------------

    fun refreshSecurityUi() {
        bioAllowed = Auth.isSet() && store.bioUnlock && DeviceAuth.available(getApplication<Application>())
    }

    /** Called every second by the screen: applies the auto-lock timeout and the lock-out countdown. */
    fun tick() {
        val nowLocked = !Auth.isUnlocked()
        if (nowLocked != locked) {
            locked = nowLocked
            if (nowLocked) {
                pending = null
                awaitingAuth = null
                needDeviceAuth = false
                authMessage = "Session locked. Please verify again."
            }
        }
        lockSecs = Auth.lockoutSecs()
        val set = Auth.isSet()
        if (passcodeSet != set) passcodeSet = set
    }

    private fun securitySay(text: String, listenAfter: Boolean) {
        authListen = listenAfter
        status = Status.SPEAKING
        voice.speak(text)
    }

    fun startVoiceAuth() {
        if (!Auth.isSet()) { authMessage = "Create a passcode first."; return }
        val secs = Auth.lockoutSecs()
        if (secs > 0L) {
            securitySay("Voice interaction is locked. Try again in " + minutesText(secs) + ".", false)
            return
        }
        securitySay("Security verification required. What is the password?", true)
    }

    fun tryPasscode(code: String) { handleAuth(Auth.verify(code), false) }

    private fun handleAuth(r: AuthResult, spoken: Boolean) {
        when (r.status) {
            AuthStatus.OK -> {
                locked = false
                authMessage = ""
                lockSecs = 0L
                securitySay("Identity verified. Welcome back. How can I assist you?", false)
            }
            AuthStatus.WRONG -> {
                authMessage = "Access denied. Incorrect password. " + r.attemptsLeft + " attempts left."
                securitySay("Access denied. Incorrect password." + (if (spoken) " What is the password?" else ""), spoken)
            }
            AuthStatus.LOCKED_OUT -> {
                lockSecs = r.lockSecs
                authMessage = ""
                locked = true
                securitySay(
                    if (r.justLocked) "Access denied. Incorrect password. Too many incorrect attempts. Voice interaction is locked for 5 minutes."
                    else "Voice interaction is locked. Try again in " + minutesText(r.lockSecs) + ".",
                    false
                )
            }
            AuthStatus.NOT_SET -> authMessage = "Create a passcode first."
        }
    }

    fun createPasscode(code: String, again: String) {
        if (code != again) { authMessage = "The two passcodes do not match."; return }
        if (!Auth.setPasscode(code)) { authMessage = "Use at least 3 letters or digits."; return }
        Auth.unlock()
        passcodeSet = true
        locked = false
        authMessage = ""
        refreshSecurityUi()
        securitySay("Passcode saved. Identity verified. How can I assist you?", false)
    }

    fun biometricResult(ok: Boolean) {
        if (ok && Auth.isSet()) {
            Auth.unlock()
            locked = false
            authMessage = ""
            securitySay("Identity verified. Welcome back. How can I assist you?", false)
        } else authMessage = "Device authentication failed."
    }

    /** Used by the security dashboard. Returns a message for the owner. */
    fun changePasscode(current: String, next: String, again: String): String {
        if (next != again) return "The new passcodes do not match."
        val r = Auth.verify(current)
        return when (r.status) {
            AuthStatus.OK -> if (Auth.setPasscode(next)) "Passcode changed." else "Use at least 3 letters or digits."
            AuthStatus.WRONG -> "The current passcode is wrong. " + r.attemptsLeft + " attempts left."
            AuthStatus.LOCKED_OUT -> { tick(); "Too many wrong attempts. Jarvis is locked for 5 minutes." }
            AuthStatus.NOT_SET -> "No passcode is set."
        }
    }

    private fun runPending(p: Pending) {
        if (p.ask != null) { history += "user" to p.ask; askModel() } else reply(p.run())
    }

    /** Result of the fingerprint / phone-PIN prompt shown before a sensitive action. */
    fun deviceAuthResult(ok: Boolean) {
        val p = awaitingAuth
        awaitingAuth = null
        needDeviceAuth = false
        if (p == null) return
        if (ok) runPending(p) else reply("Authentication failed. I cancelled that action.", remember = false)
    }

    /** Called when the screen goes to the background: hand the microphone to the background service. */
    fun onBackground() {
        voice.stopListening()
        if (status == Status.LISTENING) status = Status.STANDBY
    }

    override fun onCleared() { Bridge.sink = null; voice.shutdown() }
}
