package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speech-to-text (SpeechRecognizer) and text-to-speech (TextToSpeech). Create on the main thread. */
class Voice(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onListening: (Boolean) -> Unit,
    private val onSpeechDone: () -> Unit,
    private val onFail: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx) { status ->
        if (status == TextToSpeech.SUCCESS) { ready = true; setupVoice() }
    }

    private fun setupVoice() {
        tts.language = Locale.getDefault()
        tts.setPitch(1.05f)
        tts.setSpeechRate(1.0f)
        applyPreferredVoice(ctx, tts)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { onSpeechDone() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { onSpeechDone() } }
        })
    }

    private val natural = NaturalVoice(ctx) { onSpeechDone() }

    fun speak(text: String) {
        val store = SecureStore.of(ctx)
        if (natural.usable(store)) {
            tts.stop()
            natural.speak(text, store) { speakBuiltIn(text) }
            return
        }
        if (store.naturalVoice && !NaturalVoice.status.startsWith("Problem")) {
            NaturalVoice.status = "Problem: not available right now (no internet, no Gemini key, or waiting after a failure)."
        }
        speakBuiltIn(text)
    }

    fun resetNatural() { natural.clearBackoff() }

    /** The phone's own voice (also the back-up when the natural voice is not available). */
    private fun speakBuiltIn(text: String) {
        if (!ready) { onSpeechDone(); return }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun stopSpeaking() { tts.stop(); natural.stop() }

    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onListening(false)
            onFail("Speech recognition isn't available on this device."); return
        }
        stopListening()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(error: Int) {
                onListening(false)
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
                    onFail("I need microphone permission to hear you.")
            }
            override fun onResults(results: Bundle?) {
                onListening(false)
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onText(t)
            }
        })
        recognizer = r
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, SecureStore(ctx).offlineMode)
        })
    }

    fun stopListening() { recognizer?.destroy(); recognizer = null }

    /** Installed voices for the phone's language, so the user can pick one. */
    fun voiceNames(): List<String> = try {
        val lang = Locale.getDefault().language
        tts.voices.orEmpty().filter { it.locale.language == lang }.map { it.name }.sorted()
    } catch (e: Exception) { emptyList() }

    /** Android does not tell us a voice's gender, so male/female changes the pitch of whichever voice is installed. */
    fun applyGender(male: Boolean) { tts.setPitch(if (male) 0.78f else 1.2f) }

    fun setVoice(name: String): Boolean {
        val v = tts.voices.orEmpty().firstOrNull { it.name == name } ?: return false
        return tts.setVoice(v) == TextToSpeech.SUCCESS
    }

    fun shutdown() { stopListening(); natural.shutdown(); tts.stop(); tts.shutdown() }
}


/** Applies the voice the user picked in settings (if any). */
fun applyPreferredVoice(ctx: Context, tts: TextToSpeech) {
    val store = SecureStore(ctx)
    tts.setPitch(if (store.voiceGender == "female") 1.2f else 0.78f)
    val name = store.voiceName
    if (name.isEmpty()) return
    val v = tts.voices.orEmpty().firstOrNull { it.name == name } ?: return
    tts.setVoice(v)
}
