package com.jarvis.assistant

import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

/** The "incoming call" screen: rings, and when you answer, Jarvis speaks the reminder. */
class ReminderActivity : ComponentActivity() {
    private var ring: Ringtone? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var queued: String? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        val text = intent.getStringExtra("text") ?: "your reminder"
        val name = SecureStore(this).ownerName.ifBlank { "there" }

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val t = tts
                if (t != null) {
                    t.language = Locale.getDefault()
                    applyPreferredVoice(this, t)
                    ttsReady = true
                    queued?.let { t.speak(it, TextToSpeech.QUEUE_FLUSH, null, "remind") }
                }
            }
        }
        try {
            val r = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
            if (Build.VERSION.SDK_INT >= 28) {
                r.isLooping = true
                r.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            }
            r.play()
            ring = r
        } catch (e: Exception) { }
        handler.postDelayed({ stopRing() }, 30000)

        setContent {
            JarvisTheme {
                var answered by remember { mutableStateOf(false) }
                Column(
                    Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(64.dp))
                    Text("Jarvis", color = JarvisCyan, fontSize = 34.sp, fontFamily = FontFamily.Monospace)
                    Text(if (answered) "Reminder" else "incoming call…", color = JarvisText.copy(alpha = 0.7f), fontSize = 16.sp)
                    Spacer(Modifier.height(24.dp))
                    Text(text, color = JarvisText, fontSize = 22.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.weight(1f))
                    if (!answered) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            CallButton("Decline", Color(0xFFE53935)) { stopRing(); finish() }
                            CallButton("Answer", Color(0xFF43A047)) {
                                answered = true
                                stopRing()
                                speak("Hello $name, this is Jarvis. Don't forget: $text.")
                            }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            CallButton("Snooze 10 min", Color(0xFF455A64)) {
                                Reminders.add(applicationContext, text, System.currentTimeMillis() + 600_000L, false)
                                finish()
                            }
                            CallButton("Done", Color(0xFF43A047)) { finish() }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    private fun speak(msg: String) {
        val t = tts
        if (ttsReady && t != null) t.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "remind") else queued = msg
    }

    private fun stopRing() { try { ring?.stop() } catch (e: Exception) { }; ring = null }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopRing()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun CallButton(label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(color).clickable(onClick = onClick))
        Spacer(Modifier.height(8.dp))
        Text(label, color = JarvisText, fontSize = 14.sp)
    }
}
