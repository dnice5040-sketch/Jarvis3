package com.jarvis.assistant

/** Lets the background service drop messages into the chat screen (now, or when the app next opens). */
object Bridge {
    private val buffer = mutableListOf<Msg>()
    var sink: ((Msg) -> Unit)? = null

    fun post(m: Msg) {
        val s = sink
        if (s != null) s(m) else synchronized(buffer) {
            buffer.add(m)
            while (buffer.size > 50) buffer.removeAt(0)
        }
    }

    fun drain(): List<Msg> = synchronized(buffer) {
        val copy = buffer.toList()
        buffer.clear()
        copy
    }
}
