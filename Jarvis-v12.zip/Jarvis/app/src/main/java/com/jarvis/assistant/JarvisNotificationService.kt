package com.jarvis.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Only runs if the user turns on Notification access for Jarvis in Android settings.
 * Keeps the 30 most recent notifications in memory only. If "Read notifications aloud" is on, new
 * messages and alerts are passed to the background assistant, which speaks them and can reply
 * (after the user confirms) using the app's own reply button.
 */
class JarvisNotificationService : NotificationListenerService() {
    private val store by lazy { SecureStore(applicationContext) }
    private val lastSpoken = HashMap<String, String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (ex: Exception) { sbn.packageName }

        var replyAction: Notification.Action? = null
        var replyInput: RemoteInput? = null
        for (a in n.actions ?: emptyArray<Notification.Action>()) {
            val r = a.remoteInputs?.firstOrNull { it.allowFreeFormInput }
            if (r != null) { replyAction = a; replyInput = r; break }
        }
        val item = Item(sbn.key, app, title, text, replyAction, replyInput, n.category.orEmpty())
        synchronized(recent) {
            recent.removeAll { it.key == item.key }
            recent.add(0, item)
            while (recent.size > 30) recent.removeAt(recent.lastIndex)
        }
        if (store.readAloud && shouldRead(item) && lastSpoken[sbn.key] != text) {
            lastSpoken[sbn.key] = text
            WakeService.announce(item)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) { lastSpoken.remove(sbn.key) }

    private fun shouldRead(i: Item) = i.action != null || i.category in READ_CATEGORIES

    data class Item(
        val key: String, val app: String, val title: String, val text: String,
        val action: Notification.Action?, val input: RemoteInput?, val category: String
    )

    companion object {
        val recent = mutableListOf<Item>()
        private val READ_CATEGORIES = setOf(
            Notification.CATEGORY_MESSAGE, Notification.CATEGORY_EMAIL, Notification.CATEGORY_SOCIAL,
            Notification.CATEGORY_REMINDER, Notification.CATEGORY_EVENT
        )

        /** Sends [message] through the notification's own reply button. Call only after the user confirmed. */
        fun sendReply(ctx: Context, item: Item, message: String): Boolean {
            val action = item.action ?: return false
            val input = item.input ?: return false
            return try {
                val intent = Intent()
                val bundle = Bundle()
                bundle.putCharSequence(input.resultKey, message)
                RemoteInput.addResultsToIntent(arrayOf(input), intent, bundle)
                action.actionIntent.send(ctx, 0, intent)
                true
            } catch (e: PendingIntent.CanceledException) {
                false
            } catch (e: Exception) {
                false
            }
        }
    }
}
