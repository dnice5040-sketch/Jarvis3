package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Listens for the wake word while the app is in the background. Visible to the user as a
 * permanent notification with a Stop button. Only runs if the user switches it on.
 * Audio is handled by Android's speech recognizer; JARVIS only looks for the wake word.
 */
class WakeService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var paused = false
    private var wakeWord = "jarvis"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LISTEN, "Wake word listening", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Wake word heard", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            SecureStore(this).wakeEnabled = false
            stopSelf(); return START_NOT_STICKY
        }
        wakeWord = SecureStore(this).wakeWord.lowercase(Locale.getDefault())
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS is listening for \"$wakeWord\"")
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, 1, n, type)
        paused = appVisible
        if (!paused) startListening()
        return START_STICKY
    }

    private fun startListening() {
        if (paused || recognizer != null) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(b: Bundle?) { check(b) }
            override fun onResults(b: Bundle?) { if (!check(b)) restart(300) }
            override fun onError(e: Int) {
                restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
            }
        })
        recognizer = r
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        })
    }

    private fun check(b: Bundle?): Boolean {
        if (paused) return false
        val heard = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.joinToString(" ")?.lowercase(Locale.getDefault()) ?: return false
        if (!heard.contains(wakeWord)) return false
        onWake()
        return true
    }

    private fun stopRecognizer() { recognizer?.destroy(); recognizer = null }

    private fun restart(delayMs: Long) {
        stopRecognizer()
        main.postDelayed({ startListening() }, delayMs)
    }

    private fun onWake() {
        paused = true
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("wake", true)
        val canLaunch = Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)
        if (canLaunch) {
            startActivity(open)
        } else {
            val pi = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(this, CH_WAKE)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS heard you")
                .setContentText("Tap to talk")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
        }
        // If the app never comes to the front, go back to listening.
        main.postDelayed({ paused = appVisible; startListening() }, 8000)
    }

    fun onVisibility(visible: Boolean) {
        main.removeCallbacksAndMessages(null)
        if (visible) { paused = true; stopRecognizer() }
        else { paused = false; main.postDelayed({ startListening() }, 500) }
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.jarvis.assistant.STOP_WAKE"
        private const val CH_LISTEN = "wake_listen"
        private const val CH_WAKE = "wake_heard"
        @Volatile var appVisible = false
        private var instance: WakeService? = null

        fun markVisible(v: Boolean) { appVisible = v; instance?.onVisibility(v) }
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }
    }
}
