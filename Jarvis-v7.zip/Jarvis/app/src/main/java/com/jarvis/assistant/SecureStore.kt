package com.jarvis.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Everything sensitive (API key, name, remembered facts) is encrypted on-device. */
class SecureStore(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "jarvis_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v.trim()).apply()

    var ownerName: String
        get() = prefs.getString("owner", "Sam") ?: "Sam"
        set(v) = prefs.edit().putString("owner", v.trim()).apply()

    var provider: AiProvider
        get() = try { AiProvider.valueOf(prefs.getString("provider", "GEMINI") ?: "GEMINI") } catch (e: Exception) { AiProvider.GEMINI }
        set(v) = prefs.edit().putString("provider", v.name).apply()

    var geminiKey: String
        get() = prefs.getString("gemini_key", "") ?: ""
        set(v) = prefs.edit().putString("gemini_key", v.trim()).apply()

    fun model(p: AiProvider): String = prefs.getString("model_" + p.name, "") ?: ""
    fun setModel(p: AiProvider, v: String) = prefs.edit().putString("model_" + p.name, v.trim()).apply()

    var backendUrl: String
        get() = prefs.getString("backend_url", "") ?: ""
        set(v) = prefs.edit().putString("backend_url", v.trim()).apply()

    var backendToken: String
        get() = prefs.getString("backend_token", "") ?: ""
        set(v) = prefs.edit().putString("backend_token", v.trim()).apply()

    var wakeWord: String
        get() = (prefs.getString("wake_word", "jarvis") ?: "jarvis").ifBlank { "jarvis" }
        set(v) = prefs.edit().putString("wake_word", v.trim().ifBlank { "jarvis" }).apply()

    var wakeEnabled: Boolean
        get() = prefs.getBoolean("wake_on", false)
        set(v) = prefs.edit().putBoolean("wake_on", v).apply()

    val memories: List<String>
        get() = (prefs.getString("mem", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun remember(fact: String) {
        val all = memories + fact.replace("\n", " ").trim()
        prefs.edit().putString("mem", all.takeLast(50).joinToString("\n")).apply()
    }

    fun forgetAll() = prefs.edit().remove("mem").apply()
}
