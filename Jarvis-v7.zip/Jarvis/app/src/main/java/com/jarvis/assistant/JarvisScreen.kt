package com.jarvis.assistant

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

private val Mono = FontFamily.Monospace

@Composable
fun JarvisScreen(vm: JarvisViewModel = viewModel()) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleMic() else vm.notify("Microphone permission was denied. I can still read typed commands.")
    }
    fun onMic() {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) vm.toggleMic() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun send() { vm.submit(input); input = "" }

    val wakePerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic) vm.setWake(true) else vm.notify("I need microphone permission to listen for the wake word.")
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        vm.permResult(res.values.any { it })
    }
    LaunchedEffect(vm.permRequest) { vm.permRequest?.let { permLauncher.launch(it.perms.toTypedArray()) } }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        vm.fileChosen(uri, ctx.contentResolver)
    }
    LaunchedEffect(vm.filePick) {
        if (vm.filePick != null) fileLauncher.launch(arrayOf("text/*", "application/json", "application/xml"))
    }
    fun onWakeToggle(on: Boolean) {
        if (!on) { vm.setWake(false); return }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        wakePerms.launch(perms.toTypedArray())
    }

    Column(
        Modifier.fillMaxSize().background(Color.Black)
            .statusBarsPadding().navigationBarsPadding().imePadding()
            .padding(horizontal = 14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("J.A.R.V.I.S", color = JarvisCyan, fontFamily = Mono, fontWeight = FontWeight.Bold,
                fontSize = 20.sp, letterSpacing = 4.sp)
            Spacer(Modifier.weight(1f))
            StatusIndicator(vm.status)
            TextButton(onClick = { showSettings = true }) { Text("⚙", color = JarvisCyan, fontSize = 20.sp) }
        }
        ClockBlock()
        if (!imeOpen) {
            ArcReactor(vm.status, vm.level, Modifier.size(170.dp).align(Alignment.CenterHorizontally))
        }
        Waveform(vm.status, vm.level, Modifier.fillMaxWidth().height(36.dp))
        if (!imeOpen) { Spacer(Modifier.height(6.dp)); SystemDashboard() }
        Spacer(Modifier.height(8.dp))

        val listState = rememberLazyListState()
        LaunchedEffect(vm.messages.size) {
            if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.messages) { Bubble(it) }
        }

        vm.pending?.let {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.confirmPending() }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text("CONFIRM") }
                OutlinedButton(onClick = { vm.cancelPending() }, modifier = Modifier.weight(1f)) { Text("CANCEL") }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type or tap the mic…") }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            TextButton(onClick = { send() }) { Text("SEND", color = JarvisCyan, fontFamily = Mono) }
            MicButton(vm.status == Status.LISTENING) { onMic() }
        }
    }
    if (showSettings) SettingsDialog(vm, onToggleWake = { onWakeToggle(it) }) { showSettings = false }
}

@Composable
fun StatusIndicator(status: Status) {
    val label = when (status) {
        Status.STANDBY -> "STANDBY"; Status.LISTENING -> "LISTENING"
        Status.THINKING -> "PROCESSING"; Status.SPEAKING -> "SPEAKING"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (status == Status.STANDBY) JarvisCyan.copy(alpha = 0.4f) else JarvisCyan))
        Spacer(Modifier.width(6.dp))
        Text(label, color = JarvisCyan, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun ClockBlock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now).uppercase()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(time, color = JarvisText, fontFamily = Mono, fontSize = 30.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp)
        Text(date, color = JarvisCyan.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun ArcReactor(status: Status, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "reactor")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin"
    )
    val pulse by t.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween(if (status == Status.STANDBY) 2200 else 900, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ), label = "pulse"
    )
    val boost = when (status) {
        Status.LISTENING -> 0.15f + level * 0.35f
        Status.SPEAKING -> 0.25f
        Status.THINKING -> 0.1f
        Status.STANDBY -> 0f
    }
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(JarvisCyan.copy(alpha = 0.25f), r * 0.98f, c, style = Stroke(1.5.dp.toPx()))
        drawCircle(JarvisCyan.copy(alpha = 0.12f), r * 0.70f, c, style = Stroke(1.dp.toPx()))
        for (k in 0 until 3) rotate(spin + k * 120f, c) {
            drawArc(JarvisCyan, 0f, 70f, false, Offset(c.x - r * 0.85f, c.y - r * 0.85f),
                Size(r * 1.7f, r * 1.7f), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
        }
        for (k in 0 until 4) rotate(-spin * 1.6f + k * 90f, c) {
            drawArc(JarvisCyan.copy(alpha = 0.7f), 0f, 40f, false, Offset(c.x - r * 0.58f, c.y - r * 0.58f),
                Size(r * 1.16f, r * 1.16f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        val coreR = r * 0.38f * (pulse + boost) * 1.6f
        drawCircle(Brush.radialGradient(listOf(Color.White, JarvisCyan, Color.Transparent), c, coreR), coreR, c)
    }
}

@Composable
fun Waveform(status: Status, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase"
    )
    val amp = when (status) {
        Status.LISTENING -> 0.15f + level * 0.85f
        Status.SPEAKING -> 0.6f
        Status.THINKING -> 0.3f
        Status.STANDBY -> 0.06f
    }
    Canvas(modifier) {
        val n = 36
        val gap = size.width / n
        for (i in 0 until n) {
            val h = (size.height * (0.12f + amp * abs(sin(phase + i * 0.45f)))).coerceAtMost(size.height)
            val x = gap * i + gap / 2
            drawLine(JarvisCyan.copy(alpha = 0.35f + 0.65f * amp.coerceAtMost(1f)),
                Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = gap * 0.5f, cap = StrokeCap.Round)
        }
    }
}

data class Stats(val battery: Float, val memory: Float, val storage: Float)

fun readStats(ctx: Context): Stats {
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) / 100f
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val fs = StatFs(Environment.getDataDirectory().path)
    return Stats(
        bat.coerceIn(0f, 1f),
        (1f - mi.availMem.toFloat() / mi.totalMem.toFloat()).coerceIn(0f, 1f),
        (1f - fs.availableBytes.toFloat() / fs.totalBytes.toFloat()).coerceIn(0f, 1f)
    )
}

@Composable
fun SystemDashboard() {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(readStats(ctx)) }
    LaunchedEffect(Unit) { while (true) { delay(5000); s = readStats(ctx) } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Gauge("PWR", s.battery, Modifier.weight(1f))
        Gauge("MEM", s.memory, Modifier.weight(1f))
        Gauge("DISK", s.storage, Modifier.weight(1f))
    }
}

@Composable
fun Gauge(label: String, value: Float, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, JarvisCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Text("$label ${(value * 100).toInt()}%", color = JarvisCyan, fontFamily = Mono, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = { value }, modifier = Modifier.fillMaxWidth(),
            color = JarvisCyan, trackColor = JarvisCyan.copy(alpha = 0.15f))
    }
}

@Composable
fun Bubble(m: Msg) {
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier.widthIn(max = 300.dp).clip(shape)
                .background(if (m.fromUser) Color(0xFF0B2A33) else JarvisPanel)
                .border(1.dp, JarvisCyan.copy(alpha = if (m.fromUser) 0.6f else 0.25f), shape)
                .padding(10.dp)
        ) { Text(m.text, color = JarvisText, fontSize = 14.sp) }
    }
}

@Composable
fun MicButton(listening: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(56.dp).clip(CircleShape)
            .background(if (listening) JarvisCyan else JarvisPanel)
            .border(1.5.dp, JarvisCyan, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(if (listening) "■" else "MIC", color = if (listening) Color.Black else JarvisCyan,
            fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun SettingsDialog(vm: JarvisViewModel, onToggleWake: (Boolean) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var prov by remember { mutableStateOf(vm.provider) }
    var key by remember(prov) { mutableStateOf("") }
    var model by remember(prov) { mutableStateOf(vm.modelFor(prov)) }
    var name by remember { mutableStateOf(vm.ownerName) }
    var word by remember { mutableStateOf(vm.wakeWord) }
    var backend by remember { mutableStateOf(vm.backendUrl) }
    var token by remember { mutableStateOf("") }
    fun save() = vm.saveSettings(prov, key, model, name, word, backend, token)

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF05161A),
        title = { Text("SYSTEM CONFIG", color = JarvisCyan, fontFamily = Mono) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AI provider", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AiProvider.values().forEach { p ->
                        if (p == prov) {
                            Button(onClick = { prov = p }, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text(p.short) }
                        } else {
                            OutlinedButton(onClick = { prov = p }, modifier = Modifier.weight(1f)) { Text(p.short) }
                        }
                    }
                }
                OutlinedTextField(key, { key = it }, singleLine = true,
                    label = { Text(if (vm.keySaved(prov)) "${prov.short} API key (saved; paste to replace)" else "${prov.short} API key") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(model, { model = it }, singleLine = true,
                    label = { Text("Model (default: ${vm.defaultModel(prov)})") })
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("What should I call you?") })
                OutlinedTextField(word, { word = it }, singleLine = true, label = { Text("Wake word") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Listen for wake word", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.wakeEnabled, { onToggleWake(it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Continuous conversation", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.continuous, { vm.continuous = it })
                }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }) { Text("Allow opening over other apps…") }
                OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                    Text("Notification access…")
                }
                Text("Optional secure backend", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                OutlinedTextField(backend, { backend = it }, singleLine = true,
                    label = { Text("Backend URL (https://…, leave empty for direct)") })
                OutlinedTextField(token, { token = it }, singleLine = true,
                    label = { Text("Backend token (paste to set)") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedButton(onClick = { save(); onClose(); vm.testConnection() }) { Text("Save and test connection") }
                Text("Keys are stored encrypted on this phone only. With a backend, the AI key stays on the server instead.",
                    color = JarvisText.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton({ save(); onClose() }) { Text("SAVE") } },
        dismissButton = { TextButton(onClose) { Text("CLOSE") } }
    )
}
