package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speech-to-text (SpeechRecognizer) and text-to-speech (TextToSpeech). Create on the main thread. */
class Voice(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onListening: (Boolean) -> Unit,
    private val onSpeechDone: () -> Unit,
    private val onFail: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx) { status ->
        if (status == TextToSpeech.SUCCESS) { ready = true; setupVoice() }
    }

    private fun setupVoice() {
        tts.language = Locale.getDefault()
        tts.setPitch(1.05f)
        tts.setSpeechRate(1.0f)
        applyPreferredVoice(ctx, tts)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { onSpeechDone() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { onSpeechDone() } }
        })
    }

    fun speak(text: String) {
        if (!ready) { onSpeechDone(); return }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun stopSpeaking() { tts.stop() }

    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onListening(false)
            onFail("Speech recognition isn't available on this device."); return
        }
        stopListening()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(error: Int) {
                onListening(false)
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
                    onFail("I need microphone permission to hear you.")
            }
            override fun onResults(results: Bundle?) {
                onListening(false)
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onText(t)
            }
        })
        recognizer = r
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        })
    }

    fun stopListening() { recognizer?.destroy(); recognizer = null }

    /** Installed voices for the phone's language, so the user can pick one. */
    fun voiceNames(): List<String> = try {
        val lang = Locale.getDefault().language
        tts.voices.orEmpty().filter { it.locale.language == lang }.map { it.name }.sorted()
    } catch (e: Exception) { emptyList() }

    fun setVoice(name: String): Boolean {
        val v = tts.voices.orEmpty().firstOrNull { it.name == name } ?: return false
        return tts.setVoice(v) == TextToSpeech.SUCCESS
    }

    fun shutdown() { stopListening(); tts.stop(); tts.shutdown() }
}


/** Applies the voice the user picked in settings (if any). */
fun applyPreferredVoice(ctx: Context, tts: TextToSpeech) {
    val name = SecureStore(ctx).voiceName
    if (name.isEmpty()) return
    val v = tts.voices.orEmpty().firstOrNull { it.name == name } ?: return
    tts.setVoice(v)
}
