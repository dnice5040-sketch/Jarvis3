package com.jarvis.assistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Reminders that "call" you: at the set time Michelle rings like an incoming call, then speaks. */
object Reminders {
    data class R(val id: Int, val text: String, val at: Long, val daily: Boolean)

    fun all(ctx: Context): List<R> {
        val raw = SecureStore(ctx).remindersJson
        if (raw.isBlank()) return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                R(o.getInt("id"), o.getString("text"), o.getLong("at"), o.optBoolean("daily", false))
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun save(ctx: Context, list: List<R>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text).put("at", it.at).put("daily", it.daily)) }
        SecureStore(ctx).remindersJson = a.toString()
    }

    fun add(ctx: Context, text: String, at: Long, daily: Boolean): R {
        val list = all(ctx)
        var id = (System.currentTimeMillis() % 1_000_000L).toInt()
        while (list.any { it.id == id }) id++
        val r = R(id, text, at, daily)
        save(ctx, list + r)
        schedule(ctx, r)
        return r
    }

    fun cancelAll(ctx: Context) {
        all(ctx).forEach { cancel(ctx, it) }
        save(ctx, emptyList())
    }

    private fun firePi(ctx: Context, id: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, id, Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun schedule(ctx: Context, r: R) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(r.at, show), firePi(ctx, r.id))
    }

    private fun cancel(ctx: Context, r: R) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(firePi(ctx, r.id))
    }

    fun reschedule(ctx: Context) {
        val now = System.currentTimeMillis()
        val list = all(ctx).map { r -> if (r.at < now && r.daily) r.copy(at = nextDaily(r.at, now)) else r }
            .filter { it.at >= now || it.daily }
        save(ctx, list)
        list.forEach { schedule(ctx, it) }
    }

    fun fired(ctx: Context, r: R) {
        val rest = all(ctx).filter { it.id != r.id }
        if (r.daily) {
            val next = r.copy(at = nextDaily(r.at, System.currentTimeMillis()))
            save(ctx, rest + next)
            schedule(ctx, next)
        } else save(ctx, rest)
    }

    private fun nextDaily(at: Long, now: Long): Long {
        var t = at
        while (t <= now) t += 86_400_000L
        return t
    }

    /** Next time the clock shows [hour24]:[minute]: today if still ahead, otherwise tomorrow. */
    fun nextAt(hour24: Int, minute: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, hour24)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_MONTH, 1)
        return c.timeInMillis
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val r = Reminders.all(ctx).firstOrNull { it.id == id } ?: return
        Reminders.fired(ctx, r)
        val open = Intent(ctx, ReminderActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("text", r.text)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Michelle calls", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, r.id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentTitle("Michelle is calling")
            .setContentText(r.text)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(r.id, n)
        if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(ctx)) {
            try { ctx.startActivity(open) } catch (e: Exception) { }
        }
    }

    companion object { const val CH = "michelle_calls" }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { Reminders.reschedule(ctx) }
}
