package com.jarvis.assistant

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val Mono = FontFamily.Monospace

@Composable
fun JarvisScreen(vm: JarvisViewModel = viewModel()) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var tabIdx by rememberSaveable { mutableStateOf(0) }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleMic() else vm.notify("Microphone permission was denied. I can still read typed commands.")
    }
    fun onMic() {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok) vm.toggleMic() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun send() { vm.submit(input); input = "" }

    val wakePerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic) vm.setWake(true) else vm.notify("I need microphone permission to listen for the wake word.")
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        vm.permResult(res.values.any { it })
    }
    LaunchedEffect(vm.permRequest) { vm.permRequest?.let { permLauncher.launch(it.perms.toTypedArray()) } }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        vm.fileChosen(uri, ctx.contentResolver)
    }
    LaunchedEffect(vm.filePick) {
        if (vm.filePick != null) fileLauncher.launch(arrayOf("text/*", "application/json", "application/xml"))
    }
    fun onWakeToggle(on: Boolean) {
        if (!on) { vm.setWake(false); return }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        wakePerms.launch(perms.toTypedArray())
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .background(Brush.radialGradient(colors = listOf(Color(0xFF07302D), Color.Black), radius = 1500f))
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("M I C H E L L E", Modifier.align(Alignment.Center), color = JarvisCyan, fontFamily = Mono,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 3.sp)
                Box(Modifier.align(Alignment.CenterEnd)) { StatusIndicator(vm.status) }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tabIdx) {
                    0 -> HomeTab(vm)
                    1 -> ChatTab(vm)
                    else -> SuitTab(vm)
                }
            }
            vm.pending?.let {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.confirmPending() }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text("CONFIRM") }
                    OutlinedButton(onClick = { vm.cancelPending() }, modifier = Modifier.weight(1f)) { Text("CANCEL") }
                }
            }
            if (tabIdx == 1) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Type a message…") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() })
                    )
                    TextButton(onClick = { send() }) { Text("SEND", color = JarvisCyan, fontFamily = Mono) }
                }
            }
            BottomBar(tabIdx, vm.status == Status.LISTENING, { tabIdx = it }, { onMic() }, { showSettings = true })
        }
    }
    if (showSettings) SettingsDialog(vm, onToggleWake = { onWakeToggle(it) }) { showSettings = false }
}

@Composable
fun StatusIndicator(status: Status) {
    val label = when (status) {
        Status.STANDBY -> "STANDBY"; Status.LISTENING -> "LISTENING"
        Status.THINKING -> "PROCESSING"; Status.SPEAKING -> "SPEAKING"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (status == Status.STANDBY) JarvisCyan.copy(alpha = 0.4f) else JarvisCyan))
        Spacer(Modifier.width(6.dp))
        Text(label, color = JarvisCyan, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun ClockBlock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now).uppercase()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(time, color = JarvisText, fontFamily = Mono, fontSize = 30.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp)
        Text(date, color = JarvisCyan.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun ArcReactor(status: Status, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "reactor")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin"
    )
    val pulse by t.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween(if (status == Status.STANDBY) 2200 else 900, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ), label = "pulse"
    )
    val boost = when (status) {
        Status.LISTENING -> 0.15f + level * 0.35f
        Status.SPEAKING -> 0.25f
        Status.THINKING -> 0.1f
        Status.STANDBY -> 0f
    }
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(JarvisCyan.copy(alpha = 0.25f), r * 0.98f, c, style = Stroke(1.5.dp.toPx()))
        drawCircle(JarvisCyan.copy(alpha = 0.12f), r * 0.70f, c, style = Stroke(1.dp.toPx()))
        for (k in 0 until 3) rotate(spin + k * 120f, c) {
            drawArc(JarvisCyan, 0f, 70f, false, Offset(c.x - r * 0.85f, c.y - r * 0.85f),
                Size(r * 1.7f, r * 1.7f), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
        }
        for (k in 0 until 4) rotate(-spin * 1.6f + k * 90f, c) {
            drawArc(JarvisCyan.copy(alpha = 0.7f), 0f, 40f, false, Offset(c.x - r * 0.58f, c.y - r * 0.58f),
                Size(r * 1.16f, r * 1.16f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        val coreR = r * 0.38f * (pulse + boost) * 1.6f
        drawCircle(Brush.radialGradient(listOf(Color.White, JarvisCyan, Color.Transparent), c, coreR), coreR, c)
    }
}

@Composable
fun Waveform(status: Status, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase"
    )
    val amp = when (status) {
        Status.LISTENING -> 0.15f + level * 0.85f
        Status.SPEAKING -> 0.6f
        Status.THINKING -> 0.3f
        Status.STANDBY -> 0.06f
    }
    Canvas(modifier) {
        val n = 36
        val gap = size.width / n
        for (i in 0 until n) {
            val h = (size.height * (0.12f + amp * abs(sin(phase + i * 0.45f)))).coerceAtMost(size.height)
            val x = gap * i + gap / 2
            drawLine(JarvisCyan.copy(alpha = 0.35f + 0.65f * amp.coerceAtMost(1f)),
                Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = gap * 0.5f, cap = StrokeCap.Round)
        }
    }
}

data class Stats(val battery: Float, val memory: Float, val storage: Float)

fun readStats(ctx: Context): Stats {
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) / 100f
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val fs = StatFs(Environment.getDataDirectory().path)
    return Stats(
        bat.coerceIn(0f, 1f),
        (1f - mi.availMem.toFloat() / mi.totalMem.toFloat()).coerceIn(0f, 1f),
        (1f - fs.availableBytes.toFloat() / fs.totalBytes.toFloat()).coerceIn(0f, 1f)
    )
}

@Composable
fun SystemDashboard() {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(readStats(ctx)) }
    LaunchedEffect(Unit) { while (true) { delay(5000); s = readStats(ctx) } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Gauge("PWR", s.battery, Modifier.weight(1f))
        Gauge("MEM", s.memory, Modifier.weight(1f))
        Gauge("DISK", s.storage, Modifier.weight(1f))
    }
}

@Composable
fun Gauge(label: String, value: Float, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, JarvisCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Text("$label ${(value * 100).toInt()}%", color = JarvisCyan, fontFamily = Mono, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = { value }, modifier = Modifier.fillMaxWidth(),
            color = JarvisCyan, trackColor = JarvisCyan.copy(alpha = 0.15f))
    }
}

@Composable
fun Bubble(m: Msg) {
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier.widthIn(max = 300.dp).clip(shape)
                .background(if (m.fromUser) Color(0xFF0B2A33) else JarvisPanel)
                .border(1.dp, JarvisCyan.copy(alpha = if (m.fromUser) 0.6f else 0.25f), shape)
                .padding(10.dp)
        ) { Text(m.text, color = JarvisText, fontSize = 14.sp) }
    }
}

@Composable
fun MicButton(listening: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(56.dp).clip(CircleShape)
            .background(if (listening) JarvisCyan else JarvisPanel)
            .border(1.5.dp, JarvisCyan, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(if (listening) "■" else "MIC", color = if (listening) Color.Black else JarvisCyan,
            fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun SettingsDialog(vm: JarvisViewModel, onToggleWake: (Boolean) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var prov by remember { mutableStateOf(vm.provider) }
    var key by remember(prov) { mutableStateOf("") }
    var model by remember(prov) { mutableStateOf(vm.modelFor(prov)) }
    var name by remember { mutableStateOf(vm.ownerName) }
    var word by remember { mutableStateOf(vm.wakeWord) }
    var backend by remember { mutableStateOf(vm.backendUrl) }
    var token by remember { mutableStateOf("") }
    fun save() = vm.saveSettings(prov, key, model, name, word, backend, token)

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF05161A),
        title = { Text("SYSTEM CONFIG", color = JarvisCyan, fontFamily = Mono) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AI provider", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AiProvider.values().forEach { p ->
                        if (p == prov) {
                            Button(onClick = { prov = p }, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = Color.Black)) { Text(p.short) }
                        } else {
                            OutlinedButton(onClick = { prov = p }, modifier = Modifier.weight(1f)) { Text(p.short) }
                        }
                    }
                }
                OutlinedTextField(key, { key = it }, singleLine = true,
                    label = { Text(if (vm.keySaved(prov)) "${prov.short} API key (saved; paste to replace)" else "${prov.short} API key") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(model, { model = it }, singleLine = true,
                    label = { Text("Model (default: ${vm.defaultModel(prov)})") })
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("What should I call you?") })
                OutlinedTextField(word, { word = it }, singleLine = true, label = { Text("Wake word") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Listen for wake word", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.wakeEnabled, { onToggleWake(it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Continuous conversation", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.continuous, { vm.continuous = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Read notifications aloud", Modifier.weight(1f), color = JarvisText)
                    Switch(vm.readAloud, { vm.setReadAloud(it) })
                }
                OutlinedButton(onClick = { vm.cycleVoice() }) { Text("Change voice (now: " + vm.voiceLabel + ")") }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }) { Text("Allow opening over other apps…") }
                OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                    Text("Notification access…")
                }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }) { Text("Keep me running in background…") }
                Text("Optional secure backend", color = JarvisCyan, fontFamily = Mono, fontSize = 12.sp)
                OutlinedTextField(backend, { backend = it }, singleLine = true,
                    label = { Text("Backend URL (https://…, leave empty for direct)") })
                OutlinedTextField(token, { token = it }, singleLine = true,
                    label = { Text("Backend token (paste to set)") },
                    visualTransformation = PasswordVisualTransformation())
                OutlinedButton(onClick = { save(); onClose(); vm.testConnection() }) { Text("Save and test connection") }
                Text("Keys are stored encrypted on this phone only. With a backend, the AI key stays on the server instead.",
                    color = JarvisText.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton({ save(); onClose() }) { Text("SAVE") } },
        dismissButton = { TextButton(onClose) { Text("CLOSE") } }
    )
}


// =====================  Hologram look  =====================

private fun fibonacciSphere(n: Int): FloatArray {
    val out = FloatArray(n * 3)
    val golden = Math.PI * (3.0 - Math.sqrt(5.0))
    for (i in 0 until n) {
        val y = 1.0 - (i / (n - 1.0)) * 2.0
        val r = Math.sqrt(1.0 - y * y)
        val th = golden * i
        out[3 * i] = (Math.cos(th) * r).toFloat()
        out[3 * i + 1] = y.toFloat()
        out[3 * i + 2] = (Math.sin(th) * r).toFloat()
    }
    return out
}

@Composable
fun HomeTab(vm: JarvisViewModel) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ClockBlock()
        Spacer(Modifier.height(4.dp))
        HoloSphere(vm.status, vm.level, Modifier.weight(1f).fillMaxWidth())
        val last = vm.messages.lastOrNull { !it.fromUser }?.text.orEmpty()
        Text(
            last, color = JarvisText.copy(alpha = 0.85f), fontSize = 15.sp, textAlign = TextAlign.Center,
            maxLines = 3, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp).heightIn(min = 64.dp)
        )
        Waveform(vm.status, vm.level, Modifier.fillMaxWidth().height(28.dp).padding(horizontal = 28.dp))
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ChatTab(vm: JarvisViewModel) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 14.dp), state = listState,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { items(vm.messages) { Bubble(it) } }
}

@Composable
fun HoloSphere(status: Status, level: Float, modifier: Modifier = Modifier) {
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { time.floatValue = it / 1_000_000_000f } } }
    val sphere = remember { fibonacciSphere(420) }
    val noise = remember { FloatArray(900) { kotlin.random.Random(it).nextFloat() } }
    val target = when (status) {
        Status.LISTENING -> 0.25f + level * 0.9f
        Status.SPEAKING -> 0.55f
        Status.THINKING -> 0.35f
        Status.STANDBY -> 0.08f
    }
    val amp by animateFloatAsState(target, label = "amp")
    Canvas(modifier) {
        val t = time.floatValue
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = min(size.width, size.height) / 2f * 0.95f
        val a = if (status == Status.SPEAKING) amp * (0.6f + 0.4f * sin(t * 9f)) else amp

        drawCircle(JarvisCyan.copy(alpha = 0.22f), r * 0.98f, Offset(cx, cy), style = Stroke(1.dp.toPx()))
        drawCircle(JarvisCyan.copy(alpha = 0.12f), r * 0.60f, Offset(cx, cy), style = Stroke(1.dp.toPx()))

        // wobbling particle rings
        val rings = 3
        val per = 300
        val ring = ArrayList<Offset>(rings * per)
        for (k in 0 until rings) {
            val base = r * (0.84f - k * 0.045f)
            for (i in 0 until per) {
                val th = (i / per.toFloat()) * 6.2831855f
                val nz = noise[(k * per + i) % noise.size]
                val wob = a * 0.07f * r * (sin(3f * th + t * 1.3f + k) + 0.6f * sin(5f * th - t * 0.9f))
                val jit = (nz - 0.5f) * r * 0.035f * (1f + a * 2f)
                val rr = base + wob + jit
                ring.add(Offset(cx + rr * cos(th), cy + rr * sin(th)))
            }
        }
        drawPoints(ring, PointMode.Points, JarvisCyan.copy(alpha = 0.85f), 2.4.dp.toPx(), StrokeCap.Round)

        // rotating particle globe
        val rotY = t * (if (status == Status.THINKING) 1.3f else 0.35f)
        val tilt = 0.45f
        val sr = r * 0.42f * (1f + a * 0.10f)
        val cY = cos(rotY); val sY = sin(rotY); val cX = cos(tilt); val sX = sin(tilt)
        val front = ArrayList<Offset>()
        val back = ArrayList<Offset>()
        for (i in 0 until sphere.size / 3) {
            val x = sphere[3 * i]; val y = sphere[3 * i + 1]; val z = sphere[3 * i + 2]
            val x1 = x * cY + z * sY
            val z1 = -x * sY + z * cY
            val y2 = y * cX - z1 * sX
            val z2 = y * sX + z1 * cX
            val p = Offset(cx + x1 * sr, cy + y2 * sr)
            if (z2 > 0f) front.add(p) else back.add(p)
        }
        drawCircle(
            Brush.radialGradient(listOf(JarvisCyan.copy(alpha = 0.30f), Color.Transparent), Offset(cx, cy), sr * 1.35f),
            sr * 1.35f, Offset(cx, cy)
        )
        drawPoints(back, PointMode.Points, JarvisCyan.copy(alpha = 0.30f), 1.6.dp.toPx(), StrokeCap.Round)
        drawPoints(front, PointMode.Points, JarvisCyan.copy(alpha = 0.95f), 2.8.dp.toPx(), StrokeCap.Round)
    }
}

private fun DrawScope.polyline(pts: List<Pair<Float, Float>>, close: Boolean, ox: Float, oy: Float, s: Float) {
    val p = Path()
    pts.forEachIndexed { i, pt ->
        val px = ox + pt.first * s
        val py = oy + pt.second * s
        if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
    }
    if (close) p.close()
    drawPath(p, JarvisCyan.copy(alpha = 0.18f), style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(p, JarvisCyan, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.drawSuit(t: Float) {
    val s = min(size.width / 100f, size.height / 140f) * 0.95f
    val ox = (size.width - 100f * s) / 2f
    val oy = (size.height - 140f * s) / 2f
    fun mir(p: List<Pair<Float, Float>>) = p.map { (100f - it.first) to it.second }

    val head = listOf(50f to 4f, 62f to 6f, 72f to 16f, 78f to 32f, 80f to 50f, 76f to 64f, 70f to 78f, 62f to 92f, 54f to 100f, 50f to 102f)
    polyline(head + mir(head).reversed(), true, ox, oy, s)
    val plate = listOf(50f to 20f, 64f to 26f, 70f to 40f, 68f to 58f, 62f to 72f, 54f to 84f, 50f to 86f)
    polyline(plate + mir(plate).reversed(), true, ox, oy, s)
    val eye = listOf(56f to 44f, 68f to 42f, 70f to 48f, 58f to 52f)
    polyline(eye, true, ox, oy, s)
    polyline(mir(eye), true, ox, oy, s)
    polyline(listOf(42f to 92f, 58f to 92f), false, ox, oy, s)
    polyline(listOf(44f to 98f, 56f to 98f), false, ox, oy, s)
    val shoulder = listOf(38f to 100f, 24f to 106f, 8f to 118f, 0f to 140f)
    polyline(shoulder, false, ox, oy, s)
    polyline(mir(shoulder), false, ox, oy, s)
    val chest = listOf(38f to 100f, 36f to 118f, 30f to 140f)
    polyline(chest, false, ox, oy, s)
    polyline(mir(chest), false, ox, oy, s)

    val c = Offset(ox + 50f * s, oy + 124f * s)
    drawCircle(JarvisCyan.copy(alpha = 0.25f), 13f * s, c, style = Stroke(5.dp.toPx()))
    drawCircle(JarvisCyan, 9f * s, c, style = Stroke(1.6.dp.toPx()))
    drawCircle(JarvisCyan.copy(alpha = 0.8f), 5f * s, c, style = Stroke(1.2.dp.toPx()))
    drawCircle(Brush.radialGradient(listOf(Color.White, JarvisCyan, Color.Transparent), c, 8f * s), 8f * s, c)

    val y = oy + ((t * 0.25f) % 1f) * 140f * s
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, JarvisCyan.copy(alpha = 0.25f)), startY = y - 30f * s, endY = y),
        topLeft = Offset(ox - 10f * s, y - 30f * s), size = Size(120f * s, 30f * s)
    )
    drawLine(JarvisCyan, Offset(ox - 10f * s, y), Offset(ox + 110f * s, y), 1.5.dp.toPx())
}

@Composable
fun SuitTab(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var st by remember { mutableStateOf(readStats(ctx)) }
    LaunchedEffect(Unit) { while (true) { delay(3000); st = readStats(ctx) } }
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { time.floatValue = it / 1_000_000_000f } } }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Canvas(Modifier.weight(1f).fillMaxWidth()) { drawSuit(time.floatValue) }
        Spacer(Modifier.height(8.dp))
        Text("POWER LEVEL  " + "%.1f".format(st.battery * 100f) + "%", color = JarvisCyan, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = { st.battery }, modifier = Modifier.fillMaxWidth(),
            color = JarvisCyan, trackColor = JarvisCyan.copy(alpha = 0.15f))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Gauge("MEM", st.memory, Modifier.weight(1f))
            Gauge("DISK", st.storage, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "AI CORE  " + vm.provider.short.uppercase() + "     WAKE WORD  " + (if (vm.wakeEnabled) "ON" else "OFF"),
            color = JarvisText.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp
        )
        Spacer(Modifier.height(10.dp))
    }
}

private fun DrawScope.drawNavIcon(kind: Int, color: Color) {
    val s = size.minDimension
    val w = s * 0.08f
    val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val c = Offset(s / 2f, s / 2f)
    when (kind) {
        0 -> {
            drawCircle(color, s * 0.42f, c, style = st)
            drawLine(color, c, Offset(c.x, c.y - s * 0.25f), w, StrokeCap.Round)
            drawLine(color, c, Offset(c.x + s * 0.18f, c.y + s * 0.08f), w, StrokeCap.Round)
        }
        1 -> {
            drawRoundRect(color, topLeft = Offset(s * 0.08f, s * 0.12f), size = Size(s * 0.84f, s * 0.6f),
                cornerRadius = CornerRadius(s * 0.14f), style = st)
            val tail = Path()
            tail.moveTo(s * 0.3f, s * 0.72f); tail.lineTo(s * 0.24f, s * 0.92f); tail.lineTo(s * 0.5f, s * 0.72f)
            drawPath(tail, color, style = st)
        }
        2 -> {
            val h = Path()
            h.moveTo(s * 0.2f, s * 0.15f); h.lineTo(s * 0.8f, s * 0.15f); h.lineTo(s * 0.88f, s * 0.55f)
            h.lineTo(s * 0.7f, s * 0.9f); h.lineTo(s * 0.5f, s * 0.95f); h.lineTo(s * 0.3f, s * 0.9f)
            h.lineTo(s * 0.12f, s * 0.55f); h.close()
            drawPath(h, color, style = st)
            drawLine(color, Offset(s * 0.28f, s * 0.5f), Offset(s * 0.45f, s * 0.56f), w, StrokeCap.Round)
            drawLine(color, Offset(s * 0.72f, s * 0.5f), Offset(s * 0.55f, s * 0.56f), w, StrokeCap.Round)
        }
        else -> {
            drawCircle(color, s * 0.2f, c, style = st)
            for (k in 0 until 8) {
                val ang = k * 0.7853982f
                drawLine(color, Offset(c.x + s * 0.3f * cos(ang), c.y + s * 0.3f * sin(ang)),
                    Offset(c.x + s * 0.44f * cos(ang), c.y + s * 0.44f * sin(ang)), w * 1.4f, StrokeCap.Round)
            }
        }
    }
}

@Composable
fun NavIcon(selected: Boolean, kind: Int, onClick: () -> Unit) {
    val color = if (selected) JarvisCyan else JarvisCyan.copy(alpha = 0.55f)
    Box(
        Modifier.size(50.dp).clip(CircleShape)
            .then(if (selected) Modifier.border(1.dp, JarvisCyan.copy(alpha = 0.6f), CircleShape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Canvas(Modifier.size(26.dp)) { drawNavIcon(kind, color) } }
}

@Composable
fun MicBig(listening: Boolean, onClick: () -> Unit) {
    val tr = rememberInfiniteTransition(label = "mic")
    val pulse by tr.animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pulse"
    )
    Box(Modifier.size(68.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            if (listening) drawCircle(JarvisCyan.copy(alpha = 0.25f * pulse), r * 0.98f, c)
            drawCircle(JarvisCyan, r * 0.9f, c, style = Stroke(2.dp.toPx()))
            drawCircle(JarvisCyan.copy(alpha = 0.35f), r * 0.74f, c, style = Stroke(1.dp.toPx()))
            val w = r * 0.26f
            drawRoundRect(JarvisCyan, topLeft = Offset(c.x - w / 2f, c.y - r * 0.38f), size = Size(w, r * 0.5f),
                cornerRadius = CornerRadius(w / 2f), style = Stroke(2.dp.toPx()))
            drawArc(JarvisCyan, 0f, 180f, false, Offset(c.x - r * 0.26f, c.y - r * 0.2f), Size(r * 0.52f, r * 0.42f),
                style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            drawLine(JarvisCyan, Offset(c.x, c.y + r * 0.22f), Offset(c.x, c.y + r * 0.38f), 2.dp.toPx())
        }
    }
}

@Composable
fun BottomBar(tab: Int, listening: Boolean, onTab: (Int) -> Unit, onMic: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF031A19))) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(JarvisCyan.copy(alpha = 0.4f)))
        Row(
            Modifier.fillMaxWidth().height(76.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            NavIcon(tab == 0, 0) { onTab(0) }
            NavIcon(tab == 1, 1) { onTab(1) }
            MicBig(listening, onMic)
            NavIcon(false, 3) { onSettings() }
            NavIcon(tab == 2, 2) { onTab(2) }
        }
    }
}
