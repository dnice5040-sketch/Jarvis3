package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** The text that is visible on the screen right now, in reading order. */
class ScreenSnapshot(val pkg: String, val items: List<String>)

/** Lets Jarvis read the screen, press Back/Home/Recents, scroll and tap. Works only if the owner enabled it in Accessibility settings. */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        SecureStore.of(applicationContext).screenControlSeen = true
        getSystemService(android.app.NotificationManager::class.java).cancel(9002)
        val info = serviceInfo
        if (info != null) {
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            serviceInfo = info
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = event.packageName?.toString()
            if (p != null && p != "com.android.systemui") lastPackage = p
        }
    }

    override fun onInterrupt() { }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        if (SecureStore.of(applicationContext).screenControlSeen) Proactive.screenControlOff(applicationContext)
        return super.onUnbind(intent)
    }

    /** The app that is in front, or null if Android won't say. */
    fun foregroundPackage(): String? = rootInActiveWindow?.packageName?.toString() ?: lastPackage

    /** Visible text on screen. Password fields and text boxes are never read. */
    fun snapshot(): ScreenSnapshot? {
        val root = rootInActiveWindow ?: return null
        val found = ArrayList<Triple<Int, Int, String>>()
        collect(root, found, 0)
        val seen = LinkedHashSet<String>()
        for (t in found.sortedWith(compareBy<Triple<Int, Int, String>>({ it.first }, { it.second }))) {
            seen.add(t.third.take(120))
        }
        return ScreenSnapshot(root.packageName?.toString().orEmpty(), seen.toList())
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<Triple<Int, Int, String>>, depth: Int) {
        if (depth > 40 || out.size > 500) return
        if (n.isPassword) return
        if (n.isVisibleToUser && !n.isEditable) {
            val t = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
            if (t.isNotEmpty()) {
                val r = Rect()
                n.getBoundsInScreen(r)
                out.add(Triple(r.top, r.left, t))
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            collect(c, out, depth + 1)
        }
    }

    fun scrollScreen(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val f = findScrollable(c)
            if (f != null) return f
        }
        return null
    }

    fun clickText(what: String, blocked: Regex): String {
        val root = rootInActiveWindow ?: return "I can't see the screen right now."
        val nodes = root.findAccessibilityNodeInfosByText(what)
        if (nodes.isNullOrEmpty()) return "I couldn't find \"$what\" on the screen."
        for (node in nodes) {
            var target: AccessibilityNodeInfo? = node
            while (target != null && !target.isClickable) target = target.parent
            if (target == null) continue
            val label = node.text?.toString().orEmpty() + " " + node.contentDescription?.toString().orEmpty()
            if (blocked.containsMatchIn(label)) return "I won't tap that because it looks like a payment or a deletion. Please do it yourself."
            if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped $what."
        }
        return "I found \"$what\" but couldn't tap it."
    }

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
        @Volatile var lastPackage: String? = null
    }
}

object ScreenControl {
    private val rx = RegexOption.IGNORE_CASE
    private val blocked = Regex(
        "pay|buy|purchase|order|send money|transfer|delete|uninstall|factory reset|erase|checkout|confirm payment", rx
    )

    private fun m(p: String, s: String) = Regex(p, rx).matchEntire(s)

    /** True when Android lists Jarvis screen control as switched on (even if it has not connected yet). */
    fun enabledInAndroid(ctx: Context): Boolean {
        val v = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        return v.contains(ctx.packageName + "/", true) && v.contains("JarvisAccessibilityService", true)
    }

    private fun needService(ctx: Context): ActionResult {
        try {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
        return ActionResult.Done("To control the screen I need Accessibility access. I've opened the setting. Enable Jarvis screen control there, then ask again.")
    }

    fun appLabel(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { if (pkg.isEmpty()) "an unknown app" else pkg }

    /** Waits (off the main thread) until [pkg] is the app in front. */
    fun waitForApp(pkg: String, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (JarvisAccessibilityService.instance?.foregroundPackage() == pkg) {
                try { Thread.sleep(700) } catch (e: InterruptedException) { }
                return true
            }
            try { Thread.sleep(250) } catch (e: InterruptedException) { return false }
        }
        return false
    }

    /** What is on the screen, as a sentence Jarvis can say. Reads only what Accessibility exposes. */
    fun describeScreen(ctx: Context): String {
        val svc = JarvisAccessibilityService.instance
            ?: return "Screen control isn't switched on yet. Open the Control Center and enable Jarvis screen control in Accessibility."
        val snap = svc.snapshot() ?: return "I can't see the screen right now."
        if (snap.pkg == ctx.packageName) return "You're in Jarvis itself. Open another app first, then ask me to read the screen."
        val app = appLabel(ctx, snap.pkg)
        if (snap.items.isEmpty()) return "You're in $app, but I can't read any text here. The app may hide its content from accessibility."
        val spoken = snap.items.take(12)
        return "In $app I can see: " + spoken.joinToString("; ") +
            if (snap.items.size > 12) ". Plus " + (snap.items.size - 12) + " more items. Say summarize the screen for a short summary." else "."
    }

    fun handle(ctx: Context, s: String): ActionResult? {
        m("(?:test|check) (?:the |my )?screen control", s)?.let {
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            return ActionResult.Later {
                val snap = svc.snapshot()
                "Screen control is connected. The front app is " + appLabel(ctx, snap?.pkg.orEmpty()) +
                    " and I can read " + (snap?.items?.size ?: 0) + " text items."
            }
        }
        m("(?:tell me |show me )?what(?:'s| is) (?:on|in) (?:my |the )?(?:screen|display)|what do you see(?: on (?:my |the )?screen)?|what am i looking at|(?:read|describe)(?: out)?(?: what(?:'s| is) on)?(?: to me)? (?:my |the )?(?:screen|display)|read (?:my |the )?screen(?: to me)?", s)?.let {
            if (JarvisAccessibilityService.instance == null) return needService(ctx)
            return ActionResult.Later { describeScreen(ctx) }
        }
        m("summari[sz]e (?:my |the )?(?:screen|display)", s)?.let {
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            val snap = svc.snapshot() ?: return ActionResult.Done("I can't see the screen right now.")
            if (snap.pkg == ctx.packageName) return ActionResult.Done("You're in Jarvis itself. Open another app first.")
            if (snap.items.isEmpty()) return ActionResult.Done("There's no readable text on this screen.")
            return ActionResult.ConfirmAsk(
                "I'll send the text that is visible on your screen to the AI so it can summarize it.",
                "Summarize this phone screen in two or three short sentences. App: " + appLabel(ctx, snap.pkg) +
                    ". Visible text:\n" + snap.items.take(60).joinToString("\n")
            )
        }

        val glob: Pair<Int, String>? = when {
            m("(?:go|press|return) (?:to )?(?:the )?home(?: screen)?|show (?:the )?home screen", s) != null ->
                AccessibilityService.GLOBAL_ACTION_HOME to "Going home."
            m("(?:go|press|navigate) back", s) != null ->
                AccessibilityService.GLOBAL_ACTION_BACK to "Going back."
            m("(?:open|show) (?:the )?(?:recent apps|recents|app switcher)", s) != null ->
                AccessibilityService.GLOBAL_ACTION_RECENTS to "Here are your recent apps."
            m("(?:pull down|open|show) (?:the )?notification (?:panel|shade|bar)", s) != null ->
                AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS to "Opening the notification panel."
            m("(?:pull down|open|show) (?:the )?quick settings", s) != null ->
                AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS to "Opening quick settings."
            Build.VERSION.SDK_INT >= 28 && m("take a screenshot|screenshot", s) != null ->
                AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT to "Screenshot taken."
            Build.VERSION.SDK_INT >= 28 && m("lock (?:the )?(?:screen|phone)", s) != null ->
                AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN to "Locking the screen."
            else -> null
        }
        if (glob != null) {
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            return ActionResult.Done(if (svc.performGlobalAction(glob.first)) glob.second else "That didn't work on this screen.")
        }
        m("scroll (down|up)", s)?.let { r ->
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            val dir = r.groupValues[1].lowercase()
            return ActionResult.Done(if (svc.scrollScreen(dir == "down")) "Scrolling $dir." else "I can't scroll this screen.")
        }
        m("(?:tap|click) (?:on )?(?:the )?(.+)", s)?.let { r ->
            val what = r.groupValues[1].trim()
            if (blocked.containsMatchIn(what)) {
                return ActionResult.Done("I won't tap \"$what\" by voice because it could spend money or delete something. Please do that yourself.")
            }
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            return ActionResult.Done(svc.clickText(what, blocked))
        }
        return null
    }
}
