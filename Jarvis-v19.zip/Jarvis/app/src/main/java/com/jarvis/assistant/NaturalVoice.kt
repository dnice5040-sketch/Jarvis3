package com.jarvis.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicReference

/**
 * A more natural voice from Google's Gemini speech models (preset voices, using your own Gemini key).
 * Text is cut into sentences; the next sentence is fetched while the current one plays.
 * If anything fails (no internet, quota, wrong model) the phone's own voice speaks instead.
 */
class NaturalVoice(private val ctx: Context, private val finished: () -> Unit) {
    private class Chunk(val pcm: ByteArray, val rate: Int)

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var generation = 0
    @Volatile private var track: AudioTrack? = null
    @Volatile private var badUntil = 0L

    fun usable(store: SecureStore): Boolean =
        store.naturalVoice && !store.offlineMode && store.geminiKey.isNotBlank() &&
            SystemClock.elapsedRealtime() >= badUntil && Net.online(ctx)

    fun voiceName(store: SecureStore): String {
        val list = voicesFor(store.voiceGender)
        return if (list.contains(store.naturalVoiceName)) store.naturalVoiceName else list[0]
    }

    fun speak(text: String, store: SecureStore, fallback: () -> Unit) {
        generation++
        val gen = generation
        val key = store.geminiKey
        val voice = voiceName(store)
        val model = store.ttsModel.ifBlank { DEFAULT_MODEL }
        val chunks = split(text.take(1200))
        exec.execute { play(gen, chunks, voice, key, model, fallback) }
    }

    /** Stops at once (does not call the "finished" callback, like the phone voice). */
    fun stop() {
        generation++
        val t = track
        if (t != null) {
            try { t.pause(); t.flush() } catch (e: Exception) { }
        }
    }

    fun shutdown() {
        stop()
        exec.shutdownNow()
    }

    private fun newTrack(rate: Int): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, rate))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun releaseTrack(t: AudioTrack?) {
        try { t?.release() } catch (e: Exception) { }
        track = null
    }

    private fun play(gen: Int, chunks: List<String>, voice: String, key: String, model: String, fallback: () -> Unit) {
        val queue = LinkedBlockingQueue<Chunk>(3)
        val end = Chunk(ByteArray(0), 0)
        val error = AtomicReference<String?>(null)
        val producer = Thread {
            try {
                for (c in chunks) {
                    if (gen != generation) break
                    queue.put(fetch(c, voice, key, model))
                }
            } catch (e: Exception) {
                error.set(e.message ?: "unknown error")
            } finally {
                try { queue.put(end) } catch (e: InterruptedException) { }
            }
        }
        producer.start()

        var t: AudioTrack? = null
        var frames = 0L
        var started = false
        try {
            while (true) {
                val c = queue.take()
                if (c === end || gen != generation) break
                if (t == null) {
                    t = newTrack(c.rate)
                    track = t
                    t.play()
                }
                var off = 0
                while (off < c.pcm.size && gen == generation) {
                    val n = t.write(c.pcm, off, minOf(4096, c.pcm.size - off))
                    if (n <= 0) break
                    off += n
                }
                frames += (c.pcm.size / 2).toLong()
                started = true
            }
        } catch (e: InterruptedException) { }

        val err = error.get()
        if (gen != generation) {
            releaseTrack(t)
            return
        }
        if (!started) {
            lastError = err ?: "no audio came back"
            badUntil = SystemClock.elapsedRealtime() + 120_000L
            releaseTrack(t)
            main.post { if (gen == generation) fallback() }
            return
        }
        if (t != null) {
            try { t.stop() } catch (e: Exception) { }
            val deadline = System.currentTimeMillis() + 15_000L
            while (gen == generation && System.currentTimeMillis() < deadline && t.playbackHeadPosition < frames) {
                try { Thread.sleep(40) } catch (e: InterruptedException) { break }
            }
        }
        releaseTrack(t)
        lastError = err ?: ""
        main.post { if (gen == generation) finished() }
    }

    // ---- talking to the speech model ---------------------------------------------------------------

    private fun fetch(text: String, voice: String, key: String, model: String): Chunk {
        val order = if (workingVariant >= 0) listOf(workingVariant) else listOf(0, 1, 2)
        var last = "no answer"
        for (v in order) {
            val m = if (v == 0) model else ALT_MODEL
            val r = post(m, body(v, text, voice), key)
            if (r.first in 200..299) {
                val c = parse(r.second)
                if (c != null) {
                    workingVariant = v
                    return c
                }
                last = "the reply had no audio"
            } else {
                last = describe(r.first, r.second)
                if (r.first == 429 || r.first == 401 || r.first == 403) break
            }
        }
        throw IllegalStateException(last)
    }

    private fun body(variant: Int, text: String, voice: String): JSONObject {
        val voiceCfg = if (variant == 1) JSONObject().put("voice", voice)
        else JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
        val gen = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", JSONObject().put("voiceConfig", voiceCfg))
        val content = JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))
        return JSONObject().put("contents", JSONArray().put(content)).put("generationConfig", gen)
    }

    private fun post(model: String, body: JSONObject, key: String): Pair<Int, String> {
        val c = URL(BASE + model + ":generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 40000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return Pair(code, stream?.bufferedReader()?.use { it.readText() } ?: "")
        } finally {
            c.disconnect()
        }
    }

    private fun parse(body: String): Chunk? = try {
        val part = JSONObject(body).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
        val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data")
        val data = inline?.optString("data").orEmpty()
        if (inline == null || data.isEmpty()) null else {
            val mime = inline.optString("mimeType", inline.optString("mime_type", ""))
            val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
            Chunk(Base64.decode(data, Base64.DEFAULT), rate)
        }
    } catch (e: Exception) { null }

    private fun describe(code: Int, body: String): String {
        val msg = try { JSONObject(body).optJSONObject("error")?.optString("message").orEmpty() } catch (e: Exception) { "" }
        val reason = when (code) {
            429 -> "quota or rate limit reached"
            401, 403 -> "the key was refused"
            404 -> "speech model not found"
            else -> "error $code"
        }
        return if (msg.isEmpty()) reason else reason + ": " + msg.take(100)
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.1-flash-tts-preview"
        private const val ALT_MODEL = "gemini-3.8-flash-tts"
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
        val MALE = listOf("Charon", "Fenrir", "Orus", "Puck")
        val FEMALE = listOf("Kore", "Zephyr", "Leda", "Aoede")
        @Volatile var lastError: String = ""
        @Volatile private var workingVariant = -1

        fun voicesFor(gender: String): List<String> = if (gender == "female") FEMALE else MALE

        /** First sentence alone (so speech starts quickly), then the rest in groups. */
        fun split(text: String): List<String> {
            val sentences = text.replace("\n", " ").split(Regex("(?<=[.!?])\\s+")).filter { it.isNotBlank() }
            if (sentences.size <= 1) return listOf(text.trim())
            val out = ArrayList<String>()
            out.add(sentences[0])
            var cur = StringBuilder()
            for (s in sentences.drop(1)) {
                if (cur.isNotEmpty() && cur.length + s.length > 220) {
                    out.add(cur.toString())
                    cur = StringBuilder()
                }
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(s)
            }
            if (cur.isNotEmpty()) out.add(cur.toString())
            return out
        }
    }
}
