package com.jarvis.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.sin

/** The small pill at the top of the screen (like Siri) that shows what Jarvis is doing. */
class HudView(ctx: Context) : View(ctx) {
    var hudState = 0          // 0 listening, 1 thinking, 2 speaking
    var hudLevel = 0f
    var hudCaption = ""
        set(value) { field = value; textLayout = null }

    private var textLayout: StaticLayout? = null
    private val dens = ctx.resources.displayMetrics.density
    private val rect = RectF()
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(238, 2, 8, 18) }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.2f * dens; color = Color.argb(140, 38, 198, 255)
    }
    private val orb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(255, 38, 198, 255) }
    private val ripple = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.6f * dens; color = Color.argb(255, 38, 198, 255)
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.4f * dens; strokeCap = Paint.Cap.ROUND
        color = Color.argb(255, 38, 198, 255)
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(255, 214, 241, 255); textSize = 14f * dens
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = (System.nanoTime() / 1_000_000L) / 1000f

        rect.set(1f, 1f, w - 1f, h - 1f)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, pill)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, edge)

        val cx = h / 2f
        val cy = h / 2f
        val r = h * 0.20f
        when (hudState) {
            0 -> {
                for (k in 0 until 3) {
                    val ph = (t * 0.9f + k / 3f) % 1f
                    ripple.alpha = ((1f - ph) * 170f).toInt()
                    canvas.drawCircle(cx, cy, r * (1f + ph * (0.7f + hudLevel)), ripple)
                }
                canvas.drawCircle(cx, cy, r * (0.9f + 0.25f * hudLevel), orb)
            }
            1 -> {
                rect.set(cx - r * 1.5f, cy - r * 1.5f, cx + r * 1.5f, cy + r * 1.5f)
                canvas.drawArc(rect, (t * 260f) % 360f, 110f, false, arcPaint)
                canvas.drawCircle(cx, cy, r * 0.7f, orb)
            }
            else -> {
                val bw = r * 0.55f
                for (k in 0 until 5) {
                    val bh = r * (0.5f + 1.5f * abs(sin(t * 7f + k * 1.3f)))
                    val x = cx + (k - 2) * bw * 1.7f
                    rect.set(x - bw / 2f, cy - bh, x + bw / 2f, cy + bh)
                    canvas.drawRoundRect(rect, bw / 2f, bw / 2f, orb)
                }
            }
        }

        val avail = (w - h * 1.1f - h * 0.35f).toInt()
        if (avail > 10) {
            var layout = textLayout
            if (layout == null) {
                val c = hudCaption
                layout = StaticLayout.Builder.obtain(c, 0, c.length, textPaint, avail)
                    .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
                textLayout = layout
            }
            canvas.save()
            canvas.translate(h * 1.05f, (h - layout.height) / 2f)
            layout.draw(canvas)
            canvas.restore()
        }
        postInvalidateOnAnimation()
    }
}

class AssistantHud(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var hud: HudView? = null

    private fun allowed() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    /** state: 0 listening, 1 thinking, 2 speaking. Does nothing if "Display over other apps" is not allowed. */
    fun show(state: Int, caption: String) {
        if (!allowed()) return
        handler.removeCallbacksAndMessages(null)
        var v = hud
        if (v == null) {
            v = HudView(ctx)
            val d = ctx.resources.displayMetrics.density
            val lp = WindowManager.LayoutParams(
                (300 * d).toInt(), (64 * d).toInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = (36 * d).toInt()
            try { wm.addView(v, lp) } catch (e: Exception) { return }
            hud = v
        }
        v.hudState = state
        v.hudCaption = caption
    }

    fun level(l: Float) { hud?.hudLevel = l }

    fun hide(delayMs: Long) {
        handler.removeCallbacksAndMessages(null)
        if (delayMs <= 0L) remove() else handler.postDelayed({ remove() }, delayMs)
    }

    private fun remove() {
        val v = hud ?: return
        hud = null
        try { wm.removeView(v) } catch (e: Exception) { }
    }
}
