package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.Executors

/**
 * JARVIS in the background. While another app is on screen it:
 *  1. listens for the wake word,
 *  2. answers out loud ("Yes, Sam?"), listens for a command,
 *  3. runs phone actions / asks the AI, speaks the result,
 *  4. goes back to listening for the wake word.
 * Shown to the user as a permanent notification with a Stop button. Only runs if switched on.
 */
class WakeService : Service() {
    private enum class St { WAKE, COMMAND, BUSY }
    private enum class After { WAKE, LISTEN }

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private var voice: Voice? = null
    private lateinit var store: SecureStore
    private lateinit var actions: PhoneActions
    private val llm = LlmClient()

    private var paused = false
    private var wakeWord = "jarvis"
    private var st = St.WAKE
    private var after = After.WAKE
    private var gotText = false
    private var turns = 0
    private var warnedOverlay = false
    private var quitting = false
    private var destroyed = false
    private var pending: Pending? = null
    private val history = mutableListOf<Pair<String, String>>()
    private val backstop = Runnable { if (st == St.COMMAND && !gotText) endConversation() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        store = SecureStore(this)
        actions = PhoneActions(applicationContext)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LISTEN, "Wake word listening", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "JARVIS needs you", NotificationManager.IMPORTANCE_HIGH))
        voice = Voice(
            applicationContext,
            onText = { onCommand(it) },
            onLevel = { },
            onListening = { on ->
                if (!on) main.postDelayed({ if (st == St.COMMAND && !gotText) endConversation() }, 300)
            },
            onSpeechDone = { onSpeechFinished() },
            onFail = { endConversation() }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            SecureStore(this).wakeEnabled = false
            stopSelf(); return START_NOT_STICKY
        }
        wakeWord = store.wakeWord.lowercase(Locale.getDefault())
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS is listening for \"$wakeWord\"")
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, 1, n, type)
        st = St.WAKE
        paused = appVisible
        if (!paused) startListening()
        return START_STICKY
    }

    // ---- Wake word -----------------------------------------------------------------------------

    private fun startListening() {
        if (paused || st != St.WAKE || recognizer != null) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(b: Bundle?) { heardWake(b) }
            override fun onResults(b: Bundle?) { if (!heardWake(b)) restart(300) }
            override fun onError(e: Int) {
                restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
            }
        })
        recognizer = r
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        })
    }

    private fun heardWake(b: Bundle?): Boolean {
        if (paused || st != St.WAKE) return false
        val heard = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.joinToString(" ")?.lowercase(Locale.getDefault()) ?: return false
        if (!heard.contains(wakeWord)) return false
        main.post { onWake() }
        return true
    }

    private fun stopRecognizer() { recognizer?.destroy(); recognizer = null }

    private fun restart(delayMs: Long) {
        stopRecognizer()
        main.postDelayed({ startListening() }, delayMs)
    }

    // ---- Conversation --------------------------------------------------------------------------

    private fun onWake() {
        if (paused || st != St.WAKE) return
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        st = St.COMMAND
        after = After.LISTEN
        turns = 0
        pending = null
        gotText = false
        val name = store.ownerName.trim()
        voice?.speak(if (name.isEmpty()) "Yes?" else "Yes, $name?")
    }

    private fun onSpeechFinished() {
        if (destroyed || quitting || paused) return
        when (st) {
            St.COMMAND -> startCommandListening()
            St.BUSY -> if (after == After.LISTEN) { st = St.COMMAND; startCommandListening() } else endConversation()
            St.WAKE -> {}
        }
    }

    private fun startCommandListening() {
        if (paused) { st = St.WAKE; return }
        gotText = false
        stopRecognizer()
        voice?.listen()
        main.removeCallbacks(backstop)
        main.postDelayed(backstop, 12000)
    }

    private fun endConversation() {
        main.removeCallbacks(backstop)
        voice?.stopListening()
        st = St.WAKE
        pending = null
        if (!paused && !quitting && !destroyed) main.postDelayed({ startListening() }, 500)
    }

    private fun onCommand(text: String) {
        gotText = true
        main.removeCallbacks(backstop)
        st = St.BUSY
        handle(text.trim())
    }

    private fun say(text: String, next: After) {
        if (destroyed) return
        after = next
        st = St.BUSY
        Bridge.post(Msg(false, text))
        history += "assistant" to text
        voice?.speak(text)
    }

    private fun sayError(text: String) {
        if (destroyed) return
        after = After.WAKE
        st = St.BUSY
        Bridge.post(Msg(false, text))
        voice?.speak(text)
    }

    private fun handle(text: String) {
        if (text.isEmpty()) { endConversation(); return }
        Bridge.post(Msg(true, text))
        val t = text.lowercase(Locale.getDefault()).trimEnd('.', '!', '?').trim()

        val p = pending
        if (p != null) {
            pending = null
            if (t in YES) {
                if (p.ask != null) { history += "user" to p.ask; askModel() } else say(p.run(), After.WAKE)
                return
            }
            if (t in NO) { say("Understood. Cancelled.", After.WAKE); return }
        }
        if (t in SLEEP) {
            quitting = true
            store.wakeEnabled = false
            say("Going quiet. Switch me back on in my settings whenever you like.", After.WAKE)
            main.postDelayed({ stopSelf() }, 4500)
            return
        }

        history += "user" to text
        Regex("remember (?:that )?(.+)", RegexOption.IGNORE_CASE).matchEntire(text.trimEnd('.'))?.let {
            store.remember(it.groupValues[1]); say("Noted. I'll remember that.", After.WAKE); return
        }
        if (t == "forget everything" || t == "forget all") { store.forgetAll(); say("Memory cleared.", After.WAKE); return }

        when (val r = actions.handle(text)) {
            is ActionResult.Done -> say(withOverlayNote(r.message), After.WAKE)
            is ActionResult.Confirm -> {
                pending = Pending(r.description, r.run)
                say(r.description + " Shall I proceed? Say yes or no.", After.LISTEN)
            }
            is ActionResult.ConfirmAsk -> {
                pending = Pending(r.description, ask = r.prompt)
                say(r.description + " Shall I proceed? Say yes or no.", After.LISTEN)
            }
            is ActionResult.NeedPermission -> {
                say("I need your permission for that, so I'm opening my screen.", After.WAKE)
                bringForward("retry", r.retry)
            }
            is ActionResult.PickFile -> {
                say("Opening my screen so you can choose the file.", After.WAKE)
                bringForward("retry", text)
            }
            is ActionResult.Later -> exec.execute {
                val m = r.work()
                main.post { say(m, After.WAKE) }
            }
            null -> askModel()
        }
    }

    private fun askModel() {
        val cfg = store.aiConfig()
        val owner = store.ownerName
        val mem = store.memories
        val snap = history.takeLast(20)
        exec.execute {
            val r = llm.ask(cfg, owner, mem, snap)
            main.post {
                if (r.ok) say(r.text, if (++turns < 6) After.LISTEN else After.WAKE) else sayError(r.text)
            }
        }
    }

    private fun withOverlayNote(msg: String): String {
        if (warnedOverlay || Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) return msg
        warnedOverlay = true
        return "$msg If nothing opened, please allow Display over other apps for me in my settings."
    }

    /** Opens the JARVIS screen (needed for permission pop-ups and the file picker). */
    private fun bringForward(key: String, value: String) {
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(key, value)
        if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) {
            startActivity(open)
        } else {
            val pi = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(this, CH_WAKE)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS needs you")
                .setContentText("Tap to continue")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
        }
    }

    /** The app screen has priority over the microphone while it is open. */
    fun onVisibility(visible: Boolean) {
        main.removeCallbacksAndMessages(null)
        if (visible) {
            paused = true
            stopRecognizer()
            voice?.stopListening()
            voice?.stopSpeaking()
            st = St.WAKE
            pending = null
        } else {
            paused = false
            st = St.WAKE
            main.postDelayed({ startListening() }, 1200)
        }
    }

    override fun onDestroy() {
        destroyed = true
        instance = null
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        voice?.shutdown()
        exec.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.jarvis.assistant.STOP_WAKE"
        private const val CH_LISTEN = "wake_listen"
        private const val CH_WAKE = "wake_heard"
        private val YES = setOf("yes", "yes please", "yep", "yeah", "sure", "ok", "okay", "confirm", "do it", "go ahead", "proceed")
        private val NO = setOf("no", "nope", "cancel", "stop", "never mind", "nevermind", "don't")
        private val SLEEP = setOf("go to sleep", "stop listening", "goodbye", "good bye")
        @Volatile var appVisible = false
        private var instance: WakeService? = null

        fun markVisible(v: Boolean) { appVisible = v; instance?.onVisibility(v) }
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }
    }
}
