package com.jarvis.assistant

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Status { STANDBY, LISTENING, THINKING, SPEAKING }
data class Msg(val fromUser: Boolean, val text: String)
class Pending(val description: String, val run: () -> String = { "" }, val ask: String? = null)
class PermRequest(val perms: List<String>, val retry: String)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SecureStore(app)
    private val actions = PhoneActions(app)
    private val llm = LlmClient()
    private val history = mutableListOf<Pair<String, String>>()
    private lateinit var voice: Voice

    val messages = mutableStateListOf<Msg>()
    var status by mutableStateOf(Status.STANDBY); private set
    var pending by mutableStateOf<Pending?>(null); private set
    var permRequest by mutableStateOf<PermRequest?>(null); private set
    var filePick by mutableStateOf<String?>(null); private set
    var level by mutableStateOf(0f); private set
    var continuous by mutableStateOf(false)
    var hasKey by mutableStateOf(false); private set
    var provider by mutableStateOf(store.provider); private set
    var backendUrl by mutableStateOf(store.backendUrl); private set
    var ownerName by mutableStateOf(store.ownerName); private set
    var wakeWord by mutableStateOf(store.wakeWord); private set
    var wakeEnabled by mutableStateOf(store.wakeEnabled); private set

    init {
        voice = Voice(
            app,
            onText = { submit(it) },
            onLevel = { level = it },
            onListening = { on ->
                if (!on) { level = 0f; if (status == Status.LISTENING) status = Status.STANDBY }
            },
            onSpeechDone = {
                status = Status.STANDBY
                if (continuous && WakeService.appVisible) { status = Status.LISTENING; voice.listen() }
            },
            onFail = { notify(it); status = Status.STANDBY }
        )
        val who = if (ownerName.isBlank()) "" else ", $ownerName"
        messages += Msg(false, "JARVIS online$who. How may I assist?")
        Bridge.drain().forEach { messages += it }
        Bridge.sink = { messages += it }
    }

    private fun config(): AiConfig {
        val p = store.provider
        val key = if (p == AiProvider.GEMINI) store.geminiKey else store.apiKey
        return AiConfig(p, key, store.model(p), store.backendUrl, store.backendToken)
    }

    fun keySaved(p: AiProvider) = (if (p == AiProvider.GEMINI) store.geminiKey else store.apiKey).isNotBlank()
    fun modelFor(p: AiProvider) = store.model(p)
    fun defaultModel(p: AiProvider) = LlmClient.defaultModel(p)

    fun saveSettings(
        p: AiProvider, key: String, model: String, name: String, word: String,
        backend: String, token: String
    ) {
        store.provider = p
        if (key.isNotBlank()) { if (p == AiProvider.GEMINI) store.geminiKey = key else store.apiKey = key }
        store.setModel(p, model)
        store.backendUrl = backend
        if (token.isNotBlank()) store.backendToken = token
        store.ownerName = name
        provider = p
        backendUrl = store.backendUrl
        hasKey = config().key.isNotBlank() || store.backendUrl.isNotBlank()
        ownerName = store.ownerName
        val changed = word.trim().ifBlank { "jarvis" } != store.wakeWord
        store.wakeWord = word
        wakeWord = store.wakeWord
        if (changed && wakeEnabled) setWake(true)
    }

    /** Call only after microphone permission is granted. */
    fun setWake(on: Boolean) {
        val app = getApplication<Application>()
        store.wakeEnabled = on
        wakeEnabled = on
        if (on) { WakeService.stop(app); WakeService.start(app) } else WakeService.stop(app)
    }

    /** Called when the wake word was heard and the app was brought forward. */
    fun onWake() {
        if (status == Status.LISTENING) return
        voice.stopSpeaking()
        status = Status.LISTENING
        voice.listen()
    }

    fun notify(text: String) { messages += Msg(false, text) }

    fun toggleMic() {
        if (status == Status.LISTENING) { voice.stopListening(); status = Status.STANDBY; return }
        voice.stopSpeaking()
        status = Status.LISTENING
        voice.listen()
    }

    fun confirmPending() = submit("yes")
    fun cancelPending() = submit("cancel")

    fun submit(textRaw: String, echo: Boolean = true) {
        val text = textRaw.trim()
        if (text.isEmpty()) return
        if (echo) messages += Msg(true, text)
        val t = text.lowercase().trimEnd('.', '!')
        val p = pending
        if (p != null) {
            pending = null
            if (t in listOf("yes", "confirm", "do it", "go ahead", "yes please", "yep", "sure")) {
                if (p.ask != null) { history += "user" to p.ask; askModel() } else reply(p.run())
                return
            }
            if (t in listOf("no", "cancel", "stop", "never mind", "nevermind")) { reply("Understood. Cancelled."); return }
        }
        history += "user" to text
        Regex("remember (?:that )?(.+)", RegexOption.IGNORE_CASE).matchEntire(text.trimEnd('.'))?.let {
            store.remember(it.groupValues[1]); reply("Noted. I'll remember that."); return
        }
        if (t == "forget everything" || t == "forget all") { store.forgetAll(); reply("Memory cleared."); return }
        if (t == "what do you remember") {
            val m = store.memories
            reply(if (m.isEmpty()) "Nothing yet." else "I remember: " + m.joinToString(". ")); return
        }
        when (val r = actions.handle(text)) {
            is ActionResult.Done -> reply(r.message)
            is ActionResult.Confirm -> {
                pending = Pending(r.description, r.run)
                reply(r.description + " Shall I proceed?")
            }
            is ActionResult.ConfirmAsk -> {
                pending = Pending(r.description, ask = r.prompt)
                reply(r.description + " Shall I proceed?")
            }
            is ActionResult.NeedPermission -> {
                reply(r.message)
                permRequest = PermRequest(r.perms, r.retry)
            }
            is ActionResult.Later -> {
                status = Status.THINKING
                viewModelScope.launch { reply(withContext(Dispatchers.IO) { r.work() }) }
            }
            is ActionResult.PickFile -> {
                reply("Choose a file. I'll only read the one you pick.")
                filePick = r.task
            }
            null -> askModel()
        }
    }

    fun permResult(anyGranted: Boolean) {
        val r = permRequest ?: return
        permRequest = null
        if (anyGranted) submit(r.retry, echo = false)
        else reply("Understood. I won't access that without your permission.")
    }

    fun fileChosen(uri: Uri?, cr: ContentResolver) {
        val task = filePick ?: return
        filePick = null
        if (uri == null) { reply("No file selected."); return }
        status = Status.THINKING
        viewModelScope.launch {
            val (name, text) = withContext(Dispatchers.IO) {
                val n = cr.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "file"
                val t = try {
                    cr.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(12000) } ?: ""
                } catch (e: Exception) { "" }
                n to t
            }
            if (text.isBlank() || text.contains('\u0000')) {
                reply("I can only read plain text files for now, and that one looks empty or binary.")
                return@launch
            }
            messages += Msg(true, "File: $name")
            history += "user" to "$task\n\nFile name: $name\n-----\n$text"
            askModel()
        }
    }

    private fun askModel() {
        val cfg = config()
        status = Status.THINKING
        val snapshot = history.takeLast(20)
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { llm.ask(cfg, store.ownerName, store.memories, snapshot) }
            reply(r.text, remember = r.ok)
        }
    }

    /** Sends one tiny real request with the saved settings and reports the outcome in the chat. */
    fun testConnection() {
        val cfg = config()
        status = Status.THINKING
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                llm.ask(cfg, store.ownerName, emptyList(), listOf("user" to "Reply with exactly: Connection OK"))
            }
            status = Status.STANDBY
            val via = if (cfg.backendUrl.isNotBlank()) "backend" else "direct"
            messages += Msg(false, if (r.ok) "Test passed (${cfg.provider.short}, $via): ${r.text}" else "Test failed: ${r.text}")
        }
    }

    private fun reply(text: String, remember: Boolean = true) {
        messages += Msg(false, text)
        if (remember) history += "assistant" to text
        status = Status.SPEAKING
        voice.speak(text)
    }

    /** Called when the screen goes to the background: hand the microphone to the background service. */
    fun onBackground() {
        voice.stopListening()
        if (status == Status.LISTENING) status = Status.STANDBY
    }

    override fun onCleared() { Bridge.sink = null; voice.shutdown() }
}
