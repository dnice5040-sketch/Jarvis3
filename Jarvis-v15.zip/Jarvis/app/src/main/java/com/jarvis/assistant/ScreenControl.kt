package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets Jarvis press Back/Home/Recents, scroll and tap buttons. Works only if the owner enabled it in Accessibility settings. */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }

    override fun onInterrupt() { }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    fun scrollScreen(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val f = findScrollable(c)
            if (f != null) return f
        }
        return null
    }

    fun clickText(what: String, blocked: Regex): String {
        val root = rootInActiveWindow ?: return "I can't see the screen right now."
        val nodes = root.findAccessibilityNodeInfosByText(what)
        if (nodes.isNullOrEmpty()) return "I couldn't find \"$what\" on the screen."
        for (node in nodes) {
            var target: AccessibilityNodeInfo? = node
            while (target != null && !target.isClickable) target = target.parent
            if (target == null) continue
            val label = node.text?.toString().orEmpty() + " " + node.contentDescription?.toString().orEmpty()
            if (blocked.containsMatchIn(label)) return "I won't tap that because it looks like a payment or a deletion. Please do it yourself."
            if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped $what."
        }
        return "I found \"$what\" but couldn't tap it."
    }

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
    }
}

object ScreenControl {
    private val rx = RegexOption.IGNORE_CASE
    private val blocked = Regex(
        "pay|buy|purchase|order|send money|transfer|delete|uninstall|factory reset|erase|checkout|confirm payment", rx
    )

    private fun m(p: String, s: String) = Regex(p, rx).matchEntire(s)

    private fun needService(ctx: Context): ActionResult {
        try {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
        return ActionResult.Done("To control the screen I need Accessibility access. I've opened the setting. Enable Jarvis screen control there, then ask again.")
    }

    fun handle(ctx: Context, s: String): ActionResult? {
        val glob: Pair<Int, String>? = when {
            m("(?:go|press|return) (?:to )?(?:the )?home(?: screen)?|show (?:the )?home screen", s) != null ->
                AccessibilityService.GLOBAL_ACTION_HOME to "Going home."
            m("(?:go|press|navigate) back", s) != null ->
                AccessibilityService.GLOBAL_ACTION_BACK to "Going back."
            m("(?:open|show) (?:the )?(?:recent apps|recents|app switcher)", s) != null ->
                AccessibilityService.GLOBAL_ACTION_RECENTS to "Here are your recent apps."
            m("(?:pull down|open|show) (?:the )?notification (?:panel|shade|bar)", s) != null ->
                AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS to "Opening the notification panel."
            m("(?:pull down|open|show) (?:the )?quick settings", s) != null ->
                AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS to "Opening quick settings."
            Build.VERSION.SDK_INT >= 28 && m("take a screenshot|screenshot", s) != null ->
                AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT to "Screenshot taken."
            Build.VERSION.SDK_INT >= 28 && m("lock (?:the )?(?:screen|phone)", s) != null ->
                AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN to "Locking the screen."
            else -> null
        }
        if (glob != null) {
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            return ActionResult.Done(if (svc.performGlobalAction(glob.first)) glob.second else "That didn't work on this screen.")
        }
        m("scroll (down|up)", s)?.let { r ->
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            val dir = r.groupValues[1].lowercase()
            return ActionResult.Done(if (svc.scrollScreen(dir == "down")) "Scrolling $dir." else "I can't scroll this screen.")
        }
        m("(?:tap|click) (?:on )?(?:the )?(.+)", s)?.let { r ->
            val what = r.groupValues[1].trim()
            if (blocked.containsMatchIn(what)) {
                return ActionResult.Done("I won't tap \"$what\" by voice because it could spend money or delete something. Please do that yourself.")
            }
            val svc = JarvisAccessibilityService.instance ?: return needService(ctx)
            return ActionResult.Done(svc.clickText(what, blocked))
        }
        return null
    }
}
